package com.svb.gateway.payments.payment.alert.service;

import com.svb.gateway.common.admin.dto.alerts.AlertRequest;
import com.svb.gateway.common.admin.dto.alerts.InputParams;
import com.svb.gateway.payments.common.alert.model.AlertParameters;
import com.svb.gateway.payments.common.alert.model.MsgDeliveryTrustedBody;
import com.svb.gateway.payments.common.alert.util.AlertCategoryEnum;
import com.svb.gateway.payments.common.alert.util.AlertEnum;
import com.svb.gateway.payments.common.alert.util.AlertUtil;
import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.entity.payment.BasePaymentEntity;
import com.svb.gateway.payments.common.enums.TransactionStatusEnum;
import com.svb.gateway.payments.common.enums.payment.PaymentType;
import com.svb.gateway.payments.common.model.MethodSignature;
import com.svb.gateway.payments.common.model.identity.IdentityResponseIdentityData;
import com.svb.gateway.payments.common.model.payment.PaymentTransStatusUpdateRequest;
import com.svb.gateway.payments.common.model.payment.TransferPaymentProcessingData;
import com.svb.gateway.payments.common.model.payment.WirePaymentProcessingData;
import com.svb.gateway.payments.common.model.payment.payinit.PaymentResponse;
import com.svb.gateway.payments.common.model.payment.processing.PaymentProcessingData;
import com.svb.gateway.payments.common.service.IdentityService;
import com.svb.gateway.payments.common.service.payment.IPaymentTransactionExtService;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.payment.entity.TransactionEntryEntity;
import com.svb.gateway.payments.payment.mapper.model.PaymentCommonMapper;
import com.svb.gateway.payments.payment.service.manager.PaymentManager;
import com.svb.gateway.payments.payment.service.manager.PaymentManagerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.modulith.NamedInterface;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

@Service
@NamedInterface
public class PaymentAlertService {
    @Value("${payment.application-timezone}")
    final String paymentAppTimeZone = "America/Los_Angeles";

    private final IdentityService identityService;
    private final DateUtil dateUtil;
    private final PaymentManagerFactory paymentManagerFactory;
    private final IPaymentTransactionExtService iPaymentTransactionExtService;

    public PaymentAlertService(IdentityService identityService, DateUtil dateUtil, PaymentManagerFactory paymentManagerFactory, IPaymentTransactionExtService iPaymentTransactionExtService) {
        this.identityService = identityService;
        this.dateUtil = dateUtil;
        this.paymentManagerFactory = paymentManagerFactory;
        this.iPaymentTransactionExtService = iPaymentTransactionExtService;
    }

    public AlertRequest paymentAwaitingApprovalRemainder(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest paymentAwaitingApproval(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest paymentProcessedNewRecipient(MethodSignature methodSignature, AlertRequest alertRequest) {
        // get params
        WirePaymentProcessingData wirePayment = (WirePaymentProcessingData) methodSignature.getArgs()[0];
        // no action if spm call response is null or invalid
        PaymentResponse paymentRes = (PaymentResponse) methodSignature.getResponseObj();
        if (paymentRes == null ||
                !StringUtils.hasLength(paymentRes.getPaymentReferenceId())) {
            return alertRequest;
        }

        Map<String, String> processingContext = wirePayment.getPaymentHeader().getContext();
        // No Alert because the payment transaction is not completed
        if(processingContext == null || processingContext.isEmpty()) {
            return alertRequest;
        }

        String processingStatus = processingContext.get(PaymentConstant.PAYMENT_PROCESSING_STATUS);
        // no action - if processing status as null or empty or in progress
        if(processingStatus == null || processingStatus.isEmpty()
        || TransactionStatusEnum.INPR.name().equalsIgnoreCase(processingStatus)) {
            return alertRequest;
        }
        String paymentRefId = paymentRes.getPaymentReferenceId();
        LocalDate deliveryDate = paymentRes.getPayment().getRequestedExecutionDate();
        String formattedDeliveryDate = deliveryDate.format(DateTimeFormatter.ofPattern("MMMM dd, yyyy"));
        PaymentManager manager = paymentManagerFactory.getPaymentManager(null);
        long transactionId = Long.parseLong(wirePayment.getPaymentData().getTxRefNum());
        TransactionEntryEntity transactionEntry = manager.getTransactionEntry(transactionId, 1);

        String createdUserId = transactionEntry.getCreatedBy();
        String modifiedUserId = transactionEntry.getUpdatedBy();
        String clientId = wirePayment.getPaymentData().getAddPayDetails().getClientId();
        long payeeId = transactionEntry.getPayeeId();

        IdentityResponseIdentityData modifier;
        // fetch identity data
        IdentityResponseIdentityData creator = identityService.getIdentity(createdUserId);
        if (creator == null) {
            return alertRequest;
        }
        if (createdUserId.equals(modifiedUserId)) {
            modifier = creator;
        } else {
            modifier = identityService.getIdentity(modifiedUserId);
        }

        var message = (MsgDeliveryTrustedBody) alertRequest.getAlerts().getFirst().getMsgDeliveryBody().getFirst();

        // get alerts params
        AlertParameters parameters = getAlertParamsForPaymentProcessing(creator, modifier, wirePayment.getPaymentData());
        parameters.setEstDeliveryDate(String.format("%s<br>Payment Reference: %s",
                formattedDeliveryDate, paymentRefId));
        parameters.setEstDeliveryTxt("Estimated Delivery Date");

        // check for first-time payment to payee
        if (!firstTimePayee(clientId, payeeId)) {
            message.setAlertName(AlertEnum.SVB_PYPRER.name());
            message.setAlertSubject(AlertEnum.SVB_PYPRER.getAlertSubject());
            message.setTrusted(AlertCategoryEnum.TRUSTED.equals(AlertEnum.SVB_PYPRER.getAlertCategory()));
        }
        // set parameters
        message.setParams(AlertUtil.constructInputParams(parameters));

        // populate the message body attributes
        populateMsgBodyAttrs(alertRequest,
                wirePayment.getPaymentData().getAddPayDetails().getCorpID(),
                wirePayment.getPaymentData().getAddPayDetails().getCif(),
                createdUserId);

        return alertRequest;
    }

    public AlertRequest paymentRejected(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    private boolean isIsTransfer(PaymentType paymentType) {
        return CommonConstant.TRANSFER_TYPES.contains(paymentType.toString());
    }

    /**
     * Get alert parameters for payment
     *
     * @param creator  IdentityResponseIdentityData
     * @param modifier IdentityResponseIdentityData
     * @param data     PaymentProcessingData
     * @return AlertParameters
     */
    private AlertParameters getAlertParamsForPaymentProcessing(IdentityResponseIdentityData creator, IdentityResponseIdentityData modifier,
                                                               PaymentProcessingData data) {
        LocalDate pymtLocalDate = PaymentCommonMapper.getDate(data.getProcessingDate());
        String formattedPymtDate = pymtLocalDate.format(DateTimeFormatter.ofPattern("MMMM dd, yyyy"));
        return AlertParameters.builder()
                .initiatorFirstName(creator.getData().getFirstName())
                .initiatorLastName(creator.getData().getLastName())
                .firstName(creator.getData().getFirstName())
                .modifiedByFirstName(modifier.getData().getFirstName())
                .modifiedByLastName(modifier.getData().getLastName())
                .accountNumber(data.getDebitAccountData().getAccNum())
                .accountNickName(data.getDebitAccountData().getAccName())
                .cifName(data.getAddPayDetails().getClientName())
                .recipientName(data.getCreditorData().getName())
                .recipientAccountNumber(data.getCreditAccountData().getAccNum())
                .amount(String.format("%.2f", Double.valueOf(data.getTransactionAmt())))
                .paymentDate(String.format("%s<br>Recurring Series ID: %s<br>Transaction ID: %s",
                        formattedPymtDate, "", data.getTxRefNum()))
                .isoCrycy(data.getTransactionCcy())
                .clientLanguage("US")
                .build();
    }

    /**
     * populate the message body attributes
     *
     * @param alertRequest AlertRequest
     * @param clientId     String
     * @param cif          String
     * @param userToken    String
     *
     */
    private void populateMsgBodyAttrs(AlertRequest alertRequest, final String clientId,
                                      final String cif, final String userToken) {
        alertRequest.getAlerts().getFirst().getMsgDeliveryBody().getFirst().setCorpId(clientId);
        alertRequest.getAlerts().getFirst().getMsgDeliveryBody().getFirst().setCustomerId(cif);
        alertRequest.getAlerts().getFirst().getMsgDeliveryBody().getFirst().setUserToken(userToken);
    }

    public AlertRequest templateCreated(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest templateDeleted(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest templateModified(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest templateAwaitingApproval(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest templateRejected(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }


    public AlertRequest transferCompleted(MethodSignature methodSignature, AlertRequest alertRequest) {
        // get params
        TransferPaymentProcessingData transferPayment = (TransferPaymentProcessingData) methodSignature.getArgs()[0];
        // no action if processing status is empty
        if(transferPayment.getPaymentHeader().getContext() == null
                || transferPayment.getPaymentHeader().getContext().isEmpty()) {
            return alertRequest;
        }
        Map<String, String> processingContext = transferPayment.getPaymentHeader().getContext();
        // no action if processing status is empty or in progress
        String processingStatus = processingContext.get(PaymentConstant.PAYMENT_PROCESSING_STATUS);
        if(processingStatus == null || TransactionStatusEnum.INPR.name().equalsIgnoreCase(processingStatus)) {
            return alertRequest;
        }
        PaymentManager manager = paymentManagerFactory.getPaymentManager(null);
        long transactionId = Long.parseLong(transferPayment.getPaymentData().getTxRefNum());
        TransactionEntryEntity transactionEntry = manager.getTransactionEntry(transactionId, 1);

        String createdUserId = transactionEntry.getCreatedBy();
        String modifiedUserId = transactionEntry.getUpdatedBy();

        IdentityResponseIdentityData modifier;
        // fetch identity data
        IdentityResponseIdentityData creator = identityService.getIdentity(createdUserId);
        if (creator == null) {
            return alertRequest;
        }
        if (createdUserId.equals(modifiedUserId)) {
            modifier = creator;
        } else {
            modifier = identityService.getIdentity(createdUserId);
        }

        var message = (MsgDeliveryTrustedBody) alertRequest.getAlerts().getFirst().getMsgDeliveryBody().getFirst();

        // get alerts params
        AlertParameters parameters = getAlertParamsForPaymentProcessing(creator, modifier, transferPayment.getPaymentData());
        parameters.setCifName(transactionEntry.getDebitAccountCifName());
        parameters.setToAccountCifName(transactionEntry.getPayeeName());
        // set parameters
        message.setParams(AlertUtil.constructInputParams(parameters));

        // populate the message body attributes
        populateMsgBodyAttrs(alertRequest,
                transferPayment.getPaymentData().getAddPayDetails().getCorpID(),
                transferPayment.getPaymentData().getAddPayDetails().getCif(),
                createdUserId);
        if (alertRequest.getAlerts().getFirst().getMsgDeliveryBody().getFirst() instanceof MsgDeliveryTrustedBody msgBody) {
            msgBody.setAccountId(transferPayment.getPaymentData().getDebitAccountData().getAccNum());
        }
        return alertRequest;
    }

    public AlertRequest transferUpdated(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest transferScheduled(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest transactionCancelled(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest transferCancelled(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest fxTransactionReversal(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest fxPaymentInstRequired(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest recurringPaymentScheduled(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest templateAwaitingApprovalReminder(MethodSignature methodSIgnature, AlertRequest alertRequest) {
        return alertRequest;
    }

    public AlertRequest wireReturned(MethodSignature methodSignature, AlertRequest alertRequest) {
        PaymentTransStatusUpdateRequest paymentTransStatusUpdateRequest;
        if (methodSignature != null &&
                methodSignature.getArgs() != null &&
                methodSignature.getArgs().length > 0 &&
                methodSignature.getArgs()[0] instanceof PaymentTransStatusUpdateRequest){
            paymentTransStatusUpdateRequest = (PaymentTransStatusUpdateRequest)methodSignature.getArgs()[0];
            PaymentTransStatusUpdateRequest.PaymentUpdateDetail paymentUpdateDetail = paymentTransStatusUpdateRequest.getPaymentUpdateDetails().getFirst();
            AlertParameters parameters = getWireParameters(paymentUpdateDetail.getTxRefNum(),paymentUpdateDetail);
            List<InputParams> params = AlertUtil.constructInputParams(parameters);
            alertRequest.getAlerts().getFirst().getMsgDeliveryBody().getFirst().setParams(params);
        }
        return alertRequest;
    }

    private AlertParameters getWireParameters(String txnRefNum, PaymentTransStatusUpdateRequest.PaymentUpdateDetail paymentUpdateDetail) {
        BasePaymentEntity paymentTransactionEntity = iPaymentTransactionExtService.getPaymentTransactions(txnRefNum);
        IdentityResponseIdentityData creator;
        AlertParameters alertParameters = null;
        if (paymentTransactionEntity != null) {
            creator = identityService.getIdentity(paymentTransactionEntity.getUserId());
            alertParameters = AlertParameters.builder()
                .accountNumber(paymentTransactionEntity.getClientAccountNumber())
                .amount(paymentTransactionEntity.getDebitAmount())
                .paymentDate(paymentUpdateDetail.getWireReturnDate())
                .recipientName(paymentTransactionEntity.getPayeeName())
                .caseNum(paymentUpdateDetail.getAppianCaseNumber())
                .accountNickName(paymentTransactionEntity.getPayeeNickName())
                .reason(paymentUpdateDetail.getWireReturnReason())
                .isoCrycy(paymentTransactionEntity.getClientAccountCurrency())
                .cifName(paymentTransactionEntity.getCif())
                .returnAmount(paymentUpdateDetail.getWireReturnAmount())
                .returnIsoCurrency(paymentUpdateDetail.getWireReturnCurrency())

                .build();
            if(creator != null && creator.getData() !=null){
                alertParameters.setFirstName(creator.getData().getFirstName());
            }
        }
        return alertParameters;
    }

    /**
     * Check if payment is made for the payee
     *
     * @param clientId String
     * @param payeeId  long
     * @return boolean
     */
    private boolean firstTimePayee(final String clientId, final long payeeId) {
        Timestamp fromDate = Timestamp.valueOf(dateUtil.getStartOfDayDateTime(paymentAppTimeZone).minusDays(365));

        PaymentManager manager = paymentManagerFactory.getPaymentManager(null);
        int count = manager.getPaymentCount(clientId, payeeId, fromDate);
        return count == 0;
    }
}
