package com.svb.gateway.payments.payment.alert.service;

import com.svb.gateway.common.admin.dto.alerts.AlertRequest;
import com.svb.gateway.payments.common.alert.model.AlertParameters;
import com.svb.gateway.payments.common.alert.model.MsgDeliveryTrustedBody;
import com.svb.gateway.payments.common.alert.util.AlertCategoryEnum;
import com.svb.gateway.payments.common.alert.util.AlertEnum;
import com.svb.gateway.payments.common.alert.util.AlertUtil;
import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.ApprovalStateEnum;
import com.svb.gateway.payments.common.enums.payment.PaymentStatus;
import com.svb.gateway.payments.common.enums.payment.PaymentType;
import com.svb.gateway.payments.common.model.MethodSignature;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.approvals.ApprovalData;
import com.svb.gateway.payments.common.model.identity.IdentityResponseIdentityData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.modulith.NamedInterface;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.List;

@Slf4j
@Service
@NamedInterface
public class PaymentWorkflowAlertService {

    private final AlertUtil alertUtil;

    public PaymentWorkflowAlertService(AlertUtil alertUtil) {
        this.alertUtil = alertUtil;
    }

    /**
     * Populating alerts parameters
     *
     * @param methodSignature MethodSignature
     * @param alertRequest    AlertRequest
     * @return AlertRequest
     */
    public AlertRequest approvalInitiated(MethodSignature methodSignature, AlertRequest alertRequest) {
        // get params
        RequestData<PaymentInitiationData> requestData = (RequestData<PaymentInitiationData>) methodSignature.getArgs()[0];
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        PaymentInitiationData paymentData = requestData.getRequest();
        // no action required
        if (suppressAlert(context, paymentData)) {
            log.info("alert payment approval Initiated::suppressed {}", context.log());
            return null;
        }
        // fetch identity data
        List<IdentityResponseIdentityData> names = alertUtil.getNames(paymentData.getMetaInfo().getCreatedBy(), context.getUserId());
        // get message body
        MsgDeliveryTrustedBody message = (MsgDeliveryTrustedBody) alertRequest.getAlerts().getFirst().getMsgDeliveryBody().getFirst();
        // get alerts params
        AlertParameters parameters = AlertParameters.builder()
                .firstName(names.size() > 1 ? names.get(1).getData().getFirstName() : names.get(0).getData().getFirstName())
                .initiatorFirstName(names.get(0).getData().getFirstName())
                .initiatorLastName(names.get(0).getData().getLastName())
                .accountNumber(paymentData.getEntries().getFirst().getDebitAccountData().getAccNum())
                .accountNickName(paymentData.getEntries().getFirst().getDebitAccountData().getAccName())
                .cifName(StringUtils.hasLength(paymentData.getEntries().getFirst().getDebitAccountData().getCifName()) ?
                        paymentData.getEntries().getFirst().getDebitAccountData().getCifName() : Strings.EMPTY)
                .recipientName(paymentData.getEntries().getFirst().getCreditorData().getName())
                .recipientAccountNumber(paymentData.getEntries().getFirst().getCreditAccountData().getAccNum())
                .amount(String.format("%.2f", paymentData.getTotalTransactionAmt()))
                .paymentDate(alertUtil.getDate(paymentData.getPaymentDate(),
                        paymentData.getPaymentId(),
                        paymentData.getRecurringData()))
                .isoCrycy(paymentData.getTransactionCcy().toString())
                .clientLanguage("US")
                .alertPaymentMethod(paymentData.getPaymentType() != null ? paymentData.getPaymentType().getDescriptionAlert() : Strings.EMPTY)
                .approvalSequencingMethod(getApprovalSequencingMethod(paymentData.getPaymentType(), paymentData.getPaymentStatus()))
                .cutOff(alertUtil.getCutOff(paymentData.getPaymentType()))
                .userIds(alertUtil.getUsers(paymentData.getPaymentId(), "payment", paymentData.getWorkflowId()))
                .build();
        // set parameters
        message.setParams(AlertUtil.constructInputParams(parameters));
        // populate the message body attributes
        message.setCorpId(context.getClientId());
        message.setCustomerId(paymentData.getEntries().getFirst().getDebitAccountData().getCif());
        message.setAccountId(paymentData.getEntries().getFirst().getDebitAccountData().getAccNum());

        boolean isTransfer = isIsTransfer(paymentData.getPaymentType().toString());
        setAlertDetails(message, isTransfer ? AlertEnum.SVB_TRAPP : AlertEnum.SVB_PYPDA);
        return alertRequest;
    }

    /**
     * Populating alerts parameters
     *
     * @param methodSignature MethodSignature
     * @param alertRequest    AlertRequest
     * @return AlertRequest
     */
    public AlertRequest approvedProcessed(MethodSignature methodSignature, AlertRequest alertRequest) {
        // get params
        PaymentContext context = (PaymentContext) methodSignature.getArgs()[0];
        ApprovalData approvalData = (ApprovalData) methodSignature.getArgs()[1];
        HashMap<String, String> additionalData = approvalData.getAdditionalData();
        // no action required
        if (suppressAlert(context, approvalData)) {
            log.info("alert payment approval processed::suppressed {}", context.log());
            return null;
        }
        // fetch identity data
        List<IdentityResponseIdentityData> names = alertUtil.getNames(additionalData.get("createdBy"), context.getUserId());
        // get message body
        MsgDeliveryTrustedBody message = (MsgDeliveryTrustedBody) alertRequest.getAlerts().getFirst().getMsgDeliveryBody().getFirst();
        PaymentType paymentType = PaymentType.fromValue(additionalData.get("paymentType"));
        // get alerts params
        String cifName = additionalData.get("debitAccountData.cifName");
        String toCifName = additionalData.get("creditAccountData.cifName");
        AlertParameters parameters = AlertParameters.builder()
                .firstName(names.size() > 1 ? names.get(1).getData().getFirstName() : names.get(0).getData().getFirstName())
                .initiatorFirstName(names.get(0).getData().getFirstName())
                .initiatorLastName(names.get(0).getData().getLastName())
                .accountNumber(additionalData.get("debitAccountData.accNum"))
                .accountNickName(additionalData.get("debitAccountData.accNickName"))
                .cifName(StringUtils.hasLength(cifName) ? cifName : CommonConstant.EMPTY)
                .toAccountCifName(StringUtils.hasLength(toCifName) ? toCifName : CommonConstant.EMPTY)
                .recipientName(additionalData.get("creditorData.name"))
                .recipientAccountNumber(additionalData.get("creditAccountData.accNum"))
                .amount(additionalData.get("totalTransactionAmt"))
                .paymentDate(alertUtil.getDate(additionalData))
                .isoCrycy(additionalData.get("transactionCcy"))
                .clientLanguage("US")
                .alertPaymentMethod(paymentType != null ? paymentType.getDescriptionAlert() : "")
                .build();
        boolean isTransfer = isIsTransfer(additionalData.get("paymentType"));
        if (approvalData.getCurrentState().equals("11")) {
            if(isTransfer) {
                setAlertDetails(message, AlertEnum.SVB_TRREJ);
            }
            parameters.setRejectedByFirstName(names.get(1).getData().getFirstName());
            parameters.setRejectedByLastName(names.get(1).getData().getLastName());
        } else if (approvalData.getCurrentState().equals("12")) {
            setAlertDetails(message, isTransfer ? AlertEnum.SVB_TRCAN : AlertEnum.SVB_PYCAN);
            parameters.setModifiedByFirstName(names.get(1).getData().getFirstName());
            parameters.setModifiedByLastName(names.get(1).getData().getLastName());
        } else {
            parameters.setApprovalSequencingMethod(getApprovalSequencingMethod(paymentType,
                    PaymentStatus.fromValue(additionalData.get("paymentStatus"))));
            setAlertDetails(message, isTransfer ? AlertEnum.SVB_TRAPP : AlertEnum.SVB_PYPDA);
            parameters.setUserIds(alertUtil.getUsers(Long.parseLong(additionalData.get("paymentId")), "payment", approvalData.getWorkflowId()));
            parameters.setCutOff(alertUtil.getCutOff(paymentType));
        }
        // set parameters
        message.setParams(AlertUtil.constructInputParams(parameters));
        // populate the message body attributes
        message.setCorpId(context.getClientId());
        message.setCustomerId(additionalData.get("debitAccountData.cif"));
        message.setAccountId(additionalData.get("debitAccountData.accNum"));
        return alertRequest;
    }

    private boolean isIsTransfer(String paymentType) {
        return CommonConstant.TRANSFER_TYPES.contains(paymentType);
    }

    private void setAlertDetails(MsgDeliveryTrustedBody message, AlertEnum alertEnum) {
        message.setAlertName(alertEnum.name());
        message.setAlertSubject(alertEnum.getAlertSubject());
        message.setTrusted(AlertCategoryEnum.TRUSTED.equals(AlertEnum.SVB_PYCAN.getAlertCategory()));
    }

    protected boolean suppressAlert(PaymentContext context, PaymentInitiationData paymentData) {
        return !context.getBadRequestExceptions().isEmpty();
    }

    private boolean suppressAlert(PaymentContext context, ApprovalData approvalData) {
        boolean result = true;

        ApprovalStateEnum stateEnum = ApprovalStateEnum.fromValue(approvalData.getCurrentState());
        if (stateEnum == null) {
            log.error("Approval current state is null, {}", approvalData.getEntityId());
        } else {
            log.info("Approval current state: {}", stateEnum.name());
            result = (!context.getBadRequestExceptions().isEmpty()
                    || (stateEnum != ApprovalStateEnum.REJECTED
                    && stateEnum != ApprovalStateEnum.CANCELLED
                    && stateEnum != ApprovalStateEnum.NEED_APPROVAL
                    && stateEnum != ApprovalStateEnum.NEED_FINAL_APPROVAL));
        }

        return result;
    }

    private String getApprovalSequencingMethod(PaymentType paymentType, PaymentStatus paymentStatus) {
        if (paymentType == null || paymentStatus == null) {
            return "APPROVAL_SEQUENCING_METHOD";
        }
        String approvalState = "_INITIAL";
        if (paymentStatus == PaymentStatus.PNFA) {
            approvalState = "_FINAL";
        }

        return switch (paymentType) {
            case ACH, CHK, RTP, FED, FET, USI, FXW, MSI, MXW, SAM, ICA ->
                    paymentType.getDescriptionAlert() + approvalState;
            default -> "APPROVAL_SEQUENCING_METHOD";
        };
    }
}
