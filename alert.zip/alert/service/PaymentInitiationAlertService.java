package com.svb.gateway.payments.payment.alert.service;

import com.svb.gateway.common.admin.dto.alerts.AlertRequest;
import com.svb.gateway.payments.common.alert.model.AlertParameters;
import com.svb.gateway.payments.common.alert.model.MsgDeliveryTrustedBody;
import com.svb.gateway.payments.common.alert.util.AlertCategoryEnum;
import com.svb.gateway.payments.common.alert.util.AlertEnum;
import com.svb.gateway.payments.common.alert.util.AlertUtil;
import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.payment.PaymentStatus;
import com.svb.gateway.payments.common.model.MethodSignature;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.identity.IdentityResponseIdentityData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationEntryData;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.payment.service.manager.PaymentManager;
import com.svb.gateway.payments.payment.service.manager.PaymentManagerFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.modulith.NamedInterface;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@NamedInterface
public class PaymentInitiationAlertService {

    private final AlertUtil alertUtil;
    private final DateUtil dateUtil;
    private final PaymentManagerFactory paymentManagerFactory;

    public PaymentInitiationAlertService(AlertUtil alertUtil, DateUtil dateUtil, PaymentManagerFactory paymentManagerFactory) {
        this.alertUtil = alertUtil;
        this.dateUtil = dateUtil;
        this.paymentManagerFactory = paymentManagerFactory;
    }

    /**
     * Populating alerts parameters
     *
     * @param methodSignature MethodSignature
     * @param alertRequest    AlertRequest
     * @return AlertRequest
     */
    public AlertRequest paymentScheduled(MethodSignature methodSignature, AlertRequest alertRequest) {
        // get params
        RequestData<PaymentInitiationData> requestData = (RequestData<PaymentInitiationData>) methodSignature.getArgs()[0];
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        PaymentInitiationData paymentData = requestData.getRequest();
        // no action required
        if (suppressAlert(context, paymentData)) {
            log.info("alert payment scheduled::suppressed {} : Is Hold: {},  Payment Status : {}",
                    context.log(), paymentData.isHold(), Optional.of(paymentData).map(PaymentInitiationData::getPaymentStatus)
                            .map(PaymentStatus::toString).orElse(Strings.EMPTY));
            return null;
        }
        populateAlertDetails(paymentData, alertRequest, false, requestData, context);

        return alertRequest;
    }

    /**
     * Populating alerts parameters
     *
     * @param methodSignature MethodSignature
     * @param alertRequest    AlertRequest
     * @return AlertRequest
     */
    public AlertRequest paymentUpdated(MethodSignature methodSignature, AlertRequest alertRequest) {
        // get params
        RequestData<PaymentInitiationData> requestData = (RequestData<PaymentInitiationData>) methodSignature.getArgs()[0];
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        PaymentInitiationData paymentData = requestData.getRequest();
        // no action required
        if (suppressAlert(context, paymentData)) {
            log.info("alert payment updated::suppressed {} : Is Hold: {},  Payment Status : {}",
                    context.log(), paymentData.isHold(), paymentData.getPaymentStatus().toString());
            return null;
        }
        // fetch identity data
        populateAlertDetails(paymentData, alertRequest, true, requestData, context);

        return alertRequest;
    }

    private void populateAlertDetails(PaymentInitiationData paymentData, AlertRequest alertRequest, boolean isUpdate, RequestData<PaymentInitiationData> requestData, PaymentContext context) {
        // fetch identity data
        List<IdentityResponseIdentityData> names = alertUtil.getNames(paymentData.getMetaInfo().getCreatedBy(), paymentData.getMetaInfo().getUpdatedBy());
        // get message body
        MsgDeliveryTrustedBody message = (MsgDeliveryTrustedBody) alertRequest.getAlerts().getFirst().getMsgDeliveryBody().getFirst();
        // get alerts params
        AlertParameters parameters = getAlertParameters(isUpdate, names.get(0), names.size() > 1 ? names.get(1) : names.get(0), message, requestData);
        // set parameters
        message.setParams(AlertUtil.constructInputParams(parameters));
        // populate the message body attributes
        message.setCorpId(context.getClientId());
        message.setCustomerId(paymentData.getEntries().getFirst().getDebitAccountData().getCif());
        message.setAccountId(paymentData.getEntries().getFirst().getDebitAccountData().getAccNum());
    }

    /**
     * Get alert parameters for transfer or payment depending on a payment type
     * populate alert details like subject, alert id
     *
     * @param isUpdate    boolean
     * @param creator     IdentityResponseIdentityData
     * @param modifier    IdentityResponseIdentityData
     * @param message     MsgDeliveryTrustedBody
     * @param requestData RequestData<PaymentInitiationData>
     * @return AlertParameters
     */
    private AlertParameters getAlertParameters(boolean isUpdate, IdentityResponseIdentityData creator, IdentityResponseIdentityData modifier, MsgDeliveryTrustedBody message, RequestData<PaymentInitiationData> requestData) {
        AlertParameters parameters;
        PaymentInitiationData paymentData = requestData.getRequest();
        PaymentInitiationEntryData data = paymentData.getEntries().getFirst();
        boolean isNewPayee = false;
        // check for transfer
        boolean isTransfer = alertUtil.isIsTransfer(paymentData.getPaymentType());
        log.info("Payment Initiation Alert : Payment Type: {}, Is Tranfer: {} ",
                paymentData.getPaymentType().toString(), isTransfer);
        // check for transfer
        if (isTransfer) {
            parameters = getAlertParametersForTransfer(creator, modifier, data, paymentData);
        } else {
            parameters = getAlertParametersForPayment(creator, modifier, data, paymentData);
            // check for first-time payment to payee
            if (!isUpdate) {
                isNewPayee = firstTimePayee(requestData);
            }
        }
        // set alertId
        setAlertId(message, isTransfer, isUpdate, isNewPayee);
        return parameters;
    }

    /**
     * Check if payment is made for the payee
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return boolean
     */
    private boolean firstTimePayee(RequestData<PaymentInitiationData> requestData) {
        Timestamp fromDate = Timestamp.valueOf(dateUtil.getStartOfDayDateTime(requestData.getRequest().getEntries().getFirst().getNetworkTimeZone()).minusDays(365));
        PaymentManager manager = paymentManagerFactory.getPaymentManager(null);
        // fetch from a database
        int count = manager.getPaymentCount(requestData.getGatewayContext().getClientId(),
                requestData.getRequest().getEntries().getFirst().getPayeeId(),
                fromDate);
        return count == 0;
    }

    /**
     * Get alert parameters for payment
     *
     * @param creator     IdentityResponseIdentityData
     * @param modifier    IdentityResponseIdentityData
     * @param data        PaymentInitiationEntryData
     * @param paymentData PaymentInitiationData
     * @return AlertParameters
     */
    private AlertParameters getAlertParametersForPayment(IdentityResponseIdentityData creator, IdentityResponseIdentityData modifier, PaymentInitiationEntryData data, PaymentInitiationData paymentData) {
        return AlertParameters.builder()
                .firstName(modifier.getData().getFirstName())
                .initiatorFirstName(creator.getData().getFirstName())
                .initiatorLastName(creator.getData().getLastName())
                .modifiedByFirstName(modifier.getData().getFirstName())
                .modifiedByLastName(modifier.getData().getLastName())
                .accountNumber(data.getDebitAccountData().getAccNum())
                .accountNickName(data.getDebitAccountData().getAccName())
                .cifName(StringUtils.hasLength(data.getDebitAccountData().getCifName()) ? data.getDebitAccountData().getCifName() : Strings.EMPTY)
                .recipientName(data.getCreditorData().getName())
                .recipientAccountNumber(data.getCreditAccountData().getAccNum())
                .amount(String.format("%.2f", paymentData.getTotalTransactionAmt()))
                .paymentDate(alertUtil.getDate(paymentData.getPaymentDate(),
                        paymentData.getPaymentId(),
                        paymentData.getRecurringData()))
                .isoCrycy(paymentData.getTransactionCcy().toString())
                .clientLanguage("US")
                .alertPaymentMethod(paymentData.getPaymentType().getDescriptionAlert())
                .build();
    }

    /**
     * Get alert parameters for transfer
     *
     * @param creator     IdentityResponseIdentityData
     * @param modifier    IdentityResponseIdentityData
     * @param data        PaymentInitiationEntryData
     * @param paymentData PaymentInitiationData
     * @return AlertParameters
     */
    private AlertParameters getAlertParametersForTransfer(IdentityResponseIdentityData creator, IdentityResponseIdentityData modifier, PaymentInitiationEntryData data, PaymentInitiationData paymentData) {
        AlertParameters params = this.getAlertParametersForPayment(creator, modifier, data, paymentData);
        params.setToAccountCifName(StringUtils.hasLength(data.getCreditAccountData().getCifName())
                ? data.getCreditAccountData().getCifName() : Strings.EMPTY);
        return params;
    }

    protected boolean suppressAlert(PaymentContext context, PaymentInitiationData paymentData) {
        // status -- In Process or Created should not sent alert.
        PaymentStatus status = paymentData.getPaymentStatus();
        return !context.getBadRequestExceptions().isEmpty()
                || context.isApprovalFlag()
                || status == PaymentStatus.COMP
                || status == PaymentStatus.CRTD;
    }

    /**
     * Default alert is SVB_PYSCER and depending on criteria it can be changed
     *
     * @param message    MsgDeliveryTrustedBody
     * @param isTransfer boolean
     * @param isUpdate   boolean
     * @param isNewPayee boolean
     */
    private void setAlertId(MsgDeliveryTrustedBody message, boolean isTransfer, boolean isUpdate, boolean isNewPayee) {
        if (isTransfer && isUpdate) {
            message.setAlertName(AlertEnum.SVB_TRMOD.name());
            message.setAlertSubject(AlertEnum.SVB_TRMOD.getAlertSubject());
            message.setTrusted(AlertCategoryEnum.TRUSTED.equals(AlertEnum.SVB_TRMOD.getAlertCategory()));
        } else if (isTransfer) {
            message.setAlertName(AlertEnum.SVB_TRSCHD.name());
            message.setAlertSubject(AlertEnum.SVB_TRSCHD.getAlertSubject());
            message.setTrusted(AlertCategoryEnum.TRUSTED.equals(AlertEnum.SVB_TRSCHD.getAlertCategory()));
        } else if (isUpdate) {
            message.setAlertName(AlertEnum.SVB_PYMOD.name());
            message.setAlertSubject(AlertEnum.SVB_PYMOD.getAlertSubject());
            message.setTrusted(AlertCategoryEnum.TRUSTED.equals(AlertEnum.SVB_PYMOD.getAlertCategory()));
        } else if (isNewPayee) {
            message.setAlertName(AlertEnum.SVB_PYSCNR.name());
            message.setAlertSubject(AlertEnum.SVB_PYSCNR.getAlertSubject());
            message.setTrusted(AlertCategoryEnum.TRUSTED.equals(AlertEnum.SVB_PYSCNR.getAlertCategory()));
        }
    }
}
