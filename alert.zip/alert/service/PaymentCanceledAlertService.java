package com.svb.gateway.payments.payment.alert.service;

import com.svb.gateway.common.admin.dto.alerts.AlertRequest;
import com.svb.gateway.payments.common.alert.model.AlertParameters;
import com.svb.gateway.payments.common.alert.model.MsgDeliveryTrustedBody;
import com.svb.gateway.payments.common.alert.util.AlertCategoryEnum;
import com.svb.gateway.payments.common.alert.util.AlertEnum;
import com.svb.gateway.payments.common.alert.util.AlertUtil;
import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.payment.PaymentType;
import com.svb.gateway.payments.common.model.MethodSignature;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.identity.IdentityResponseIdentityData;
import com.svb.gateway.payments.common.model.payment.cancellation.PaymentCancellationData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.modulith.NamedInterface;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

@Slf4j
@Service
@NamedInterface
public class PaymentCanceledAlertService {

    private final AlertUtil alertUtil;

    public PaymentCanceledAlertService(AlertUtil alertUtil) {
        this.alertUtil = alertUtil;
    }

    /**
     * Populating alerts parameters
     * Default alert is SVB_PYCAN and depending on criteria, it can be changed
     * Criteria
     * - Transfer - SVB_TRCAN
     *
     * @param methodSignature MethodSignature
     * @param alertRequest    AlertRequest
     * @return AlertRequest
     */
    public AlertRequest paymentCancelled(MethodSignature methodSignature, AlertRequest alertRequest) {
        // get params
        RequestData<PaymentCancellationData> requestData = (RequestData<PaymentCancellationData>) methodSignature.getArgs()[0];
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        HashMap<String, String> additionalData = requestData.getRequest().getAdditionalData();
        // no action required
        if (!context.getExceptions().isEmpty()) {
            log.info("alert payment cancelled::suppressed {}", context.log());
            return alertRequest;
        }
        // check for transfer
        boolean isTransfer = alertUtil.isIsTransfer(requestData.getRequest().getPaymentType());
        // fetch identity data
        List<IdentityResponseIdentityData> names = alertUtil.getNames(additionalData.get("createdBy"), context.getUserId());
        // populate message details
        MsgDeliveryTrustedBody message = (MsgDeliveryTrustedBody) alertRequest.getAlerts().getFirst().getMsgDeliveryBody().getFirst();
        // get alert params
        AlertParameters alertParameters = getAlertParameters(isTransfer, names.get(0), names.size() > 1 ? names.get(1) : names.get(0), message, additionalData);
        // set alerts params
        message.setParams(AlertUtil.constructInputParams(alertParameters));

        message.setCorpId(context.getClientId());
        message.setCustomerId(additionalData.get("debitAccountData.cif"));
        message.setAccountId(additionalData.get("debitAccountData.accNum"));

        return alertRequest;
    }

    /**
     * Get alert parameters for transfer or payment depending on a payment type
     * populate alert details like subject, alert id
     *
     * @param isTransfer     boolean
     * @param creator        IdentityResponseIdentityData
     * @param modifier       IdentityResponseIdentityData
     * @param message        MsgDeliveryTrustedBody
     * @param additionalData HashMap<String, String>
     * @return AlertParameters
     */
    private AlertParameters getAlertParameters(boolean isTransfer, IdentityResponseIdentityData creator, IdentityResponseIdentityData modifier, MsgDeliveryTrustedBody message, HashMap<String, String> additionalData) {
        AlertParameters parameters;
        // check for transfer
        if (isTransfer) {
            parameters = getAlertParametersForTransfer(creator, modifier, additionalData);
            message.setAlertName(AlertEnum.SVB_TRCAN.name());
            message.setAlertSubject(AlertEnum.SVB_TRCAN.getAlertSubject());
            message.setTrusted(AlertCategoryEnum.TRUSTED.equals(AlertEnum.SVB_TRCAN.getAlertCategory()));
        } else {
            parameters = getAlertParametersForPayment(creator, modifier, additionalData);
        }

        return parameters;
    }

    /**
     * Get alert parameters for payment
     *
     * @param creator        IdentityResponseIdentityData
     * @param modifier       IdentityResponseIdentityData
     * @param additionalData HashMap<String, String>
     * @return AlertParameters
     */
    private AlertParameters getAlertParametersForPayment(IdentityResponseIdentityData creator, IdentityResponseIdentityData modifier, HashMap<String, String> additionalData) {
        PaymentType paymentType = PaymentType.valueOf(additionalData.get("paymentType"));

        return AlertParameters.builder()
                .firstName(modifier.getData().getFirstName())
                .initiatorFirstName(creator.getData().getFirstName())
                .initiatorLastName(creator.getData().getLastName())
                .modifiedByFirstName(modifier.getData().getFirstName())
                .modifiedByLastName(modifier.getData().getLastName())
                .accountNumber(additionalData.get("debitAccountData.accNum"))
                .accountNickName(additionalData.get("debitAccountData.accNickName"))
                .cifName(additionalData.get("debitAccountData.cifName"))
                .amount(additionalData.get("totalTransactionAmt"))
                .isoCrycy(additionalData.get("transactionCcy"))
                .paymentDate(alertUtil.getDate(additionalData))
                .recipientName(additionalData.get("creditorData.name"))
                .recipientAccountNumber(additionalData.get("creditAccountData.accNum"))
                .clientLanguage("US")
                .alertPaymentMethod(paymentType.getDescriptionAlert())
                .build();
    }

    /**
     * Get alert parameters for transfer
     *
     * @param creator        IdentityResponseIdentityData
     * @param modifier       IdentityResponseIdentityData
     * @param additionalData HashMap<String, String>
     * @return AlertParameters
     */
    private AlertParameters getAlertParametersForTransfer(IdentityResponseIdentityData creator, IdentityResponseIdentityData modifier, HashMap<String, String> additionalData) {
        AlertParameters params = this.getAlertParametersForPayment(creator, modifier, additionalData);
        params.setToAccountCifName(additionalData.get("creditorData.name"));
        return params;
    }
}
