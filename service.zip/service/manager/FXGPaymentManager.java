package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.mapper.db.ActivityLogDbMapper;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationEntryData;
import com.svb.gateway.payments.common.model.payment.processing.CrossCurrencyPaymentData;
import com.svb.gateway.payments.common.model.payment.processing.PaymentProcessingData;
import com.svb.gateway.payments.common.model.rulesengine.GACHInfo;
import com.svb.gateway.payments.common.model.rulesengine.RuleData;
import com.svb.gateway.payments.common.service.AccountsService;
import com.svb.gateway.payments.common.service.ApprovalsService;
import com.svb.gateway.payments.common.service.BanksService;
import com.svb.gateway.payments.common.util.AmountCurrencyUtil;
import com.svb.gateway.payments.common.util.CountryRulesUtil;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.payment.entity.PaymentEntryEntity;
import com.svb.gateway.payments.payment.entity.TransactionEntryEntity;
import com.svb.gateway.payments.payment.mapper.db.PaymentDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.entity.PaymentMapper;
import com.svb.gateway.payments.payment.mapper.entity.TransactionMapper;
import com.svb.gateway.payments.payment.mapper.model.KafkaHostMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.model.ProcessingSplitMessage;
import com.svb.gateway.payments.payment.service.FXService;
import com.svb.gateway.payments.payment.service.LimitsService;
import com.svb.gateway.payments.payment.service.host.PaymentKafkaHost;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import com.svb.gateway.payments.payment.util.RecurringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.svb.gateway.payments.common.constants.BankConfigConstant.SWIFT;

@Slf4j
@Service("FXG")
public class FXGPaymentManager extends PaymentManager {

    private final PaymentMapper paymentMapper;
    private final TransactionMapper transactionMapper;
    private final KafkaHostMapper kafkaHostMapper;
    private final BanksService banksService;
    private final FXService fxService;
    private final DateUtil dateUtil;
    private final AmountCurrencyUtil amountCurrencyUtil;
    private final CountryRulesUtil countryRulesUtil;

    public FXGPaymentManager(AccountsService accountsService,
                             ApprovalsService approvalsService,
                             RecurringUtil recurringUtil,
                             DateUtil dateUtil,
                             PaymentMapper paymentMapper,
                             TransactionMapper transactionMapper,
                             PaymentDBMapper paymentDBMapper,
                             TransactionDBMapper transactionDBMapper,
                             TransactionEntryDBMapper transactionEntryDBMapper,
                             KafkaHostMapper kafkaHostMapper,
                             PaymentKafkaHost paymentKafkaHost,
                             BanksService banksService,
                             FXService fxService,
                             LimitsService limitsService,
                             AmountCurrencyUtil amountCurrencyUtil,
                             CountryRulesUtil countryRulesUtil,
                             PaymentManagerFetch fetchManager,
                             PaymentManagerValidate validateManager,
                             PaymentManagerCreate createManager,
                             PaymentManagerEdit editManager,
                             ActivityLogDbMapper activityLogDBMapper,
                             PaymentStatusUtil paymentStatusUtil) {

        super(accountsService,
                approvalsService,
                recurringUtil,
                dateUtil,
                paymentMapper,
                paymentDBMapper,
                transactionDBMapper,
                transactionEntryDBMapper,
                kafkaHostMapper,
                paymentKafkaHost,
                limitsService,
                countryRulesUtil,
                fetchManager,
                validateManager,
                createManager,
                editManager,
                activityLogDBMapper,
                paymentStatusUtil);

        this.paymentMapper = paymentMapper;
        this.transactionMapper = transactionMapper;
        this.kafkaHostMapper = kafkaHostMapper;
        this.banksService = banksService;
        this.fxService = fxService;
        this.dateUtil = dateUtil;
        this.amountCurrencyUtil = amountCurrencyUtil;
        this.countryRulesUtil = countryRulesUtil;
    }

    /**
     * Populate debit account bank details
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    public void populateBankDetails(RequestData<PaymentInitiationData> requestData) {
        banksService.populateDebitBankDetails(requestData.getGatewayContext(), requestData.getRequest(), true, SWIFT);
    }

    /**
     * @param requestData RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    @Override
    public void validatePayment(RequestData<PaymentInitiationData> requestData, String operation) throws PaymentServiceException {
        try {
            fxService.validate(requestData);
            amountCurrencyUtil.populateLimitAmount(requestData.getRequest());
        } catch (Exception e) {
            log.error("payment validation::{}, flow {}, error {}, {}", requestData.getRequest().getPaymentType(),
                    operation, e.getMessage(),
                    requestData.getGatewayContext().log());
            throw e;
        }
        super.validatePayment(requestData, operation);
    }

    /**
     * Validate request data for country specific rules
     *
     * @param context     PaymentContext
     * @param paymentData PaymentInitiationData
     * @param entryData   PaymentInitiationEntryData
     * @param ruleData    RuleData
     */
    @Override
    protected void validatePayment(PaymentContext context, PaymentInitiationData paymentData, PaymentInitiationEntryData entryData, RuleData ruleData) throws PaymentServiceException {
        String currency = entryData.getTransactionCcy();
        Map<String, GACHInfo> gachInfoMap = ruleData.getGACHInfo().stream()
                .collect(Collectors.toMap(GACHInfo::getCurrency, Function.identity()));
        countryRulesUtil.isGACHAllowed(context, ruleData);
        countryRulesUtil.validateGACHCurrency(context, gachInfoMap, currency);
        countryRulesUtil.validateGACHAmount(context, entryData, gachInfoMap, currency, paymentData.getTemplateId() > 0);
        countryRulesUtil.validateGACHPayeeAccount(context, entryData, gachInfoMap, currency);
        countryRulesUtil.validateGACHPayeeName(context, entryData, gachInfoMap, currency);
        countryRulesUtil.validateGACHLocalRouting(context, entryData, gachInfoMap, currency);
        countryRulesUtil.validateGACHPaymentPurpose(context, entryData, gachInfoMap, currency, ruleData.getPurposeOfPayment());
        countryRulesUtil.validateGACHRemittanceInfo(context, entryData, gachInfoMap, currency, paymentData.getTemplateId() > 0);
    }

    /**
     * Confirm fx quote and then create payment and transaction
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    public void createPayment(RequestData<PaymentInitiationData> requestData)
            throws PaymentServiceException {
        // book quote
        fxService.bookQuote(requestData);
        super.createPayment(requestData);
    }

    /**
     * Populate payment entry entity
     *
     * @param context          PaymentContext
     * @param paymentEntry     PaymentEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populatePaymentEntryEntity(PaymentContext context, PaymentEntryEntity paymentEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        super.populatePaymentEntryEntity(context, paymentEntry, paymentInitiationEntryData);

        // populate cross-currency data
        paymentMapper.mapPaymentEntryEntity(paymentEntry, paymentInitiationEntryData.getCrossCurrencyPaymentData());
        // check and populate OBO data
        if (paymentInitiationEntryData.getOboData() != null) {
            paymentMapper.mapPaymentEntryEntity(paymentEntry, paymentInitiationEntryData.getOboData());
        }
        // check and populate ISO data
        if (paymentInitiationEntryData.getIsoData() != null) {
            paymentMapper.mapPaymentEntryEntity(paymentEntry, paymentInitiationEntryData.getIsoData());
        }
        // populate dates
        if (paymentInitiationEntryData.getCrossCurrencyPaymentData().getValueDate() != null
                && !paymentInitiationEntryData.getCrossCurrencyPaymentData().getValueDate().isEmpty()) {
            // format date to keep it consistent (user-input or wss returned)
            paymentInitiationEntryData.setValueDate(dateUtil.getTimestamp(paymentInitiationEntryData.getNetworkTimeZone(), paymentInitiationEntryData.getCrossCurrencyPaymentData().getValueDate().replace("-", "") + CommonConstant.ZERO_TIME_COMPONENT, dateFormatterWSS));
            paymentEntry.setContractValueDate(paymentInitiationEntryData.getValueDate());
        }
        if (paymentInitiationEntryData.getCrossCurrencyPaymentData().getTradeDate() != null
                && !paymentInitiationEntryData.getCrossCurrencyPaymentData().getTradeDate().isEmpty()) {
            paymentInitiationEntryData.setTradeDate(dateUtil.getTimestamp(paymentInitiationEntryData.getNetworkTimeZone(), paymentInitiationEntryData.getCrossCurrencyPaymentData().getTradeDate().replace("-", "") + CommonConstant.ZERO_TIME_COMPONENT, dateFormatterWSS));
            paymentEntry.setContractTradeDate(paymentInitiationEntryData.getTradeDate());
        }
    }

    @Override
    public void approvePayment(RequestData<PaymentInitiationData> requestData)
            throws PaymentServiceException {
        // book quote
        fxService.bookQuote(requestData);
        super.approvePayment(requestData);
    }

    /**
     * Populate transaction entry entity
     *
     * @param context          PaymentContext
     * @param transactionEntry TransactionEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateTransactionEntryEntity(PaymentContext context, TransactionEntryEntity transactionEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        super.populateTransactionEntryEntity(context, transactionEntry, paymentInitiationEntryData);

        // populate cross-currency data
        transactionMapper.mapTransactionEntryEntity(transactionEntry, paymentInitiationEntryData.getCrossCurrencyPaymentData());
        // check and populate OBO data
        if (paymentInitiationEntryData.getOboData() != null) {
            transactionMapper.mapTransactionEntryEntity(transactionEntry, paymentInitiationEntryData.getOboData());
        }
        // check and populate ISO data
        if (paymentInitiationEntryData.getIsoData() != null) {
            transactionMapper.mapTransactionEntryEntity(transactionEntry, paymentInitiationEntryData.getIsoData());
        }
        // populate dates
        transactionEntry.setContractTradeDate(paymentInitiationEntryData.getTradeDate());
        transactionEntry.setContractValueDate(paymentInitiationEntryData.getValueDate());
        /* override debit amount
         * credit amount will always be transaction amount */
        transactionEntry.setDebitAmount(paymentInitiationEntryData.getDebitAccountData().getCcyAmt());
    }

    /**
     * Populate host message with cross-currency and IB details, txnType
     *
     * @param context     PaymentContext
     * @param message     ProcessingMessage
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateHostMessage(PaymentContext context, ProcessingMessage message, RequestData<PaymentInitiationData> requestData) {
        super.populateHostMessage(context, message, requestData);

        PaymentInitiationEntryData entryData = requestData.getRequest().getEntries().getFirst();
        message.getPaymentData().setCrossCurrencyPaymentData(new CrossCurrencyPaymentData());

        // set cross-currency data
        kafkaHostMapper.mapHostMessage(message.getPaymentData(), entryData.getCrossCurrencyPaymentData());
        if (entryData.getOboData() != null) {
            kafkaHostMapper.mapHostMessage(message.getPaymentData(), entryData.getOboData());
        }
        if (entryData.getIsoData() != null) {
            kafkaHostMapper.mapHostMessage(message.getPaymentData(), entryData.getIsoData());
        }
        // set formatted dates to host message
        message.getPaymentData().getCrossCurrencyPaymentData().setTradeDate(dateUtil.getTimestamp(entryData.getTradeDate(), entryData.getNetworkTimeZone(), dateFormatter));
        message.getPaymentData().getCrossCurrencyPaymentData().setValueDate(dateUtil.getTimestamp(entryData.getValueDate(), entryData.getNetworkTimeZone(), dateFormatter));
        // set formatted dates to back to business object
        entryData.getCrossCurrencyPaymentData().setValueDate(message.getPaymentData().getCrossCurrencyPaymentData().getValueDate());
        entryData.getCrossCurrencyPaymentData().setTradeDate(message.getPaymentData().getCrossCurrencyPaymentData().getTradeDate());

        message.getPaymentData().setTxnType(PaymentConstant.TXN_TRF);
    }

    /**
     * Populate host message with cross-currency and IB details, txnType
     *
     * @param context     PaymentContext
     * @param message     ProcessingSplitMessage
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateHostMessage(PaymentContext context, ProcessingSplitMessage message, RequestData<PaymentInitiationData> requestData) {
        super.populateHostMessage(context, message, requestData);

        long transactionId = requestData.getRequest().getTransactionId();

        for (PaymentInitiationEntryData entryData : requestData.getRequest().getEntries()) {
            PaymentProcessingData paymentData = message.getPaymentData().stream().
                    filter(p -> p.getRequestSerialNo().equals(entryData.getEntryNumber()))
                    .findFirst().orElse(null);
            if (paymentData != null) {
                paymentData.setCrossCurrencyPaymentData(new CrossCurrencyPaymentData());
                // set cross-currency data
                kafkaHostMapper.mapHostMessage(paymentData, entryData.getCrossCurrencyPaymentData());
                if (entryData.getOboData() != null) {
                    kafkaHostMapper.mapHostMessage(paymentData, entryData.getOboData());
                }
                if (entryData.getIsoData() != null) {
                    kafkaHostMapper.mapHostMessage(paymentData, entryData.getIsoData());
                }
                // set formatted dates to host message
                paymentData.getCrossCurrencyPaymentData().setValueDate(dateUtil.getTimestamp(entryData.getValueDate(), entryData.getNetworkTimeZone(), dateFormatter));
                paymentData.getCrossCurrencyPaymentData().setTradeDate(dateUtil.getTimestamp(entryData.getTradeDate(), entryData.getNetworkTimeZone(), dateFormatter));
                // set formatted dates to back to business object
                entryData.getCrossCurrencyPaymentData().setTradeDate(paymentData.getCrossCurrencyPaymentData().getTradeDate());
                entryData.getCrossCurrencyPaymentData().setValueDate(paymentData.getCrossCurrencyPaymentData().getValueDate());
                paymentData.setTxnType(PaymentConstant.TXN_TRF);
            }
        }
    }

    @Override
    protected void createRecurring(RequestData<PaymentInitiationData> requestData) {
        // no action
    }
}
