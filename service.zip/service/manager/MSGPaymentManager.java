package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.payment.WireType;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.mapper.db.ActivityLogDbMapper;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationEntryData;
import com.svb.gateway.payments.common.model.rulesengine.GACHInfo;
import com.svb.gateway.payments.common.model.rulesengine.RuleData;
import com.svb.gateway.payments.common.service.AccountsService;
import com.svb.gateway.payments.common.service.ApprovalsService;
import com.svb.gateway.payments.common.service.BanksService;
import com.svb.gateway.payments.common.util.AmountCurrencyUtil;
import com.svb.gateway.payments.common.util.CountryRulesUtil;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.payment.entity.PaymentEntity;
import com.svb.gateway.payments.payment.entity.PaymentEntryEntity;
import com.svb.gateway.payments.payment.entity.RecurrenceEntity;
import com.svb.gateway.payments.payment.entity.TransactionEntryEntity;
import com.svb.gateway.payments.payment.mapper.db.PaymentDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.RecurringDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.entity.PaymentMapper;
import com.svb.gateway.payments.payment.mapper.entity.RecurringMapper;
import com.svb.gateway.payments.payment.mapper.entity.TransactionMapper;
import com.svb.gateway.payments.payment.mapper.model.KafkaHostMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.service.LimitsService;
import com.svb.gateway.payments.payment.service.host.PaymentKafkaHost;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import com.svb.gateway.payments.payment.util.RecurringUtil;
import com.svb.gateway.payments.payment.validator.DataValidator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.svb.gateway.payments.common.constants.BankConfigConstant.SWIFT;

@Slf4j
@Service("MSG")
public class MSGPaymentManager extends PaymentManager {

    private final PaymentMapper paymentMapper;
    private final TransactionMapper transactionMapper;
    private final KafkaHostMapper kafkaHostMapper;
    private final BanksService banksService;
    private final DataValidator dataValidator;
    private final RecurringUtil recurringUtil;
    private final RecurringDBMapper recurringDBMapper;
    private final RecurringMapper recurringMapper;
    private final AmountCurrencyUtil amountCurrencyUtil;
    private final CountryRulesUtil countryRulesUtil;

    public MSGPaymentManager(AccountsService accountsService,
                             ApprovalsService approvalsService,
                             RecurringUtil recurringUtil,
                             DateUtil dateUtil,
                             RecurringMapper recurringMapper,
                             PaymentMapper paymentMapper,
                             TransactionMapper transactionMapper,
                             RecurringDBMapper recurringDBMapper,
                             PaymentDBMapper paymentDBMapper,
                             TransactionDBMapper transactionDBMapper,
                             TransactionEntryDBMapper transactionEntryDBMapper,
                             KafkaHostMapper kafkaHostMapper,
                             PaymentKafkaHost paymentKafkaHost,
                             BanksService banksService,
                             DataValidator dataValidator,
                             LimitsService limitsService,
                             AmountCurrencyUtil amountCurrencyUtil,
                             CountryRulesUtil countryRulesUtil,
                             PaymentManagerFetch fetchManager,
                             PaymentManagerValidate validateManager,
                             PaymentManagerCreate createManager,
                             PaymentManagerEdit editManager,
                             ActivityLogDbMapper activityLogDBMapper,
                             PaymentStatusUtil paymentStatusUtil) {

        super(accountsService,
                approvalsService,
                recurringUtil,
                dateUtil,
                paymentMapper,
                paymentDBMapper,
                transactionDBMapper,
                transactionEntryDBMapper,
                kafkaHostMapper,
                paymentKafkaHost,
                limitsService,
                countryRulesUtil,
                fetchManager,
                validateManager,
                createManager,
                editManager,
                activityLogDBMapper,
                paymentStatusUtil);

        this.paymentMapper = paymentMapper;
        this.banksService = banksService;
        this.dataValidator = dataValidator;
        this.recurringUtil = recurringUtil;
        this.recurringDBMapper = recurringDBMapper;
        this.recurringMapper = recurringMapper;
        this.amountCurrencyUtil = amountCurrencyUtil;
        this.countryRulesUtil = countryRulesUtil;
        this.transactionMapper = transactionMapper;
        this.kafkaHostMapper = kafkaHostMapper;
    }

    /**
     * Populate debit account bank details
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    public void populateBankDetails(RequestData<PaymentInitiationData> requestData) {
        banksService.populateDebitBankDetails(requestData.getGatewayContext(), requestData.getRequest(), true, SWIFT);
    }

    @Override
    public PaymentInitiationData populatePayment(long paymentId, String clientId) throws PaymentServiceException {
        PaymentInitiationData data = super.populatePayment(paymentId, clientId);
        if (data.getRecurringData().isRecurring()) {
            // get existing entry
            RecurrenceEntity recurring = recurringDBMapper.getRecurrence(data.getRecurringData().getRecurrenceId());
            recurringMapper.mapRecurringServiceObject(data.getRecurringData(), recurring);
        }
        return data;
    }

    /**
     * Validate request data
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    @Override
    public void validatePayment(RequestData<PaymentInitiationData> requestData, String operation) throws PaymentServiceException {
        amountCurrencyUtil.populateLimitAmount(requestData.getRequest());
        super.validatePayment(requestData, operation);
    }

    /**
     * Validate request data for edit flow
     *
     * @param requestData     RequestData<PaymentInitiationData>
     * @param existingPayment PaymentInitiationData
     * @throws PaymentServiceException e
     */
    @Override
    protected void validatePayment(RequestData<PaymentInitiationData> requestData, PaymentInitiationData existingPayment) throws PaymentServiceException {
        super.validatePayment(requestData, existingPayment);
        dataValidator.validatePayee(requestData.getRequest(), existingPayment);
        validateRecurring(requestData, existingPayment);
    }

    private void validateRecurring(RequestData<PaymentInitiationData> requestData, PaymentInitiationData existingPayment) throws PaymentServiceException {
        if (!requestData.getRequest().getRecurringData().isRecurring()) {
            return;
        }
        dataValidator.validateRecurringData(requestData.getRequest(), existingPayment);
        recurringUtil.populateRecurringDetails(requestData, existingPayment.getNextPaymentDate(), existingPayment.getRecurringData().getProcessedInstances());
    }

    /**
     * Validate request data for country specific rules
     *
     * @param context     PaymentContext
     * @param paymentData PaymentInitiationData
     * @param entryData   PaymentInitiationEntryData
     * @param ruleData    RuleData
     */
    @Override
    protected void validatePayment(PaymentContext context, PaymentInitiationData paymentData, PaymentInitiationEntryData entryData, RuleData ruleData) throws PaymentServiceException {
        String currency = entryData.getDebitAccountData().getAccCcy().toString();
        Map<String, GACHInfo> gachInfoMap = ruleData.getGACHInfo().stream()
                .collect(Collectors.toMap(GACHInfo::getCurrency, Function.identity()));
        countryRulesUtil.isGACHAllowed(context, ruleData);
        countryRulesUtil.validateGACHCurrency(context, gachInfoMap, currency);
        countryRulesUtil.validateGACHPayeeAccount(context, entryData, gachInfoMap, currency);
        countryRulesUtil.validateGACHAmount(context, entryData, gachInfoMap, currency, paymentData.getTemplateId() > 0);
        countryRulesUtil.validateGACHPayeeName(context, entryData, gachInfoMap, currency);
        countryRulesUtil.validateGACHLocalRouting(context, entryData, gachInfoMap, currency);
        countryRulesUtil.validateGACHPaymentPurpose(context, entryData, gachInfoMap, currency, ruleData.getPurposeOfPayment());
        countryRulesUtil.validateGACHRemittanceInfo(context, entryData, gachInfoMap, currency, paymentData.getTemplateId() > 0);
    }

    /***
     * Populate payment entity and then recurring details
     * @param context     PaymentContext
     * @param payment     PaymentEntity
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populatePaymentEntity(PaymentContext context, PaymentEntity payment, RequestData<PaymentInitiationData> requestData) {
        super.populatePaymentEntity(context, payment, requestData);

        paymentMapper.mapPaymentEntity(payment, requestData.getRequest().getRecurringData());
        // override payment date
        if (requestData.getRequest().getRecurringData().isRecurring()) {
            payment.setPaymentDate(requestData.getRequest().getNextPaymentDate());
        }
    }

    /**
     * Populate payment entry
     *
     * @param context          PaymentContext
     * @param paymentEntry     PaymentEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populatePaymentEntryEntity(PaymentContext context, PaymentEntryEntity paymentEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        super.populatePaymentEntryEntity(context, paymentEntry, paymentInitiationEntryData);

        // check and populate OBO data
        if (paymentInitiationEntryData.getOboData() != null) {
            paymentMapper.mapPaymentEntryEntity(paymentEntry, paymentInitiationEntryData.getOboData());
        }
        // check and populate ISO data
        if (paymentInitiationEntryData.getIsoData() != null) {
            paymentMapper.mapPaymentEntryEntity(paymentEntry, paymentInitiationEntryData.getIsoData());
        }
    }

    /**
     * Populate transaction entry
     *
     * @param context          PaymentContext
     * @param transactionEntry TransactionEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateTransactionEntryEntity(PaymentContext context, TransactionEntryEntity transactionEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        super.populateTransactionEntryEntity(context, transactionEntry, paymentInitiationEntryData);

        // check and populate OBO data
        if (paymentInitiationEntryData.getOboData() != null) {
            transactionMapper.mapTransactionEntryEntity(transactionEntry, paymentInitiationEntryData.getOboData());
        }
        // check and populate ISO data
        if (paymentInitiationEntryData.getIsoData() != null) {
            transactionMapper.mapTransactionEntryEntity(transactionEntry, paymentInitiationEntryData.getIsoData());
        }
    }

    /**
     * Populate host message, txnType and wireType
     *
     * @param context     PaymentContext
     * @param message     ProcessingMessage
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateHostMessage(PaymentContext context, ProcessingMessage message, RequestData<PaymentInitiationData> requestData) {
        super.populateHostMessage(context, message, requestData);
        PaymentInitiationEntryData entryData = requestData.getRequest().getEntries().getFirst();
        if (entryData.getOboData() != null) {
            kafkaHostMapper.mapHostMessage(message.getPaymentData(), entryData.getOboData());
        }
        if (entryData.getIsoData() != null) {
            kafkaHostMapper.mapHostMessage(message.getPaymentData(), entryData.getIsoData());
        }
        message.getPaymentData().setTxnType(PaymentConstant.TXN_TRF);
        message.getPaymentData().setWireType(WireType.MCA);
    }
}