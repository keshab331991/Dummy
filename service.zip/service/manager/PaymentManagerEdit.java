package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.payment.PaymentStatus;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.RecurringData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.payment.entity.PaymentEntity;
import com.svb.gateway.payments.payment.entity.PaymentEntryEntity;
import com.svb.gateway.payments.payment.entity.RecurrenceEntity;
import com.svb.gateway.payments.payment.mapper.db.PaymentEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.db.RecurringDBMapper;
import com.svb.gateway.payments.payment.mapper.entity.RecurringMapper;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.Optional;

@Service
public class PaymentManagerEdit {

    private final RecurringMapper recurringMapper;
    private final RecurringDBMapper recurringDBMapper;
    private final PaymentStatusUtil paymentStatusUtil;
    private final PaymentEntryDBMapper paymentEntryDBMapper;
    private final DateUtil dateUtil;

    public PaymentManagerEdit(RecurringMapper recurringMapper,
                              RecurringDBMapper recurringDBMapper,
                              PaymentStatusUtil paymentStatusUtil,
                              PaymentEntryDBMapper paymentEntryDBMapper,
                              DateUtil dateUtil) {
        this.recurringMapper = recurringMapper;
        this.recurringDBMapper = recurringDBMapper;
        this.paymentStatusUtil = paymentStatusUtil;
        this.paymentEntryDBMapper = paymentEntryDBMapper;
        this.dateUtil = dateUtil;
    }

    /**
     * Edit recurring entry
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    protected void editRecurring(RequestData<PaymentInitiationData> requestData) {
        // populate recurring entity
        RecurrenceEntity recurring = new RecurrenceEntity();
        recurringMapper.mapRecurringEntity(recurring, requestData.getRequest());
        // update
        recurringDBMapper.editRecurrence(recurring);
    }

    /**
     * Edit processed instances for recurring
     *
     * @param recurringId        long
     * @param processedInstances int
     */
    protected void editRecurring(long recurringId, int processedInstances) {
        // update
        recurringDBMapper.editProcessedInstances(recurringId, processedInstances);
    }

    /**
     * Edit payment
     * -    If a payment has recurring details with a single instance flag, a new payment gets created, and existing series updated
     * -    Else it's edit payment with creation transaction (if criteria satisfied)
     *
     * @param requestData RequestData<PaymentInitiationData>
     */

    public void updatePaymentForEdit(RequestData<PaymentInitiationData> requestData, PaymentEntity payment) {
        boolean isRecurring = Optional.ofNullable(requestData.getRequest().getRecurringData()).map(RecurringData::isRecurring).orElse(false);
        if (requestData.getRequest().getRecurringData() != null && isRecurring) {
            // update recurring
            editRecurring(requestData);
        }
        // update into database
        paymentStatusUtil.updatePayment(payment, false);
        // update request
        requestData.getRequest().setPaymentStatus(PaymentStatus.valueOf(payment.getStatus()));
        requestData.getRequest().getMetaInfo().setUpdatedAt(Optional.ofNullable(payment.getUpdatedTimestamp()).map(Timestamp::toString).orElse(""));
    }

    /**
     * Edit payment entry
     *
     * @param requestData  RequestData<PaymentInitiationData>
     * @param paymentEntry PaymentEntryEntity
     */
    protected void editPaymentEntry(RequestData<PaymentInitiationData> requestData, PaymentEntryEntity paymentEntry) {
        Timestamp now = dateUtil.getApplicationTimestamp();

        paymentEntry.setUpdatedTimestamp(now);
        paymentEntry.setPaymentId(requestData.getRequest().getPaymentId());
        // update into database
        paymentEntryDBMapper.updatePaymentEntry(paymentEntry);
    }

    /**
     * Edit payment series
     * -    processed instances for existing series will get updated
     * -    next payment date of existing series will get updated
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @param context     PaymentContext
     */
    protected void editPaymentSeries(RequestData<PaymentInitiationData> requestData, PaymentContext context) {
        long paymentId = requestData.getRequest().getPaymentId();
        long recurrenceId = requestData.getRequest().getRecurringData().getRecurrenceId();
        int processedInstances = requestData.getRequest().getRecurringData().getProcessedInstances();
        int totalInstances = requestData.getRequest().getRecurringData().getTotalInstances();
        Timestamp nextPaymentDate = requestData.getRequest().getNextPaymentDate();
        /* update recurring data
         * for processed instances */
        editRecurring(recurrenceId, processedInstances);
        /* update recurring series
         * for the next payment date (and status)*/
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setPaymentId(paymentId);
        paymentEntity.setUserId(context.getUserId());
        if (processedInstances == totalInstances) {
            paymentEntity.setStatus(PaymentStatus.SCMP.toString());
        } else {
            paymentEntity.setPaymentDate(nextPaymentDate);
        }
        paymentStatusUtil.updatePayment(paymentEntity, false);
    }
}
