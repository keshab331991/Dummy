package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.payment.WireType;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.mapper.db.ActivityLogDbMapper;
import com.svb.gateway.payments.common.model.Address;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationEntryData;
import com.svb.gateway.payments.common.service.AccountsService;
import com.svb.gateway.payments.common.service.ApprovalsService;
import com.svb.gateway.payments.common.service.BanksService;
import com.svb.gateway.payments.common.util.CountryRulesUtil;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.payment.entity.PaymentEntryEntity;
import com.svb.gateway.payments.payment.entity.TransactionEntryEntity;
import com.svb.gateway.payments.payment.mapper.db.PaymentDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.entity.PaymentMapper;
import com.svb.gateway.payments.payment.mapper.entity.TransactionMapper;
import com.svb.gateway.payments.payment.mapper.model.KafkaHostMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.service.LimitsService;
import com.svb.gateway.payments.payment.service.host.PaymentKafkaHost;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import com.svb.gateway.payments.payment.util.RecurringUtil;
import com.svb.gateway.payments.payment.validator.DataValidator;
import org.springframework.stereotype.Service;

import static com.svb.gateway.payments.common.constants.BankConfigConstant.ABA;

@Service("FET")
public class FETPaymentManager extends PaymentManager {

    private final BanksService banksService;
    private final DataValidator dataValidator;
    private final PaymentMapper paymentMapper;
    private final TransactionMapper transactionMapper;
    private final KafkaHostMapper kafkaHostMapper;

    public FETPaymentManager(AccountsService accountsService,
                             ApprovalsService approvalsService,
                             RecurringUtil recurringUtil,
                             DateUtil dateUtil,
                             PaymentMapper paymentMapper,
                             TransactionMapper transactionMapper,
                             PaymentDBMapper paymentDBMapper,
                             TransactionDBMapper transactionDBMapper,
                             TransactionEntryDBMapper transactionEntryDBMapper,
                             KafkaHostMapper kafkaHostMapper,
                             PaymentKafkaHost paymentKafkaHost,
                             BanksService banksService,
                             DataValidator dataValidator,
                             LimitsService limitsService,
                             CountryRulesUtil countryRulesUtil,
                             PaymentManagerFetch fetchManager,
                             PaymentManagerValidate validateManager,
                             PaymentManagerCreate createManager,
                             PaymentManagerEdit editManager,
                             ActivityLogDbMapper activityLogDBMapper,
                             PaymentStatusUtil paymentStatusUtil) {

        super(accountsService,
                approvalsService,
                recurringUtil,
                dateUtil,
                paymentMapper,
                paymentDBMapper,
                transactionDBMapper,
                transactionEntryDBMapper,
                kafkaHostMapper,
                paymentKafkaHost,
                limitsService,
                countryRulesUtil,
                fetchManager,
                validateManager,
                createManager,
                editManager,
                activityLogDBMapper,
                paymentStatusUtil);

        this.banksService = banksService;
        this.dataValidator = dataValidator;
        this.paymentMapper = paymentMapper;
        this.transactionMapper = transactionMapper;
        this.kafkaHostMapper = kafkaHostMapper;
    }

    /**
     * Populate debit account bank details
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    public void populateBankDetails(RequestData<PaymentInitiationData> requestData) {
        banksService.populateDebitBankDetails(requestData.getGatewayContext(), requestData.getRequest(), true, ABA);
    }

    /**
     * Populate payment entry
     *
     * @param context          PaymentContext
     * @param paymentEntry     PaymentEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populatePaymentEntryEntity(PaymentContext context, PaymentEntryEntity paymentEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        super.populatePaymentEntryEntity(context, paymentEntry, paymentInitiationEntryData);
        // populate tax details
        paymentMapper.mapPaymentEntryEntity(paymentEntry, paymentInitiationEntryData.getTaxPayDetails());
        // check and populate OBO data
        if (paymentInitiationEntryData.getOboData() != null) {
            paymentMapper.mapPaymentEntryEntity(paymentEntry, paymentInitiationEntryData.getOboData());
        }
        // check and populate ISO data
        if (paymentInitiationEntryData.getIsoData() != null) {
            paymentMapper.mapPaymentEntryEntity(paymentEntry, paymentInitiationEntryData.getIsoData());
        }
    }

    /**
     * Populate transaction entry
     *
     * @param context          PaymentContext
     * @param transactionEntry TransactionEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateTransactionEntryEntity(PaymentContext context, TransactionEntryEntity transactionEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        super.populateTransactionEntryEntity(context, transactionEntry, paymentInitiationEntryData);

        // populate tax details
        transactionMapper.mapTransactionEntryEntity(transactionEntry, paymentInitiationEntryData.getTaxPayDetails());
        // check and populate OBO data
        if (paymentInitiationEntryData.getOboData() != null) {
            transactionMapper.mapTransactionEntryEntity(transactionEntry, paymentInitiationEntryData.getOboData());
        }
        // check and populate ISO data
        if (paymentInitiationEntryData.getIsoData() != null) {
            transactionMapper.mapTransactionEntryEntity(transactionEntry, paymentInitiationEntryData.getIsoData());
        }
    }

    /**
     * Populate host message with txnType and wireType
     *
     * @param context     PaymentContext
     * @param message     ProcessingMessage
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateHostMessage(PaymentContext context, ProcessingMessage message, RequestData<PaymentInitiationData> requestData) {
        super.populateHostMessage(context, message, requestData);

        // FET is not eligible for split, hence there will always be single entry
        PaymentInitiationEntryData entryData = requestData.getRequest().getEntries().getFirst();
        kafkaHostMapper.mapHostMessage(message.getPaymentData(), entryData.getTaxPayDetails());
        if (entryData.getOboData() != null) {
            kafkaHostMapper.mapHostMessage(message.getPaymentData(), entryData.getOboData());
        }
        if (entryData.getIsoData() != null) {
            kafkaHostMapper.mapHostMessage(message.getPaymentData(), entryData.getIsoData());
        }
        // Creditor address for FET needs to be blank
        updateCreditorAddress(message);
        // populate end to end id
        message.getPaymentData().setEndToEndId(entryData.getIsoData() != null ? entryData.getIsoData().getEndToEndId() : null);
        message.getPaymentData().setTxnType(PaymentConstant.TXN_TRF);
        message.getPaymentData().setWireType(WireType.USD);
    }

    @Override
    protected void validatePayment(RequestData<PaymentInitiationData> requestData, PaymentInitiationData existingPayment) throws PaymentServiceException {
        super.validatePayment(requestData, existingPayment);
        dataValidator.validatePayee(requestData.getRequest(), existingPayment);
    }

    private void updateCreditorAddress(ProcessingMessage message) {
        Address address = new Address();
        address.setAddLine1("");
        address.setAddLine2("");
        address.setCity("");
        address.setState("");
        address.setCountry("");
        address.setZip("");
        if (message.getPaymentData().getCreditorData() != null) {
            message.getPaymentData().getCreditorData().setAddress(address);
        }
    }
}
