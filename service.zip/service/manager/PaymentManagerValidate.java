package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.ErrorCodeEnum;
import com.svb.gateway.payments.common.enums.Mode;
import com.svb.gateway.payments.common.enums.payment.PaymentStatus;
import com.svb.gateway.payments.common.enums.payment.TransactionStatus;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.PaymentStatusDetails;
import com.svb.gateway.payments.common.model.payment.UpdatePaymentStatusRequest;
import com.svb.gateway.payments.common.model.payment.cancellation.PaymentCancellationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.util.AmountCurrencyUtil;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.common.validator.FilterValidator;
import com.svb.gateway.payments.payment.entity.PaymentEntity;
import com.svb.gateway.payments.payment.entity.TransactionEntity;
import com.svb.gateway.payments.payment.mapper.db.PaymentDBMapper;
import com.svb.gateway.payments.payment.service.LimitsService;
import com.svb.gateway.payments.payment.util.RecurringUtil;
import com.svb.gateway.payments.payment.validator.DataValidator;
import com.svb.gateway.payments.payment.validator.DateValidator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;

@Slf4j
@Service
public class PaymentManagerValidate {

    private final DateUtil dateUtil;
    private final DataValidator dataValidator;
    private final FilterValidator filterValidator;
    private final DateValidator dateValidator;
    private final RecurringUtil recurringUtil;
    private final LimitsService limitsService;
    private final AmountCurrencyUtil amountCurrencyUtil;
    private final PaymentDBMapper paymentDBMapper;
    private final PaymentManagerFetch fetchManager;

    public PaymentManagerValidate(DateUtil dateUtil,
                                  DataValidator dataValidator,
                                  FilterValidator filterValidator,
                                  DateValidator dateValidator,
                                  RecurringUtil recurringUtil,
                                  LimitsService limitsService,
                                  AmountCurrencyUtil amountCurrencyUtil,
                                  PaymentDBMapper paymentDBMapper,
                                  PaymentManagerFetch fetchManager) {
        this.dateUtil = dateUtil;
        this.dataValidator = dataValidator;
        this.filterValidator = filterValidator;
        this.dateValidator = dateValidator;
        this.recurringUtil = recurringUtil;
        this.limitsService = limitsService;
        this.amountCurrencyUtil = amountCurrencyUtil;
        this.paymentDBMapper = paymentDBMapper;
        this.fetchManager = fetchManager;
    }

    /**
     * Validate request data for update status flow
     *
     * @param request UpdatePaymentStatusRequest
     * @param context PaymentContext
     * @throws PaymentServiceException e
     */
    protected void validatePayment(UpdatePaymentStatusRequest request, PaymentContext context, boolean updateAllowed, List<String> allowedTransactionStatus) throws PaymentServiceException {
        if (!updateAllowed) {
            throw new PaymentServiceException(ErrorCodeEnum.PAYMENT_STATUS_UPDATE_ERROR, "Transaction status update not allowed for the payment type");
        }

        for (PaymentStatusDetails data : request.getPaymentData()) {
            TransactionEntity transaction = fetchManager.fetchTransaction(data.getTransactionId(), 0L, null, request.getPaymentType().toString());
            data.setPaymentId(transaction.getPaymentId());

            if (transaction.getStatus() !=null && !allowedTransactionStatus.contains(transaction.getStatus())) {
                throw new PaymentServiceException(100, ErrorCodeEnum.PAYMENT_STATUS_UPDATE_ERROR,
                        String.format("Transaction id %s having status %s can not be updated",
                                transaction.getTransactionId(), transaction.getStatus()));
            }
        }
    }

    /**
     * Validate request data for cancel flow
     *
     * @param requestData PaymentCancellationData
     * @param context     PaymentContext
     * @throws PaymentServiceException e
     */
    protected void validatePayment(PaymentCancellationData requestData, PaymentContext context, List<String> allowedPaymentStatus, List<String> allowedTransactionStatus) throws PaymentServiceException {
        PaymentEntity payment = fetchManager.fetchPayment(requestData.getPaymentId(), context.getClientId(), requestData.getPaymentType().toString());

        if (!payment.getPaymentType().equals(requestData.getPaymentType().toString())) {
            throw new PaymentServiceException(101, ErrorCodeEnum.PAYMENT_CANCELLATION_ERROR,
                    String.format("Payment id %s is not %s",
                            payment.getPaymentId(), requestData.getPaymentType()));
        }

        if (!allowedPaymentStatus.contains(payment.getStatus())) {
            throw new PaymentServiceException(101, ErrorCodeEnum.PAYMENT_CANCELLATION_ERROR,
                    String.format("Payment id %s having status %s can not be cancelled",
                            payment.getPaymentId(), payment.getStatus()));
        }

        boolean isRecurring = (payment.getRecurring() != null && 'Y' == payment.getRecurring());
        requestData.setRecurring(isRecurring);
        requestData.setSingleInstance(isRecurring && requestData.isSingleInstance());

        if (requestData.getTransactionId() > 0) {
            TransactionEntity transaction = fetchManager.fetchTransaction(requestData.getTransactionId(), requestData.getPaymentId(), context.getClientId(), requestData.getPaymentType().toString());
            if (!allowedTransactionStatus.contains(transaction.getStatus())) {
                throw new PaymentServiceException(102, ErrorCodeEnum.PAYMENT_CANCELLATION_ERROR,
                        String.format("Transaction id %s having status %s can not be cancelled",
                                transaction.getTransactionId(), transaction.getStatus()));
            }

            requestData.setTransactionStatus(TransactionStatus.fromValue(transaction.getStatus()));
        } else if (payment.getStatus().equals(PaymentStatus.ACMP.toString())
                && payment.getPaymentDate().before(Timestamp.valueOf(dateUtil.getStartOfDayDateTime()))) {
            throw new PaymentServiceException(ErrorCodeEnum.PAYMENT_CANCELLATION_ERROR,
                    String.format("Payment id %s is past-dated and can not be cancelled", payment.getPaymentId()));
        }
    }

    /**
     * Validate request data for edit flow
     *
     * @param requestData     RequestData<PaymentInitiationData>
     * @param existingPayment PaymentInitiationData
     * @throws PaymentServiceException e
     */
    protected void validatePayment(RequestData<PaymentInitiationData> requestData,
                                   PaymentInitiationData existingPayment,
                                   List<String> allowedPaymentStatus) throws PaymentServiceException {
        PaymentInitiationData newPayment = requestData.getRequest();

        if (!allowedPaymentStatus.contains(existingPayment.getPaymentStatus().toString())) {
            throw new PaymentServiceException(1002, ErrorCodeEnum.INVALID_PAYMENT_REQUEST_FOR_EDIT,
                    String.format("payment id %s having status %s can not be edited",
                            existingPayment.getPaymentId(), existingPayment.getPaymentStatus()));
        }
        dataValidator.validatePaymentType(newPayment, existingPayment);
        dataValidator.validateRecurring(newPayment, existingPayment);
        dataValidator.validatePaymentCategory(newPayment, existingPayment);
        // reset meta info
        requestData.getRequest().setMetaInfo(existingPayment.getMetaInfo());
    }

    /**
     * Validate request data
     * - payment type filter validation
     * - date validation for past-date, holiday and cut-off
     * - recurring config validation
     * - amount-currency validation like max amount and decimal places
     * - if edit flow, validate with existing payment
     * - limit validation (and consumption if create mode)
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @param operation   String
     * @throws PaymentServiceException ex
     */
    protected void validatePayment(RequestData<PaymentInitiationData> requestData,
                                   String operation) throws PaymentServiceException {
        filterValidator.validate(requestData);
        dateValidator.processDate(requestData);
        recurringUtil.validateData(requestData);
        amountCurrencyUtil.validate(requestData.getRequest(), (PaymentContext) requestData.getGatewayContext());
        // generate payment id
        if (requestData.getGatewayContext().getMode().equals(Mode.CREATE)
                && requestData.getRequest().getPaymentId() == 0) {
            requestData.getRequest().setPaymentId(paymentDBMapper.getNextPaymentId());
        }
        validatePaymentForLimits(requestData, operation);
    }

    private void validatePaymentForLimits(RequestData<PaymentInitiationData> requestData, String operation) throws PaymentServiceException {
        if (List.of(CommonConstant.OPERATION_CREATE, CommonConstant.OPERATION_UPDATE)
                .contains(operation)) {
            limitsService.process((PaymentContext) requestData.getGatewayContext(), requestData.getRequest());
        }
    }

    /**
     * Validate and move payment date according to holidays and cut-off
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    protected void validatePaymentForDate(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        dateValidator.processDate(requestData);
    }

    public void validatePaymentForStatus(RequestData<PaymentInitiationData> requestData, PaymentStatus newPaymentStatus) throws PaymentServiceException {
        boolean isValid;
        PaymentStatus paymentStatus = requestData.getRequest().getPaymentStatus();
        isValid = switch (newPaymentStatus) {
            case REJC, ACMP, CURP, SCAN ->
                    paymentStatus.equals(PaymentStatus.PNAP) || paymentStatus.equals(PaymentStatus.PNFA);
            case PNAP, PNFA -> paymentStatus.equals(PaymentStatus.PNAP);
            default -> false;
        };
        if (!isValid) {
            throw new PaymentServiceException(100, ErrorCodeEnum.PAYMENT_STATUS_INVALID,
                    String.format("Payment id %s having status %s is not eligible for status %s",
                            requestData.getRequest().getPaymentId(), requestData.getRequest().getPaymentStatus(), newPaymentStatus));
        }
    }
}
