package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.audit.constant.PaymentAuditConstant;
import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.ErrorCodeEnum;
import com.svb.gateway.payments.common.enums.payee.PaymentTransaction;
import com.svb.gateway.payments.common.enums.payment.*;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.*;
import com.svb.gateway.payments.common.model.payment.cancellation.PaymentCancellationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationEntryData;
import com.svb.gateway.payments.common.service.PayeeIntegrationService;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.payment.entity.*;
import com.svb.gateway.payments.payment.mapper.db.PaymentDBMapper;
import com.svb.gateway.payments.payment.mapper.db.PaymentEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.entity.PaymentDetailMapper;
import com.svb.gateway.payments.payment.mapper.entity.PaymentMapper;
import com.svb.gateway.payments.payment.mapper.entity.TransactionMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class PaymentManagerFetch {

    private final PaymentMapper paymentMapper;
    private final PaymentDBMapper paymentDBMapper;
    private final PaymentEntryDBMapper paymentEntryDBMapper;
    private final TransactionMapper transactionMapper;
    private final TransactionDBMapper transactionDBMapper;
    private final PaymentDetailMapper paymentDetailMapper;
    private final PayeeIntegrationService payeesService;
    private final DateUtil dateUtil;

    final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    final DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    public PaymentManagerFetch(PaymentMapper paymentMapper,
                               PaymentDBMapper paymentDBMapper,
                               PaymentEntryDBMapper paymentEntryDBMapper,
                               TransactionMapper transactionMapper,
                               TransactionDBMapper transactionDBMapper,
                               PaymentDetailMapper paymentDetailMapper,
                               PayeeIntegrationService payeesService,
                               DateUtil dateUtil) {
        this.paymentMapper = paymentMapper;
        this.paymentDBMapper = paymentDBMapper;
        this.paymentEntryDBMapper = paymentEntryDBMapper;
        this.transactionMapper = transactionMapper;
        this.transactionDBMapper = transactionDBMapper;
        this.paymentDetailMapper = paymentDetailMapper;
        this.payeesService = payeesService;
        this.dateUtil = dateUtil;
    }

    /*populate start*/

    /**
     * Populate payment entity
     *
     * @param context     PaymentContext
     * @param payment     PaymentEntity
     * @param requestData RequestData<PaymentInitiationData>
     */
    protected void populatePaymentEntity(PaymentContext context, PaymentEntity payment, RequestData<PaymentInitiationData> requestData) {
        paymentMapper.mapPaymentEntity(payment, requestData.getRequest());
        paymentMapper.mapPaymentEntity(payment, context.getCommonHeaders());
        // reset auto-populated
        payment.setClientName(null);

        // populate payment status
        if (payment.getStatus() == null
                || payment.getStatus().isBlank()) {
            payment.setStatus(context.isApprovalFlag() ? PaymentStatus.CRTD.toString()
                    : (requestData.getRequest().isHold() || requestData.getRequest().getRecurringData().isRecurring()) ? PaymentStatus.ACMP.toString()
                    : PaymentStatus.COMP.toString());
        }

        // set additional details
        payment.setClientId(context.getClientId());
        payment.setUserId(context.getUserId());
    }

    /**
     * Populate payment entry entity
     *
     * @param context                    PaymentContext
     * @param paymentEntry               PaymentEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    protected void populatePaymentEntryEntity(PaymentContext context, PaymentEntryEntity paymentEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        if (paymentInitiationEntryData.getDebitAccountData().getCcyAmt() == null
                || paymentInitiationEntryData.getDebitAccountData().getCcyAmt() == 0) {
            paymentInitiationEntryData.getDebitAccountData().setCcyAmt(paymentInitiationEntryData.getTransactionAmt());
        }
        paymentMapper.mapPaymentEntryEntity(paymentEntry, paymentInitiationEntryData);

        // populate more data
        paymentEntry.setCreatedBy(context.getUserId());
        paymentEntry.setUpdatedBy(context.getUserId());
    }

    /**
     * Populate transaction entity
     *
     * @param context     PaymentContext
     * @param transaction TransactionEntity
     * @param requestData RequestData<PaymentInitiationData>
     */
    protected void populateTransactionEntity(PaymentContext context, TransactionEntity transaction, RequestData<PaymentInitiationData> requestData) {
        transactionMapper.mapTransactionEntity(transaction, requestData.getRequest());
        transactionMapper.mapTransactionEntity(transaction, context.getCommonHeaders());

        // populate payment status
        transaction.setStatus(TransactionStatus.INPR.toString());

        Timestamp now = dateUtil.getApplicationTimestamp();
        // set additional details
        transaction.setCreatedTimestamp(now);
        transaction.setUpdatedTimestamp(now);
        transaction.setClientId(context.getClientId());
        transaction.setUserId(context.getUserId());
    }

    /**
     * Populate transaction entry entity
     *
     * @param context          PaymentContext
     * @param transactionEntry TransactionEntryEntity
     * @param entry            RequestData<PaymentInitiationData>
     */
    protected void populateTransactionEntryEntity(PaymentContext context, TransactionEntryEntity transactionEntry, PaymentInitiationEntryData entry) {
        transactionMapper.mapTransactionEntryEntity(transactionEntry, entry);

        transactionEntry.setCreatedBy(context.getUserId());
        transactionEntry.setUpdatedBy(context.getUserId());
    }
    /*populate end*/

    /**
     * Fetch payment from a database
     *
     * @param paymentId   long
     * @param clientId    String
     * @param paymentType String
     * @return PaymentEntity
     * @throws PaymentServiceException e
     */
    protected PaymentEntity fetchPayment(long paymentId, String clientId, String paymentType) throws PaymentServiceException {
        PaymentEntity payment = paymentDBMapper.getPaymentById(paymentId);
        if (payment == null || !payment.getClientId().equals(clientId)) {
            throw new PaymentServiceException(1000, ErrorCodeEnum.PAYMENT_NOT_FOUND,
                    String.format("Payment id %s not found for client %s", paymentId, clientId));
        }

        if (paymentType != null && !payment.getPaymentType().equals(paymentType)) {
            throw new PaymentServiceException(1001, ErrorCodeEnum.PAYMENT_NOT_FOUND,
                    String.format("Payment id %s not found for client %s for payment type %s", paymentId, clientId, paymentType));
        }

        return payment;
    }

    protected List<PaymentEntryEntity> fetchPaymentEntry(long paymentId) {
        return paymentEntryDBMapper.getPaymentEntries(paymentId);
    }

    /**
     * Fetch transaction from a database
     *
     * @param transactionId long
     * @param paymentId     long
     * @param clientId      String
     * @param paymentType   String
     * @return TransactionEntity
     * @throws PaymentServiceException e
     */
    protected TransactionEntity fetchTransaction(Long transactionId, Long paymentId, String clientId, String paymentType) throws PaymentServiceException {
        TransactionEntity transaction = transactionDBMapper.getTransactionById(transactionId);

        if (transaction == null) {
            throw new PaymentServiceException(ErrorCodeEnum.PAYMENT_NOT_FOUND,
                    String.format("Transaction id %s not found", transactionId));
        }

        if (clientId != null && !transaction.getClientId().equals(clientId)) {
            throw new PaymentServiceException(ErrorCodeEnum.PAYMENT_NOT_FOUND,
                    String.format("Transaction id %s not found for client %s", transactionId, clientId));
        }

        if (paymentId > 0 && transaction.getPaymentId() != paymentId) {
            throw new PaymentServiceException(ErrorCodeEnum.PAYMENT_NOT_FOUND,
                    String.format("Transaction id %s not found for payment id %s", transactionId, paymentId));
        }

        if (paymentType != null && !transaction.getPaymentType().equals(paymentType)) {
            throw new PaymentServiceException(ErrorCodeEnum.PAYMENT_NOT_FOUND,
                    String.format("Transaction id %s not found for payment type %s", transactionId, paymentType));
        }
        return transaction;
    }

    /**
     * Populate data for next payment instance in recurring series
     *
     * @param payment      PaymentInitiationData
     */
    protected void updatePaymentForNextInstance(PaymentInitiationData payment) {
        int currentInstance = payment.getRecurringData().getSeriesNumber();
        // update request data for next payment instance
        payment.setRequestDate(payment.getPaymentDate());
        payment.setRecurringData(new RecurringData());
        payment.getRecurringData().setRecurring(false);
        payment.setNextPaymentDate(null);

        payment.getRecurringData().setSeriesId(payment.getPaymentId());
        payment.getRecurringData().setSeriesNumber(currentInstance);
        payment.setEndDate(null);
    }

    /**
     * Retrieve payment (and\or transaction) details from a database
     *
     * @param clientId      String
     * @param paymentId     long
     * @param transactionId long
     * @return List<PaymentDetail>
     */
    protected List<PaymentDetail> fetchPayment(String clientId, long paymentId, long transactionId) {
        List<PaymentDetail> payments = new ArrayList<>();
        List<PaymentDetailEntity> paymentEntities;
        // fetch from a database
        if (transactionId > 0) {
            paymentEntities = transactionDBMapper.getTransaction(paymentId, clientId, transactionId);
        } else {
            paymentEntities = paymentDBMapper.getPayment(paymentId, clientId);
        }
        populateServiceObject(clientId, paymentEntities, payments, true);

        return payments;
    }

    private void populateServiceObject(String clientId, List<PaymentDetailEntity> paymentEntities,
                                       List<PaymentDetail> payments, boolean getBillPayDetails) {
        for (PaymentDetailEntity paymentDetailEntity : paymentEntities) {
            // populate details
            PaymentDetail paymentDetail = paymentDetailMapper.mapServiceObject(paymentDetailEntity);
            // populate dates
            paymentDetail.setRequestDate(dateUtil.getTimestamp(paymentDetailEntity.getRequestDate()));
            paymentDetail.setPaymentDate(dateUtil.getTimestamp(paymentDetailEntity.getPaymentDate()));
            if (paymentDetail.getRecurringData() != null) {
                paymentDetail.getRecurringData().setEndDate(dateUtil.getTimestamp(paymentDetailEntity.getEndDate()));
            }
            if (paymentDetail.getCrossCurrencyPaymentData() != null) {
                paymentDetail.getCrossCurrencyPaymentData().setTradeDate(dateUtil.getTimestamp(paymentDetailEntity.getContractTradeDate(), dateFormatter));
                paymentDetail.getCrossCurrencyPaymentData().setValueDate(dateUtil.getTimestamp(paymentDetailEntity.getContractValueDate(), dateFormatter));
            }
            // populate large bill-pay details
            if (getBillPayDetails
                    && (paymentDetailEntity.getPaymentType().equals(PaymentType.ACH.toString())
                    || paymentDetailEntity.getPaymentType().equals(PaymentType.CHK.toString()))) {
                paymentDetail.setBillPayData(payeesService.getBillPayeeDetails(clientId, paymentDetailEntity.getPayeeId(), paymentDetailEntity.getPayeeTypeId()));
            }
            payments.add(paymentDetail);
        }
    }

    /**
     * Fetch payment
     *
     * @param clientId    String
     * @param userId      String
     * @param paymentData PaymentInitiationData
     * @return DuplicateCheckResponse
     */
    protected DuplicateCheckResponse fetchPayment(String clientId, String userId, PaymentInitiationData paymentData) {
        // defaulting
        DuplicateCheckResponse duplicateCheckResponse = new DuplicateCheckResponse();
        duplicateCheckResponse.setPaymentId("");
        duplicateCheckResponse.setSequenceNo("");

        List<PaymentEntryEntity> entryEntities = null;
        String invoiceNo;

        for (PaymentInitiationEntryData entry : paymentData.getEntries()) {
            invoiceNo = getInvoiceNumber(entry);
            if (PayeeCategory.P.equals(entry.getPayeeCategory())) {
                entryEntities = paymentEntryDBMapper.getDuplicatePaymentPersonalPayee(
                        clientId, userId, paymentData.getPaymentDate(),
                        entry.getPayeeId(), entry.getPayeeTypeId(),
                        entry.getTransactionAmt(), invoiceNo);
            } else if (PayeeCategory.A.equals(entry.getPayeeCategory())) {
                entryEntities = paymentEntryDBMapper.getDuplicatePaymentAdhocPayee(
                        clientId, userId, paymentData.getPaymentDate(),
                        entry.getCreditAccountData().getAccNum(),
                        entry.getTransactionAmt(), invoiceNo);
            }
            if (entryEntities != null && !entryEntities.isEmpty()) {
                duplicateCheckResponse.setPaymentId(String.valueOf(entryEntities.getFirst().getPaymentId()));
                duplicateCheckResponse.sequenceNo(String.valueOf(entryEntities.getFirst().getSequenceNo()));
                break;
            }
        }
        return duplicateCheckResponse;
    }

    private String getInvoiceNumber(PaymentInitiationEntryData entry) {
        if (entry.getAdditionalInfo() != null) {
            Optional<AdditionalInfoItem> invoiceNoItem = entry.getAdditionalInfo().getItems()
                    .stream()
                    .filter(additionalInfoItem -> additionalInfoItem.getKey().equals(AdditionalInfoItem.KeyEnum.INVOICE_NUMBER))
                    .findFirst();
            return invoiceNoItem.map(AdditionalInfoItem::getValue).orElse(null);
        } else {
            return null;
        }
    }

    protected List<PaymentDetail> fetchPaymentsTransactions(PaymentSearchCriteria criteria) {
        // populate valid statuses
        List<String> transactionStatus = new ArrayList<>();
        List<String> paymentStatus = new ArrayList<>();
        populateStatuses(criteria, transactionStatus, paymentStatus);
        // populate fetch flags
        String paymentFetch = paymentStatus.isEmpty() ? null : CommonConstant.YES;
        String transactionFetch = transactionStatus.isEmpty() ? null : CommonConstant.YES;

        String futureDatedFetch = null;
        Timestamp futureDate = null;
        if (isFutureDatedFetchRequired(criteria)) {
            futureDatedFetch = CommonConstant.YES;
            futureDate = Timestamp.valueOf(dateUtil.getStartOfDayDateTime().plusDays(1));
        }
        // convert dates to timestamp
        Timestamp fromDate = getCriteriaDate(criteria.getFromDate(), 0);
        Timestamp toDate = getCriteriaDate(criteria.getToDate(), 1);
        // fetch from a database
        List<PaymentDetailEntity> paymentEntities = transactionDBMapper.fetchPayments(criteria,
                fromDate, toDate, paymentFetch, paymentStatus, transactionFetch, transactionStatus,
                futureDatedFetch, futureDate);
        // populate service objects
        List<PaymentDetail> payments = new ArrayList<>();
        populateServiceObject(null, paymentEntities, payments, false);
        return payments;
    }

    protected List<PayeePayment> fetchPayments(PaymentSearchCriteria criteria) {
        return paymentDBMapper.getPaymentByPayeeIds(criteria.getClientId(), criteria.getPayeeIds(), criteria.getStatus());
    }

    private boolean isFutureDatedFetchRequired(PaymentSearchCriteria criteria) {
        return criteria.getStatus().contains(PaymentTransaction.ACMP.toString());
    }

    private void populateStatuses(PaymentSearchCriteria criteria, List<String> transactionStatus, List<String> paymentStatus) {
        List<String> statuses = criteria.getStatus();
        if (statuses != null && !statuses.isEmpty()) {
            transactionStatus.addAll(statuses.stream().filter(status -> TransactionStatus.fromValue(status) != null).toList());
            paymentStatus.addAll(statuses.stream().filter(status -> PaymentStatus.fromValue(status) != null).toList());
        }
    }

    private Timestamp getCriteriaDate(String date, int days) {
        try {
            if (date == null) {
                return null;
            }
            if (days == 0) {
                return dateUtil.getTimestamp(date);
            } else {
                return Timestamp.valueOf(dateUtil.getTimestamp(date).toLocalDateTime().plusDays(days));
            }
        } catch (Exception e) {
            log.error("Error parsing date {}", date, e);
            return null;
        }
    }

    /**
     * Populating additional data for cancel
     *
     * @param request        PaymentCancellationData
     * @param initiationData PaymentInitiationData
     */
    public void populateAdditionalDetails(PaymentCancellationData request, PaymentInitiationData initiationData) {
        HashMap<String, String> additionalData = getAdditionalData(initiationData);
        if (!additionalData.isEmpty()) {
            additionalData.put("singleInstance", request.isRecurring() ? String.valueOf(request.isSingleInstance()) : null);
            additionalData.put("transactionId", request.getTransactionId() > 0 ? String.valueOf(request.getTransactionId()) : "");
            additionalData.put("paymentStatus", request.getPaymentStatus().toString());
        }
        request.setAdditionalData(additionalData);
    }

    /**
     * Populating additional data for approve\reject
     *
     * @param initiationData PaymentInitiationData
     */
    public void populateAdditionalDetails(PaymentInitiationData initiationData) {
        HashMap<String, String> additionalData = getAdditionalData(initiationData);
        if (!additionalData.isEmpty()) {
            additionalData.put("paymentStatus", initiationData.getPaymentStatus().toString());
        }
        initiationData.setAdditionalData(additionalData);
    }

    /**
     * Get additional data
     *
     * @param initiationData PaymentInitiationData
     * @return HashMap<String, String>
     */
    private HashMap<String, String> getAdditionalData(PaymentInitiationData initiationData) {
        HashMap<String, String> additionalData = new HashMap<>();
        try {
            String accountNickName = (initiationData.getEntries().getFirst().getDebitAccountData().getAccNickName() != null
                    && !initiationData.getEntries().getFirst().getDebitAccountData().getAccNickName().isEmpty())
                    ? initiationData.getEntries().getFirst().getDebitAccountData().getAccNickName()
                    : initiationData.getEntries().getFirst().getDebitAccountData().getAccName();

            additionalData.put("paymentType", initiationData.getPaymentType().toString());
            additionalData.put("status", initiationData.getPaymentStatus().toString());
            additionalData.put("createdBy", initiationData.getMetaInfo().getCreatedBy());
            additionalData.put("modifiedBy", initiationData.getMetaInfo().getUpdatedBy());
            additionalData.put("debitAccountData.accNum", initiationData.getEntries().getFirst().getDebitAccountData().getAccNum());
            additionalData.put("debitAccountData.accNickName", accountNickName);
            additionalData.put("debitAccountData.cifName", initiationData.getEntries().getFirst().getDebitAccountData().getCifName());
            additionalData.put("debitAccountData.cif", initiationData.getEntries().getFirst().getDebitAccountData().getCif());
            additionalData.put("totalTransactionAmt", String.format("%.2f", initiationData.getTotalTransactionAmt()));
            additionalData.put("transactionCcy", initiationData.getTransactionCcy().toString());
            additionalData.put("debitAccountData.ccyAmt", String.format("%.2f", initiationData.getEntries().getFirst().getDebitAccountData().getCcyAmt()));
            additionalData.put("debitAccountData.accCcy", initiationData.getEntries().getFirst().getDebitAccountData().getAccCcy().toString());
            additionalData.put("crossCurrencyPaymentData.fxRate", Optional.ofNullable(initiationData.getEntries().getFirst().getCrossCurrencyPaymentData())
                    .map(CrossCurrencyPaymentData::getFxRate)
                    .map(String::valueOf)
                    .orElse(""));
            additionalData.put("paymentDate", getDate(initiationData.getPaymentDate()));
            additionalData.put("paymentId", String.valueOf(initiationData.getPaymentId()));
            additionalData.put("charges", Optional.ofNullable(initiationData.getEntries().getFirst().getCharges())
                    .map(Charges::toString)
                    .orElse(""));
            additionalData.put("creditAccountData.accNum", Optional.ofNullable(initiationData.getEntries().getFirst().getCreditAccountData())
                    .map(AccountData::getAccNum)
                    .orElse(""));
            if (!isTransfer(initiationData.getPaymentType())) {
                additionalData.put("creditorData.name", initiationData.getEntries().getFirst().getCreditorData().getName());
                additionalData.put("creditorData.nickName", initiationData.getEntries().getFirst().getCreditorData().getNickName());
                additionalData.put("creditorData.email", initiationData.getEntries().getFirst().getCreditorData().getContact().getEmail());
                additionalData.put("creditorData.address.addLine1", initiationData.getEntries().getFirst().getCreditorData().getAddress().getAddLine1());
                additionalData.put("creditorData.address.addLine2", initiationData.getEntries().getFirst().getCreditorData().getAddress().getAddLine2());
                additionalData.put("creditorData.address.addLine3", initiationData.getEntries().getFirst().getCreditorData().getAddress().getAddLine3());
                additionalData.put("creditorData.address.city", initiationData.getEntries().getFirst().getCreditorData().getAddress().getCity());
                additionalData.put("creditorData.address.state", initiationData.getEntries().getFirst().getCreditorData().getAddress().getState());
                additionalData.put("creditorData.address.country", initiationData.getEntries().getFirst().getCreditorData().getAddress().getCountry());
                additionalData.put("creditorData.address.zip", initiationData.getEntries().getFirst().getCreditorData().getAddress().getZip());
                additionalData.put("creditorAccountData.accNum", initiationData.getEntries().getFirst().getCreditAccountData().getAccNum());
                additionalData.put("creditorAccountData.accCcy", initiationData.getEntries().getFirst().getCreditAccountData().getAccCcy().toString());
                additionalData.put("creditorAccountData.ccyAmt", initiationData.getEntries().getFirst().getCreditAccountData().getCcyAmt().toString());
                additionalData.put("creditorAccountData.cifName", initiationData.getEntries().getFirst().getCreditAccountData().getCifName());
                additionalData.put("creditorAccountData.cif", initiationData.getEntries().getFirst().getCreditAccountData().getCif());

                additionalData.put("creditorBankData.bankName", Optional.ofNullable(initiationData.getEntries().getFirst().getCreditorBankData())
                        .map(BankData::getBankName).orElse(""));
                additionalData.put("creditorBankData.routingCode", Optional.ofNullable(initiationData.getEntries().getFirst().getCreditorBankData())
                        .map(BankData::getRoutingCode).orElse(""));
                additionalData.put("billPayData.customerAccountNumber", Optional.ofNullable(initiationData.getEntries().getFirst().getBillPayData())
                        .map(BillPayData::getCustomerAccountNumber)
                        .map(String::toString)
                        .orElse(""));
                additionalData.put("isoData.endToEndId", Optional.ofNullable(initiationData.getEntries().getFirst().getIsoData())
                        .map(IsoData::getEndToEndId)
                        .map(String::toString)
                        .orElse(""));
            }
            additionalData.put("fileId", String.valueOf(initiationData.getFileId()));
            additionalData.put("recordNumber", String.valueOf(initiationData.getRecordNumber()));
            additionalData.put("notify_message", String.valueOf(initiationData.getEntries().getFirst().getNotifyMessage()));
            additionalData.put("bankInstructions", String.valueOf(initiationData.getEntries().getFirst().getInstructions().getBankToBankInstructions()));

            // populate the intermediate bank
            additionalData.put("intermediaryBankRoutingCode", String.valueOf(initiationData.getEntries().getFirst().getIntermediaryBankData().getRoutingCode()));
            additionalData.put("intermediaryBank", String.valueOf(initiationData.getEntries().getFirst().getIntermediaryBankData().getBankName()));

            if (initiationData.getEntries().getFirst().getCrossCurrencyPaymentData() != null) {
                additionalData.put("quoteConfirmationId", String.valueOf(initiationData.getEntries().getFirst().getCrossCurrencyPaymentData().getQuoteConfirmationId()));
            }
            additionalData.put("templateId", String.valueOf(initiationData.getTemplateId()));
            additionalData.put("templateName", String.valueOf(initiationData.getTemplateId()));
            additionalData.put(PaymentAuditConstant.INSUFFICIENT_FUNDS, initiationData.getEntries().getFirst().isInsufficientFunds() ? "Y" : "N");

            populateAdditionalInfo(additionalData, initiationData.getEntries().getFirst().getAdditionalInfo());
            populateRecurringData(additionalData, initiationData.getRecurringData(), initiationData.getPaymentId());
            populateRemittanceDetailsData(additionalData, initiationData.getEntries().getFirst().getIsoData());
            populateOBO(additionalData, initiationData.getEntries().getFirst().getOboData());
        } catch (Exception e) {
            log.error("populate additional details::{}", e.getMessage(), e);
        }
        return additionalData;
    }


    /**
     * Populate additional recurring data
     *
     * @param additionalData HashMap<String, String>
     * @param recurringData  RecurringData
     * @param paymentId      long
     */
    private void populateRecurringData(HashMap<String, String> additionalData, RecurringData recurringData, long paymentId) {
        if (recurringData != null && recurringData.isRecurring()) {
            additionalData.put("recurringData.recurring", "Y");
            additionalData.put("recurringData.paymentFrequency", recurringData.getPaymentFrequency().getDescription());
            additionalData.put("recurringData.endDate", getDate(recurringData.getEndDate()));
            additionalData.put("recurringData.totalInstances", recurringData.getTotalInstances().toString());
            additionalData.put("recurringData.seriesId", String.valueOf(paymentId));
        } else {
            additionalData.put("recurringData.recurring", "N");
            additionalData.put("recurringData.seriesId", "");
        }
    }

    private void populateAdditionalInfo(HashMap<String, String> additionalData, AdditionalInfo additionalInfo) {
        if (additionalInfo != null) {
            additionalData.put("additionalInfo.invoice_number", additionalInfo.getItems().stream()
                    .filter(item -> item.getKey().equals(AdditionalInfoItem.KeyEnum.INVOICE_NUMBER))
                    .findFirst().map(AdditionalInfoItem::getValue)
                    .orElse(""));
            additionalData.put("additionalInfo.internal_memo", additionalInfo.getItems().stream()
                    .filter(item -> item.getKey().equals(AdditionalInfoItem.KeyEnum.INTERNAL_MEMO))
                    .findFirst().map(AdditionalInfoItem::getValue)
                    .orElse(""));
            additionalData.put("additionalInfo.purpose_of_payment", additionalInfo.getItems().stream()
                    .filter(item -> item.getKey().equals(AdditionalInfoItem.KeyEnum.PURPOSE_OF_PAYMENT_CODE))
                    .findFirst().map(AdditionalInfoItem::getValue)
                    .orElse(""));
            additionalData.put("additionalInfo.reason_for_payment", additionalInfo.getItems().stream()
                    .filter(item -> item.getKey().equals(AdditionalInfoItem.KeyEnum.REMARKS))
                    .findFirst().map(AdditionalInfoItem::getValue)
                    .orElse(""));
        }
    }

    /**
     * Populate additional recurring data
     *
     * @param additionalData HashMap<String, String>
     * @param isoData        RecurringData
     */
    private void populateRemittanceDetailsData(HashMap<String, String> additionalData, IsoData isoData) {
        if (isoData != null && isoData.getRelatedRemittanceInfo() != null) {
            additionalData.put(PaymentAuditConstant.REMITTANCE_DETAILS_ID, isoData.getRelatedRemittanceInfo().getRemittanceId());
            additionalData.put(PaymentAuditConstant.REMITTANCE_DETAILS_SEND_METHOD, Optional.ofNullable(isoData.getRelatedRemittanceInfo().getMethod()).map(RemittanceMethod::name).orElse(null));
            additionalData.put(PaymentAuditConstant.REMITTANCE_DETAILS_ELECTRONIC_ID, isoData.getRelatedRemittanceInfo().getElectronicId());
            additionalData.put(PaymentAuditConstant.REMITTANCE_DETAILS_COUNTRY, Optional.ofNullable(isoData.getRelatedRemittanceInfo().getPostalAddress()).map(RemitAddress::getCountryCode).orElse(null));
            additionalData.put(PaymentAuditConstant.REMITTANCE_DETAILS_BUILDING_NUMBER, Optional.ofNullable(isoData.getRelatedRemittanceInfo().getPostalAddress()).map(RemitAddress::getBuildingNumber).orElse(null));
            additionalData.put(PaymentAuditConstant.REMITTANCE_DETAILS_STREET_NAME, Optional.ofNullable(isoData.getRelatedRemittanceInfo().getPostalAddress()).map(RemitAddress::getStreetName).orElse(null));
            additionalData.put(PaymentAuditConstant.REMITTANCE_DETAILS_CITY, Optional.ofNullable(isoData.getRelatedRemittanceInfo().getPostalAddress()).map(RemitAddress::getCity).orElse(null));
            additionalData.put(PaymentAuditConstant.REMITTANCE_DETAILS_STATE, Optional.ofNullable(isoData.getRelatedRemittanceInfo().getPostalAddress()).map(RemitAddress::getState).orElse(null));
            additionalData.put(PaymentAuditConstant.REMITTANCE_DETAILS_POSTAL_CODE, Optional.ofNullable(isoData.getRelatedRemittanceInfo().getPostalAddress()).map(RemitAddress::getPostalCode).orElse(null));
            additionalData.put(PaymentAuditConstant.END_TO_END_ID, isoData.getEndToEndId());
            additionalData.put(PaymentAuditConstant.REASON_FOR_PAYMENT_CODE, Optional.ofNullable(isoData.getPurposeCodeInfo()).map(PurposeCodeInfo::getPurposeCode).orElse(null));
        }
    }

    private void populateOBO(HashMap<String, String> additionalData, OBOData oboData) {
        if (oboData != null) {
            additionalData.put(PaymentAuditConstant.OBO_ORIGINATOR_TYPE_IDENTIFIER, Optional.ofNullable(oboData.getOriginatorType()).map(OBOType::getDescription).orElse(null));
            additionalData.put(PaymentAuditConstant.OBO_ORIGINATOR_NAME, oboData.getOriginatorName());
            additionalData.put(PaymentAuditConstant.OBO_ORIGINATOR_IDENTIFIER, oboData.getOriginatorIdentifier());
            additionalData.put(PaymentAuditConstant.OBO_ORIGINATOR_STREET_ADDRESS, oboData.getOriginatorStreetAddr());
            additionalData.put(PaymentAuditConstant.OBO_ORIGINATOR_CITY, oboData.getOriginatorCity());
            additionalData.put(PaymentAuditConstant.OBO_ORIGINATOR_STATE, oboData.getOriginatorState());
            additionalData.put(PaymentAuditConstant.OBO_ORIGINATOR_ZIP_CODE, oboData.getOriginatorZip());
            additionalData.put(PaymentAuditConstant.OBO_ORIGINATOR_COUNTRY, oboData.getOriginatorCountry());
        }
    }

    private String getDate(Timestamp paymentDate) {
        return dateUtil.getTimestamp(paymentDate, dateUtil.getApplicationTimeZone(), DateTimeFormatter.ISO_LOCAL_DATE);
    }

    private String getDate(String date) {
        if (date == null || date.isEmpty()) {
            return null;
        }
        Timestamp timestamp = dateUtil.getTimestamp(dateUtil.getApplicationTimeZone(), date, dateTimeFormatter);
        return dateUtil.getTimestamp(timestamp, dateUtil.getApplicationTimeZone(), DateTimeFormatter.ISO_LOCAL_DATE);
    }

    private boolean isTransfer(PaymentType paymentType) {
        return CommonConstant.TRANSFER_TYPES.contains(paymentType.toString());
    }
}
