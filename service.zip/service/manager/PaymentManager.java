package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.entity.ActivityLogEntity;
import com.svb.gateway.payments.common.enums.ErrorCodeEnum;
import com.svb.gateway.payments.common.enums.payment.PaymentStatus;
import com.svb.gateway.payments.common.enums.payment.TransactionStatus;
import com.svb.gateway.payments.common.exception.CollectException;
import com.svb.gateway.payments.common.exception.PaymentBadRequestException;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.mapper.db.ActivityLogDbMapper;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.*;
import com.svb.gateway.payments.common.model.payment.cancellation.PaymentCancellationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationEntryData;
import com.svb.gateway.payments.common.model.payment.processing.PaymentProcessingData;
import com.svb.gateway.payments.common.model.payment.processing.PaymentProcessingHeader;
import com.svb.gateway.payments.common.model.rulesengine.CountryRuleResponse;
import com.svb.gateway.payments.common.model.rulesengine.RuleData;
import com.svb.gateway.payments.common.service.AccountsService;
import com.svb.gateway.payments.common.service.ApprovalsService;
import com.svb.gateway.payments.common.util.CountryRulesUtil;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.payment.entity.*;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.payment.mapper.db.PaymentDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.entity.PaymentMapper;
import com.svb.gateway.payments.payment.mapper.model.KafkaHostMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.model.ProcessingSplitMessage;
import com.svb.gateway.payments.payment.service.LimitsService;
import com.svb.gateway.payments.payment.service.host.PaymentKafkaHost;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import com.svb.gateway.payments.payment.util.RecurringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.svb.gateway.payments.common.constants.CommonConstant.ATTENTION;
import static com.svb.gateway.payments.common.constants.CommonConstant.YES;
import static com.svb.gateway.payments.common.util.PaymentConstant.*;

@Slf4j
@Primary
@Service
public class PaymentManager {
    private final AccountsService accountsService;
    private final ApprovalsService approvalsService;
    private final RecurringUtil recurringUtil;
    private final DateUtil dateUtil;
    private final PaymentMapper paymentMapper;
    private final PaymentDBMapper paymentDBMapper;
    private final TransactionEntryDBMapper transactionEntryDBMapper;
    private final KafkaHostMapper kafkaHostMapper;
    private final PaymentKafkaHost paymentKafkaHost;
    private final LimitsService limitsService;
    private final CountryRulesUtil countryRulesUtil;
    private final PaymentManagerFetch fetchManager;
    private final PaymentManagerValidate validateManager;
    private final PaymentManagerCreate createManager;
    private final PaymentManagerEdit editManager;
    private final ActivityLogDbMapper activityLogDBMapper;
    final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    final DateTimeFormatter dateFormatterWSS = DateTimeFormatter.ofPattern("yyyyMMdd'T'HH:mm:ss");
    private final PaymentStatusUtil paymentStatusUtil;

    public PaymentManager(AccountsService accountsService,
                          ApprovalsService approvalsService,
                          RecurringUtil recurringUtil,
                          DateUtil dateUtil,
                          PaymentMapper paymentMapper,
                          PaymentDBMapper paymentDBMapper,
                          TransactionDBMapper transactionDBMapper,
                          TransactionEntryDBMapper transactionEntryDBMapper,
                          KafkaHostMapper kafkaHostMapper,
                          PaymentKafkaHost paymentKafkaHost,
                          LimitsService limitsService,
                          CountryRulesUtil countryRulesUtil,
                          PaymentManagerFetch fetchManager,
                          PaymentManagerValidate validateManager,
                          PaymentManagerCreate createManager,
                          PaymentManagerEdit editManager,
                          ActivityLogDbMapper activityLogDBMapper,
                          PaymentStatusUtil paymentStatusUtil) {
        this.accountsService = accountsService;
        this.recurringUtil = recurringUtil;
        this.dateUtil = dateUtil;
        this.paymentMapper = paymentMapper;
        this.paymentDBMapper = paymentDBMapper;
        this.transactionEntryDBMapper = transactionEntryDBMapper;
        this.kafkaHostMapper = kafkaHostMapper;
        this.paymentKafkaHost = paymentKafkaHost;
        this.limitsService = limitsService;
        this.countryRulesUtil = countryRulesUtil;
        this.fetchManager = fetchManager;
        this.validateManager = validateManager;
        this.createManager = createManager;
        this.editManager = editManager;
        this.activityLogDBMapper = activityLogDBMapper;
        this.approvalsService = approvalsService;
        this.paymentStatusUtil = paymentStatusUtil;
    }

    /**
     * Populate debit account bank details
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    public void populateBankDetails(RequestData<PaymentInitiationData> requestData) {
        throw new UnsupportedOperationException();
    }

    /**
     * Populate debit account details
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    public void populateAccountDetails(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        // populate debit account
        accountsService.populateDebitAccountDetails((PaymentContext) requestData.getGatewayContext(), requestData.getRequest(), null);
    }

    /**
     * Validate request data
     * - payment type filter validation
     * - date validation for past-date, holiday and cut-off
     * - recurring config validation
     * - amount-currency validation like max amount and decimal places
     * - if edit flow, validate with existing payment
     * - limit validation (and consumption if create mode)
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @throws PaymentServiceException ex
     */
    public void validatePayment(RequestData<PaymentInitiationData> requestData, String operation) throws PaymentServiceException {
        try {
            // country-specific validations
            if (requestData.getRequest().getFileId() > 0) {
                for (PaymentInitiationEntryData entry : requestData.getRequest().getEntries()) {
                    CountryRuleResponse countryRuleResponse = countryRulesUtil.getCountryRuleResponse(requestData.getGatewayContext(), entry);
                    this.validatePayment((PaymentContext) requestData.getGatewayContext(), requestData.getRequest(), entry, countryRuleResponse.getData());
                }
            }
            if (CommonConstant.OPERATION_UPDATE.equals(operation)) {
                // get existing payment
                PaymentInitiationData existingPayment = populatePayment(requestData.getRequest().getPaymentId(), requestData.getGatewayContext().getClientId());
                // check existing payment
                this.validatePayment(requestData, existingPayment);
            }
            validateManager.validatePayment(requestData, operation);
        } catch (PaymentBadRequestException | PaymentServiceException e) {
            log.error("payment validation::{}, flow {}, error {}, {}", requestData.getRequest().getPaymentType(),
                    operation, e.getMessage(),
                    requestData.getGatewayContext().log());
            throw e;
        }
    }

    /**
     * Validate request data for country specific rules
     *
     * @param context     PaymentContext
     * @param paymentData PaymentInitiationData
     * @param entryData   PaymentInitiationEntryData
     * @param ruleData    RuleData
     */
    protected void validatePayment(PaymentContext context, PaymentInitiationData paymentData, PaymentInitiationEntryData entryData, RuleData ruleData) throws PaymentServiceException {
        // TODO override in respective manager
    }

    /**
     * Validate request data for edit flow
     *
     * @param requestData     RequestData<PaymentInitiationData>
     * @param existingPayment PaymentInitiationData
     * @throws PaymentServiceException e
     */
    protected void validatePayment(RequestData<PaymentInitiationData> requestData, PaymentInitiationData existingPayment) throws PaymentServiceException {
        validateManager.validatePayment(requestData, existingPayment, getAllowedPaymentStatusForEdit());
    }

    /**
     * Validate request data for cancel flow
     *
     * @param requestData PaymentCancellationData
     * @param context     PaymentContext
     * @throws PaymentServiceException e
     */
    public void validatePayment(PaymentCancellationData requestData, PaymentContext context) throws PaymentServiceException {
        validateManager.validatePayment(requestData, context, getAllowedPaymentStatusForCancellation(), getAllowedTransactionStatusForCancellation());
    }

    /**
     * Validate request data for update status flow
     *
     * @param request UpdatePaymentStatusRequest
     * @param context PaymentContext
     * @throws PaymentServiceException e
     */
    public void validatePayment(UpdatePaymentStatusRequest request, PaymentContext context) throws PaymentServiceException {
        validateManager.validatePayment(request, context, transactionStatusUpdateAllowed(), getAllowedTransactionStatusForUpdate());
    }

    /**
     * Decides if transaction status update is allowed
     *
     * @return boolean
     */
    protected boolean transactionStatusUpdateAllowed() {
        return false;
    }

    /**
     * get list of allowed transaction status for cancellation
     *
     * @return List of String
     */
    protected List<String> getAllowedTransactionStatusForCancellation() {
        return new ArrayList<>();
    }

    /**
     * get list of allowed payment status for cancellation
     *
     * @return List of String
     */
    protected List<String> getAllowedPaymentStatusForCancellation() {
        return List.of(PaymentStatus.PNAP.toString(), PaymentStatus.PNFA.toString(), PaymentStatus.ACMP.toString());
    }

    /**
     * get list of allowed payment status for cancellation
     *
     * @return List of String
     */
    protected List<String> getAllowedPaymentStatusForEdit() {
        return List.of(PaymentStatus.PNAP.toString(), PaymentStatus.PNFA.toString(), PaymentStatus.ACMP.toString());
    }

    /**
     * get a list of allowed transaction status for status-update
     *
     * @return List of String
     */
    protected List<String> getAllowedTransactionStatusForUpdate() {
        return new ArrayList<>();
    }

    public void validatePayment(RequestData<PaymentInitiationData> requestData, PaymentStatus newPaymentStatus) throws PaymentServiceException {
        validateManager.validatePaymentForStatus(requestData, newPaymentStatus);
    }

    /* PAYMENT start */

    /**
     * Populate payment entity
     *
     * @param context     PaymentContext
     * @param payment     PaymentEntity
     * @param requestData RequestData<PaymentInitiationData>
     */
    /*over-ride this method as per individual payment type*/
    protected void populatePaymentEntity(PaymentContext context, PaymentEntity payment, RequestData<PaymentInitiationData> requestData) {
        fetchManager.populatePaymentEntity(context, payment, requestData);
    }

    protected PaymentInitiationData populatePaymentServiceObject(PaymentEntity paymentEntity) {
        return paymentMapper.mapPaymentServiceObject(paymentEntity);
    }

    /**
     * Populate payment entry entity
     *
     * @param context                    PaymentContext
     * @param paymentEntry               PaymentEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    /*over-ride this method as per individual payment type*/
    protected void populatePaymentEntryEntity(PaymentContext context, PaymentEntryEntity paymentEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        fetchManager.populatePaymentEntryEntity(context, paymentEntry, paymentInitiationEntryData);
    }

    protected PaymentInitiationEntryData populatePaymentEntryServiceObject(PaymentEntryEntity entry, PaymentEntity paymentEntity) {
        PaymentInitiationEntryData entryData = paymentMapper.mapPaymentServiceObject(entry);
        entryData.setTransactionCcy(paymentEntity.getPaymentCurrency());
        return entryData;
    }

    /**
     * Create a recurring entry
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    /*over-ride this method as per individual payment type*/
    protected void createRecurring(RequestData<PaymentInitiationData> requestData) {
        createManager.createRecurring(requestData);
    }

    /**
     * Edit recurring entry
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    protected void editRecurring(RequestData<PaymentInitiationData> requestData) {
        editManager.editRecurring(requestData);
    }

    /**
     * Create payment and transaction (if criteria satisfied)
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    public void createPayment(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        // create recurring
        if (requestData.getRequest().getRecurringData().isRecurring()) {
            createRecurring(requestData);
        }
        // populate payment entity
        PaymentEntity payment = new PaymentEntity();
        this.populatePaymentEntity(context, payment, requestData);
        // create payment
        createManager.createPayment(requestData, payment);
        // create payment entry
        this.createPaymentEntry(requestData);
        // log activity
        this.createActivityLog(PAYMENT, requestData.getRequest().getPaymentId(), CommonConstant.LOG_ADD, 0, context.getUserId());
        // create transaction
        this.createTransaction(requestData);
    }

    /**
     * Edit payment
     * -    If a payment has recurring details with a single instance flag, a new payment gets created, and existing series updated
     * -    Else it's edit payment with creation transaction (if criteria satisfied)
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    @Transactional(rollbackFor = Exception.class)
    public void editPayment(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        // populate payment entity
        PaymentEntity payment = new PaymentEntity();
        // create new payment and update series for processed instances and payment date
        if (requestData.getRequest().getRecurringData() != null
                && requestData.getRequest().getRecurringData().isSingleInstance() != null
                && requestData.getRequest().getRecurringData().isSingleInstance()) {
            // edit existing series
            editManager.editPaymentSeries(requestData, context);
            // populate payment entity
            fetchManager.updatePaymentForNextInstance(requestData.getRequest());
            this.populatePaymentEntity(context, payment, requestData);
            // create the next instance
            createManager.createNextPaymentInstance(requestData, payment);
            // create payment entry
            this.createPaymentEntry(requestData);
            // log activity
            this.createActivityLog(PAYMENT, requestData.getRequest().getPaymentId(), CommonConstant.LOG_MODIFY, 0, context.getUserId());
            // create transaction
            this.createTransaction(requestData);
            // return a new instance
            PaymentInitiationData paymentInitiationData = this.populatePayment(requestData.getRequest().getPaymentId(), context.getClientId());
            paymentInitiationData.setHold(requestData.getRequest().isHold());
            requestData.setRequest(paymentInitiationData);
            return;
        }
        this.populatePaymentEntity(context, payment, requestData);
        payment.setPaymentId(requestData.getRequest().getPaymentId());
        // cancel workflow
        if (!context.isApprovalFlag()) {
            this.cancelWorkflow(context, List.of(requestData.getRequest().getPaymentId()), "payment update");
        }
        // update
        editManager.updatePaymentForEdit(requestData, payment);
        // update payment entry
        this.editPaymentEntry(requestData);
        // log activity
        this.createActivityLog(PAYMENT, requestData.getRequest().getPaymentId(), CommonConstant.LOG_MODIFY, 0, context.getUserId());
        // create transaction
        this.createTransaction(requestData);
    }

    /**
     * Create payment entry
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    protected void createPaymentEntry(RequestData<PaymentInitiationData> requestData) {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        long paymentId = requestData.getRequest().getPaymentId();
        for (PaymentInitiationEntryData entry : requestData.getRequest().getEntries()) {
            // populate payment entry entity
            PaymentEntryEntity paymentEntry = new PaymentEntryEntity();
            this.populatePaymentEntryEntity(context, paymentEntry, entry);
            // create
            createManager.createPaymentEntry(paymentId, paymentEntry);
        }
    }

    /**
     * Edit payment entry
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    protected void editPaymentEntry(RequestData<PaymentInitiationData> requestData) {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        for (PaymentInitiationEntryData entry : requestData.getRequest().getEntries()) {
            // populate payment entry entity
            PaymentEntryEntity paymentEntry = new PaymentEntryEntity();
            this.populatePaymentEntryEntity(context, paymentEntry, entry);
            editManager.editPaymentEntry(requestData, paymentEntry);
        }
    }

    /**
     * Approve payment and transaction (if criteria satisfied)
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Transactional(rollbackFor = Exception.class)
    public void approvePayment(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        PaymentInitiationData paymentData = requestData.getRequest();
        if (paymentData.getRecurringData().isRecurring() && !paymentData.isHold()) {
            editManager.editRecurring(paymentData.getRecurringData().getRecurrenceId(), paymentData.getRecurringData().getProcessedInstances());
        }
        if (!paymentData.isHold() && PaymentStatus.ACMP.equals(paymentData.getPaymentStatus())) {
            paymentData.setPaymentStatus(PaymentStatus.COMP);
        }
        // edit payment
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setPaymentId(paymentData.getPaymentId());
        paymentEntity.setPaymentDate(paymentData.getPaymentDate());
        paymentEntity.setStatus(paymentData.getPaymentStatus().toString());
        paymentEntity.setUserId(context.getUserId());
        paymentStatusUtil.updatePayment(paymentEntity, false);
        String logActivity = List.of(PaymentStatus.ACMP, PaymentStatus.COMP).contains(paymentData.getPaymentStatus())
                ? String.format("%s%s", CommonConstant.LOG_APPROVE, CommonConstant.LOG_APPROVE)
                : CommonConstant.LOG_APPROVE;
        // log activity
        this.createActivityLog(PAYMENT, requestData.getRequest().getPaymentId(), logActivity, requestData.getRequest().getWorkflowId(), context.getUserId());
        // create transaction
        this.createTransaction(requestData);
        // populate additional details (for alert-audit)
        fetchManager.populateAdditionalDetails(requestData.getRequest());
    }

    /**
     * Reject payment
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    public void rejectPayment(RequestData<PaymentInitiationData> requestData) {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        PaymentInitiationData paymentData = requestData.getRequest();
        // edit payment
        PaymentEntity paymentEntity = new PaymentEntity();
        paymentEntity.setPaymentId(paymentData.getPaymentId());
        paymentEntity.setPaymentDate(paymentData.getPaymentDate());
        paymentEntity.setStatus(paymentData.getPaymentStatus().toString());
        paymentEntity.setUserId(context.getUserId());
        paymentStatusUtil.updatePayment(paymentEntity, false);
        // log activity
        this.createActivityLog(PAYMENT, requestData.getRequest().getPaymentId(), CommonConstant.LOG_REJECT, requestData.getRequest().getWorkflowId(), requestData.getGatewayContext().getUserId());
        // populate additional details (for alert-audit)
        fetchManager.populateAdditionalDetails(requestData.getRequest());
    }
    /* PAYMENT end */

    /* TRANSACTION start */

    /**
     * Populate transaction entity
     *
     * @param context     PaymentContext
     * @param transaction TransactionEntity
     * @param requestData RequestData<PaymentInitiationData>
     */
    /*over-ride this method as per individual payment type*/
    protected void populateTransactionEntity(PaymentContext context, TransactionEntity transaction, RequestData<PaymentInitiationData> requestData) {
        fetchManager.populateTransactionEntity(context, transaction, requestData);
    }

    /**
     * Populate transaction entry entity
     *
     * @param context          PaymentContext
     * @param transactionEntry TransactionEntryEntity
     * @param entry            RequestData<PaymentInitiationData>
     */
    /*over-ride this method as per individual payment type*/
    protected void populateTransactionEntryEntity(PaymentContext context, TransactionEntryEntity transactionEntry, PaymentInitiationEntryData entry) {
        fetchManager.populateTransactionEntryEntity(context, transactionEntry, entry);
    }

    /**
     * Create transaction
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    public void createTransaction(RequestData<PaymentInitiationData> requestData) {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        if (requestData.getRequest().isHold()
                || context.isApprovalFlag()) {
            return;
        }
        // populate transaction entity
        TransactionEntity transaction = new TransactionEntity();
        this.populateTransactionEntity(context, transaction, requestData);
        // create
        createManager.createTransaction(requestData, transaction);
        // create a transaction entry
        this.createTransactionEntry(requestData);
        // log activity
        this.createActivityLog(TRANSACTION, requestData.getRequest().getTransactionId(), CommonConstant.LOG_ADD, 0, context.getUserId());
    }

    /**
     * Create cancelled transaction
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    public void createCancelledTransaction(RequestData<PaymentInitiationData> requestData) {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        // populate transaction entity
        TransactionEntity transaction = new TransactionEntity();
        this.populateTransactionEntity(context, transaction, requestData);
        // override status
        transaction.setStatus(TransactionStatus.CURT.toString());
        // create
        createManager.createTransaction(requestData, transaction);
        // create a transaction entry
        this.createTransactionEntry(requestData);
        // log activity
        this.createActivityLog(TRANSACTION, requestData.getRequest().getTransactionId(), CommonConstant.LOG_CANCEL, 0, context.getUserId());
    }

    /**
     * Create a transaction entry
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    /*over-ride this method as per individual payment type*/
    protected void createTransactionEntry(RequestData<PaymentInitiationData> requestData) {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        long transactionId = requestData.getRequest().getTransactionId();
        String transactionStatus = requestData.getRequest().getTransactionStatus().toString();

        for (PaymentInitiationEntryData entry : requestData.getRequest().getEntries()) {
            // populate transaction entry entity
            TransactionEntryEntity transactionEntry = new TransactionEntryEntity();
            this.populateTransactionEntryEntity(context, transactionEntry, entry);
            // create
            createManager.createTransactionEntry(transactionId, transactionStatus, transactionEntry);
        }
    }
    /* TRANSACTION end */

    /* HOST start */

    /**
     * Populate host message
     *
     * @param context     PaymentContext
     * @param message     ProcessingMessage
     * @param requestData RequestData<PaymentInitiationData>
     */
    /*over-ride this method as per individual payment type*/
    protected void populateHostMessage(PaymentContext context, ProcessingMessage message, RequestData<PaymentInitiationData> requestData) {
        PaymentProcessingData paymentData = new PaymentProcessingData();
        PaymentProcessingHeader paymentHeader = new PaymentProcessingHeader();

        // populate payment data
        kafkaHostMapper.mapHostMessage(paymentData, requestData.getRequest());
        kafkaHostMapper.mapHostMessage(paymentData, requestData.getRequest().getEntries().getFirst());
        kafkaHostMapper.mapHostMessage(paymentData, context);
        kafkaHostMapper.mapHostMessageHeader(paymentHeader, context.getCommonHeaders());
        // populate message
        message.setPaymentHeader(paymentHeader);
        message.setPaymentData(paymentData);
    }

    /**
     * Populate host (split) message
     *
     * @param context     PaymentContext
     * @param message     ProcessingSplitMessage
     * @param requestData RequestData<PaymentInitiationData>
     */
    /*over-ride this method as per individual payment type*/
    protected void populateHostMessage(PaymentContext context, ProcessingSplitMessage message, RequestData<PaymentInitiationData> requestData) {
        message.setPaymentData(new ArrayList<>());

        PaymentProcessingHeader paymentHeader = new PaymentProcessingHeader();
        kafkaHostMapper.mapHostMessageHeader(paymentHeader, context.getCommonHeaders());
        paymentHeader.setIsSplitPayment(YES);
        message.setPaymentHeader(paymentHeader);

        for (PaymentInitiationEntryData entryData : requestData.getRequest().getEntries()) {
            PaymentProcessingData paymentData = new PaymentProcessingData();
            // populate payment data
            kafkaHostMapper.mapHostMessage(paymentData, requestData.getRequest());
            kafkaHostMapper.mapHostMessage(paymentData, entryData);
            kafkaHostMapper.mapHostMessage(paymentData, context);
            paymentData.setRequestSerialNo(entryData.getEntryNumber());
            // populate message
            message.getPaymentData().add(paymentData);
        }
    }

    /**
     * Post message to (kafka) host
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    public void postPayment(RequestData<PaymentInitiationData> requestData) {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        if (context.isApprovalFlag()
                || requestData.getRequest().isHold()
                || requestData.getRequest().getTransactionId() == 0) {
            return;
        }

        String key = getKey(requestData);
        // populate host message
        if (context.isSplitFlag()) {
            ProcessingSplitMessage message = new ProcessingSplitMessage();
            populateHostMessage(context, message, requestData);
            // post message
            paymentKafkaHost.send(requestData, key, message, this);
        } else {
            ProcessingMessage message = new ProcessingMessage();
            populateHostMessage(context, message, requestData);
            // post message
            paymentKafkaHost.send(requestData, key, message, this);
        }
    }

    /**
     * Get key used for kafka posting
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return String
     */
    protected String getKey(RequestData<PaymentInitiationData> requestData) {
        return Long.toString(requestData.getRequest().getTransactionId());
    }

    /**
     * Call back from host to update transaction status on successful posting
     *
     * @param transactionId long
     * @param userId        String
     */
    public void kafkaHostCallbackOnFailure(long transactionId, String userId) {
        try {
            PaymentTransactionStatusEntity paymentTransactionStatusEntity = new PaymentTransactionStatusEntity();
            paymentTransactionStatusEntity.setStatus(TransactionStatus.INIT.toString());
            paymentTransactionStatusEntity.setTransactionId(transactionId);
            paymentStatusUtil.updateEntireStatus(paymentTransactionStatusEntity, false);
        } catch (Exception e) {
            //TODO
        }
    }
    /* HOST end*/

    /**
     * Callback method to update payment status after approval
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    public void approvalCallbackOn(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        try {
            PaymentEntity paymentEntity = new PaymentEntity();
            paymentEntity.setPaymentId(requestData.getRequest().getPaymentId());
            paymentEntity.setStatus(requestData.getRequest().getPaymentStatus().toString());
            paymentEntity.setWorkflowId(requestData.getRequest().getWorkflowId());
            paymentEntity.setUpdatedBy(requestData.getRequest().getMetaInfo().getUpdatedBy());
            paymentStatusUtil.updatePayment(paymentEntity, true);
        } catch (Exception e) {
            throw new PaymentServiceException(ErrorCodeEnum.APPROVAL_INITIATE_ERROR,
                    "Error updating payment status after approval for paymentId " + requestData.getRequest().getPaymentId());
        }
    }

    /**
     * Get number of payments by payee id, client id and from date
     *
     * @param clientId String
     * @param payeeId  long
     * @param fromDate Timestamp
     * @return int
     */
    public int getPaymentCount(String clientId, long payeeId, Timestamp fromDate) {
        return paymentDBMapper.getPaymentCountByPayeeIdAndClientId(payeeId, clientId, fromDate);
    }

    /**
     * Retrieve and populate payment from payment id
     *
     * @param paymentId long
     * @param clientId  String
     * @return PaymentInitiationData
     * @throws PaymentServiceException e
     */
    @CollectException
    public PaymentInitiationData populatePayment(long paymentId, String clientId) throws PaymentServiceException {
        // get payment entity
        PaymentEntity paymentEntity = fetchManager.fetchPayment(paymentId, clientId, null);
        PaymentInitiationData payment = populatePaymentServiceObject(paymentEntity);
        payment.setEntries(new ArrayList<>());
        // get payment entry entities
        List<PaymentEntryEntity> entities = fetchManager.fetchPaymentEntry(paymentId);
        entities.forEach(entry -> {
            PaymentInitiationEntryData entryData = populatePaymentEntryServiceObject(entry, paymentEntity);
            paymentMapper.mapPaymentServiceObject(entryData, entry.getPaymentPurpose(), entry.getPaymentPurposeDesc(), entry.getPaymentPurposeFreeText(), entry.getInvoiceNumber(), entry.getInternalMemo());
            payment.getEntries().add(entryData);
        });
        return payment;
    }

    /**
     * Cancel payment
     * -    If a payment has recurring details with a single instance flag, a new payment gets created with canceled status
     * and existing series updated
     * -    Else payment is simply canceled
     *
     * @param requestData RequestData<PaymentCancellationData>
     * @throws PaymentServiceException e
     */
    @Transactional(rollbackFor = Exception.class)
    public void cancelPayment(RequestData<PaymentCancellationData> requestData) throws PaymentServiceException {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        PaymentCancellationData cancellationData = requestData.getRequest();
        PaymentStatus status;
        PaymentInitiationData initiationData = populatePayment(cancellationData.getPaymentId(), context.getClientId());
        if (cancellationData.isRecurring() && cancellationData.isSingleInstance()) {
            initiationData.getRecurringData().setSingleInstance(true);
            RequestData<PaymentInitiationData> newRequestData = new RequestData<>(initiationData, requestData.getGatewayContext());
            // update recurring details
            recurringUtil.populateRecurringDetails(newRequestData, initiationData.getNextPaymentDate(), initiationData.getRecurringData().getProcessedInstances());
            // edit existing series
            editManager.editPaymentSeries(newRequestData, context);
            // populate status
            status = initiationData.getPaymentStatus();
            // create canceled transaction
            this.createCancelledTransaction(newRequestData);
        } else {
            PaymentEntity paymentEntity = new PaymentEntity();
            paymentEntity.setPaymentId(cancellationData.getPaymentId());
            // populate status and remarks
            if (cancellationData.isBackOfficeCancel()) {
                status = PaymentStatus.CBNK;
                paymentEntity.setRemarks(getInvalidDealRemark());
            } else {
                status = cancellationData.isRecurring() ? PaymentStatus.SCAN : PaymentStatus.CURP;
            }
            paymentEntity.setStatus(status.toString());
            // TODO should this be the actual UserId or the modified by User_id
            paymentEntity.setUserId(context.getUserId());
            paymentStatusUtil.updatePayment(paymentEntity, false);
            // log activity
            this.createActivityLog(PAYMENT, requestData.getRequest().getPaymentId(), CommonConstant.LOG_CANCEL, 0, context.getUserId());
        }
        // assign back
        requestData.getRequest().setPaymentStatus(status);
        // populate additional details (for alert-audit)
        fetchManager.populateAdditionalDetails(requestData.getRequest(), initiationData);
    }

    /**
     * Cancel payment which is pending for approval
     *
     * @param context     PaymentContext
     * @param paymentData PaymentInitiationData
     */
    public void cancelPayment(PaymentContext context, PaymentInitiationData paymentData) {
        // update status
        PaymentEntity payment = new PaymentEntity();
        payment.setStatus(paymentData.getPaymentStatus().toString());
        payment.setUserId(context.getUserId());
        payment.setPaymentId(paymentData.getPaymentId());
        paymentStatusUtil.updatePayment(payment, false);
        // log activity
        this.createActivityLog(PAYMENT, paymentData.getPaymentId(), CommonConstant.LOG_CANCEL, 0, context.getUserId());
        // populate additional details (for alert-audit)
        fetchManager.populateAdditionalDetails(paymentData);
    }

    /**
     * Update transaction status
     *
     * @param details List<PaymentStatusDetails>
     * @param context PaymentContext
     */
    public void updateTransactionStatus(List<PaymentStatusDetails> details, PaymentContext context) {
        for (PaymentStatusDetails detail : details) {
            PaymentTransactionStatusEntity paymentTransactionStatusEntity = new PaymentTransactionStatusEntity();
            paymentTransactionStatusEntity.setTransactionId(detail.getTransactionId());
            paymentTransactionStatusEntity.setUpdatedBy(context.getActor());
            paymentTransactionStatusEntity.setRemarks(detail.getMessageDescription());
            paymentTransactionStatusEntity.setStatus(detail.getStatus());
            paymentStatusUtil.updateTransactionStatus(paymentTransactionStatusEntity, true);
        }
    }

    /**
     * revert limit
     * -    one time payment which is cancelled by user
     * -    recurring series which is cancelled before processing any instance
     *
     * @param cancellationData PaymentCancellationData
     * @param context          PaymentContext
     * @throws PaymentServiceException e
     */
    public void revertLimits(PaymentCancellationData cancellationData, PaymentContext context) throws PaymentServiceException {
        PaymentInitiationData initiationData = populatePayment(cancellationData.getPaymentId(), context.getClientId());
        if (!initiationData.getRecurringData().isRecurring()
                && initiationData.getPaymentStatus().equals(PaymentStatus.CURP)) {
            limitsService.revert(initiationData, context);
        } else if (initiationData.getRecurringData().isRecurring()
                && initiationData.getPaymentStatus().equals(PaymentStatus.SCAN)
                && initiationData.getRecurringData().getProcessedInstances() == 0) {
            limitsService.revert(initiationData, context);
        }
    }

    /**
     * revert limit
     * -    limit is consumed and payment is created but transaction not
     *
     * @param initiationData PaymentInitiationData
     * @param context        PaymentContext
     * @throws PaymentServiceException e
     */
    public void revertLimits(PaymentInitiationData initiationData, PaymentContext context) throws PaymentServiceException {
        if (initiationData.isLimitConsumed()
                && initiationData.getPaymentId() > 0
                && initiationData.getTransactionId() == 0) {
            limitsService.revert(initiationData, context);
        }
    }

    /**
     * Retrieve payment (and\or transaction) details
     *
     * @param context       PaymentContext
     * @param paymentId     long
     * @param transactionId long
     * @return PaymentDetailResponse
     */
    public PaymentDetailResponse retrieve(PaymentContext context, long paymentId, long transactionId) {
        List<PaymentDetail> paymentDetails = fetchManager.fetchPayment(context.getClientId(), paymentId, transactionId);
        PaymentDetailResponse response = new PaymentDetailResponse();
        response.addAll(paymentDetails);
        return response;
    }

    /**
     * Check payment request for duplicity
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return DuplicateCheckResponse
     * @throws PaymentServiceException e
     */
    public DuplicateCheckResponse duplicateCheck(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        // populate payment date from request date
        validateManager.validatePaymentForDate(requestData);
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        return fetchManager.fetchPayment(context.getClientId(), context.getUserId(), requestData.getRequest());
    }

    /**
     * Fetches a list of payment and transactions details based on the provided search criteria.
     *
     * @param criteria the search criteria used to filter the payments
     * @return a list of PaymentDetail objects that match the search criteria
     */
    public List<PaymentDetail> fetchPaymentsTransactions(PaymentSearchCriteria criteria) {
        return fetchManager.fetchPaymentsTransactions(criteria);
    }

    /**
     * Fetches a list of payment details based on the provided search criteria.
     *
     * @param criteria the search criteria used to filter the payments
     * @return a list of PaymentDetail objects that match the search criteria
     */
    public List<PayeePayment> fetchPayments(PaymentSearchCriteria criteria) {
        return fetchManager.fetchPayments(criteria);
    }

    /**
     * Get the transaction entry for the given transaction ID & Entry No
     *
     * @param transactionId long
     * @param entryNo       int
     */
    public TransactionEntryEntity getTransactionEntry(long transactionId, int entryNo) {
        return transactionEntryDBMapper.getTransactionEntry(transactionId, entryNo);
    }

    protected void createActivityLog(String module, long moduleId, String operation, long workFlowId, String createdBy) {
        try {
            // get activity
            ActivityLogEntity logEntity = new ActivityLogEntity();
            logEntity.setModule(module);
            logEntity.setModuleId(moduleId);
            logEntity.setOperation(operation);
            logEntity.setWorkflowId(workFlowId);
            logEntity.setCreatedTimestamp(dateUtil.getApplicationTimestamp());
            logEntity.setCreatedBy(createdBy);

            // create activity
            activityLogDBMapper.createActivityLog(logEntity);
        } catch (Exception ex) {
            log.error("error while creating activity log", ex);
        }
    }

    protected void createActivityLog(String module, List<Long> moduleIds, String operation, String createdBy) {
        try {
            Timestamp now = dateUtil.getApplicationTimestamp();
            List<ActivityLogEntity> logEntities = new ArrayList<>();
            for (Long moduleId : moduleIds) {
                // populate activity
                ActivityLogEntity logEntity = new ActivityLogEntity();
                logEntity.setModule(module);
                logEntity.setModuleId(moduleId);
                logEntity.setOperation(operation);
                logEntity.setCreatedTimestamp(now);
                logEntity.setCreatedBy(createdBy);
                logEntities.add(logEntity);
            }
            // create activity log
            if (!CollectionUtils.isEmpty(logEntities)) {
                activityLogDBMapper.createActivityLogs(logEntities);
            }
        } catch (Exception ex) {
            log.error("error while creating activity log", ex);
        }
    }

    /**
     * Cancel payments for input payment types and accounts
     *
     * @param context             PaymentContext
     * @param paymentTypeAccounts HashMap<String, List<String>>
     */
    public void cancelPayments(PaymentContext context, HashMap<String, List<String>> paymentTypeAccounts) {
        String remarks = getServiceRemovedRemark();
        paymentTypeAccounts.forEach((services, accounts) -> {
            List<Long> paymentIds = paymentDBMapper.getPaymentIdsByClientIdAndPaymentTypeAndDebitAccounts(context.getClientId(), List.of(services.split("\\|")), accounts);
            cancelPayment(context, paymentIds, remarks);
            this.createActivityLog(PAYMENT, paymentIds, CommonConstant.LOG_CANCEL, context.getUserId());
        });
    }

    public void cancelPayments(PaymentContext context, String account) {
        String remarks = getAccountClosureRemark(account);
        List<Long> paymentIds = paymentDBMapper.getPaymentIdsByClientIdAndPaymentTypeAndDebitAccounts(context.getClientId(), null, List.of(account));
        cancelPayment(context, paymentIds, remarks);
        this.createActivityLog(PAYMENT, paymentIds, CommonConstant.LOG_CANCEL, context.getUserId());
    }

    private void cancelPayment(PaymentContext context, List<Long> paymentIds, String remarks) {
        if (paymentIds.isEmpty()) {
            return;
        }
        int MAX_RECORDS_UPDATES = 999;
        int counter = 0;
        while (counter * MAX_RECORDS_UPDATES < paymentIds.size()) {
            List<Long> chunk = paymentIds.subList(counter * MAX_RECORDS_UPDATES, Math.min((counter + 1) * MAX_RECORDS_UPDATES, paymentIds.size()));
            List<PaymentEntity> payments = chunk.stream().map(paymentId -> {
                PaymentEntity paymentEntity = new PaymentEntity();
                paymentEntity.setPaymentId(paymentId);
                paymentEntity.setRemarks(remarks);
                paymentEntity.setStatus(PaymentStatus.CBNK.toString());
                return paymentEntity;
            }).toList();
            // TODO
            //paymentStatusUtil.updatePaymentsWithCommonStatus(payments, PaymentStatus.CBNK, true);
            paymentStatusUtil.updateMultiplePaymentsWithCommonStatusAndRemark(payments, PaymentStatus.CBNK, remarks, true);
            try {
                cancelWorkflow(context, chunk, "service removed or account closed");
            } catch (PaymentServiceException e) {
                log.error("workflow cancel::{} {}", ATTENTION, e.getMessage(), e);
            }
            counter++;
        }
    }

    /**
     * Canceled workflow at approval MS
     *
     * @param context    PaymentContext
     * @param paymentIds List<Long> paymentIds
     * @param reason     String
     */
    public void cancelWorkflow(PaymentContext context, List<Long> paymentIds, String reason) throws PaymentServiceException {
        List<WorkflowId> list = paymentDBMapper.getWorkflowIds(paymentIds);
        if (!list.isEmpty()) {
            List<WorkflowId> workflowIds = list.stream().filter(workflowId -> workflowId.getWorkflowId() > 0).toList();
            if (workflowIds.isEmpty()) {
                log.info("workflow cancel::{} not needed", context.log());
            } else {
                approvalsService.cancelWorkflow(context, workflowIds, reason, CommonConstant.MODULE_PAYMENTS);
            }
        }
    }

    private String getServiceRemovedRemark() {
        Timestamp now = dateUtil.getApplicationTimestamp();
        SimpleDateFormat dateTimeFormatter = new SimpleDateFormat("MMM dd, yyyy");
        return String.format("Service removed on %s. For assistance, contact SVB Client Support.", dateTimeFormatter.format(now));
    }

    private String getAccountClosureRemark(String account) {
        Timestamp now = dateUtil.getApplicationTimestamp();
        account = StringUtils.hasLength(account) && account.length() > PaymentConstant.ACCOUNT_INFO_LENGTH ?
                "***" + account.substring(account.length() - PaymentConstant.ACCOUNT_INFO_LENGTH)
                : "";
        SimpleDateFormat dateTimeFormatter = new SimpleDateFormat("MMM dd, yyyy");
        return String.format("Account %s closed on %s. To continue, create a new payment with an active account.", account, dateTimeFormatter.format(now));
    }

    private String getInvalidDealRemark() {
        Timestamp now = dateUtil.getApplicationTimestamp();
        SimpleDateFormat dateTimeFormatter = new SimpleDateFormat("MMM dd, yyyy hh:mm a");
        return String.format("Deal is no longer valid as of %s PT", dateTimeFormatter.format(now));
    }
}
