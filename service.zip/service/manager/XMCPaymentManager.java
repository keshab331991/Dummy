package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.mapper.db.ActivityLogDbMapper;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationEntryData;
import com.svb.gateway.payments.common.model.payment.processing.CrossCurrencyPaymentData;
import com.svb.gateway.payments.common.service.AccountsService;
import com.svb.gateway.payments.common.service.ApprovalsService;
import com.svb.gateway.payments.common.service.BanksService;
import com.svb.gateway.payments.common.util.AmountCurrencyUtil;
import com.svb.gateway.payments.common.util.CountryRulesUtil;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.payment.entity.PaymentEntryEntity;
import com.svb.gateway.payments.payment.entity.TransactionEntryEntity;
import com.svb.gateway.payments.payment.mapper.db.PaymentDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.entity.PaymentMapper;
import com.svb.gateway.payments.payment.mapper.entity.TransactionMapper;
import com.svb.gateway.payments.payment.mapper.model.KafkaHostMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.service.FXService;
import com.svb.gateway.payments.payment.service.LimitsService;
import com.svb.gateway.payments.payment.service.host.PaymentKafkaHost;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import com.svb.gateway.payments.payment.util.RecurringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import static com.svb.gateway.payments.common.constants.BankConfigConstant.ABA;
import static com.svb.gateway.payments.common.constants.BankConfigConstant.SWIFT;

@Slf4j
@Service("XMC")
public class XMCPaymentManager extends PaymentManager {

    private final AccountsService accountsService;
    private final PaymentMapper paymentMapper;
    private final TransactionMapper transactionMapper;
    private final BanksService banksService;
    private final KafkaHostMapper kafkaHostMapper;
    private final DateUtil dateUtil;
    private final FXService fxService;
    private final AmountCurrencyUtil amountCurrencyUtil;

    public XMCPaymentManager(AccountsService accountsService,
                             ApprovalsService approvalsService,
                             RecurringUtil recurringUtil,
                             DateUtil dateUtil,
                             PaymentMapper paymentMapper,
                             PaymentDBMapper paymentDBMapper,
                             TransactionDBMapper transactionDBMapper,
                             TransactionEntryDBMapper transactionEntryDBMapper,
                             KafkaHostMapper kafkaHostMapper,
                             PaymentKafkaHost paymentKafkaHost,
                             BanksService banksService,
                             LimitsService limitsService,
                             CountryRulesUtil countryRulesUtil,
                             PaymentManagerFetch fetchManager,
                             PaymentManagerValidate validateManager,
                             PaymentManagerCreate createManager,
                             PaymentManagerEdit editManager,
                             ActivityLogDbMapper activityLogDBMapper,
                             TransactionMapper transactionMapper,
                             FXService fxService,
                             AmountCurrencyUtil amountCurrencyUtil,
                             PaymentStatusUtil paymentStatusUtil) {

        super(accountsService,
                approvalsService,
                recurringUtil,
                dateUtil,
                paymentMapper,
                paymentDBMapper,
                transactionDBMapper,
                transactionEntryDBMapper,
                kafkaHostMapper,
                paymentKafkaHost,
                limitsService,
                countryRulesUtil,
                fetchManager,
                validateManager,
                createManager,
                editManager,
                activityLogDBMapper,
                paymentStatusUtil);

        this.accountsService = accountsService;
        this.paymentMapper = paymentMapper;
        this.banksService = banksService;
        this.kafkaHostMapper = kafkaHostMapper;
        this.dateUtil = dateUtil;
        this.transactionMapper = transactionMapper;
        this.fxService = fxService;
        this.amountCurrencyUtil = amountCurrencyUtil;
    }

    /**
     * Populate debit and credit account details
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    @Override
    public void populateAccountDetails(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        // populate debit account
        super.populateAccountDetails(requestData);
        // populate a credit account
        accountsService.populateCreditAccountDetails((PaymentContext)requestData.getGatewayContext(), requestData.getRequest(), null);
    }

    /**
     * Populate debit and credit account bank details
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    public void populateBankDetails(RequestData<PaymentInitiationData> requestData) {
        banksService.populateDebitBankDetails(requestData.getGatewayContext(), requestData.getRequest(), true, ABA);
        banksService.populateCreditBankDetails(requestData.getGatewayContext(), requestData.getRequest(), true, SWIFT);
    }

    /**
     * @param requestData RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    @Override
    public void validatePayment(RequestData<PaymentInitiationData> requestData, String operation) throws PaymentServiceException {
        try {
            amountCurrencyUtil.populateLimitAmount(requestData.getRequest());
            fxService.validate(requestData);
        } catch (Exception e) {
            log.error("payment validation::{}, flow {}, error {}, {}", requestData.getRequest().getPaymentType(),
                    operation, e.getMessage(),
                    requestData.getGatewayContext().log());
            throw e;
        }
        super.validatePayment(requestData, operation);
    }

    /**
     * Populate payment entry entity
     *
     * @param context          PaymentContext
     * @param paymentEntry     PaymentEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populatePaymentEntryEntity(PaymentContext context, PaymentEntryEntity paymentEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        super.populatePaymentEntryEntity(context, paymentEntry, paymentInitiationEntryData);

        // populate cross-currency data
        paymentMapper.mapPaymentEntryEntity(paymentEntry, paymentInitiationEntryData.getCrossCurrencyPaymentData());
        // populate dates
        if (paymentInitiationEntryData.getCrossCurrencyPaymentData().getTradeDate() != null
                && !paymentInitiationEntryData.getCrossCurrencyPaymentData().getTradeDate().isEmpty()) {
            // format date to keep it consistent (user-input or wss returned)
            paymentInitiationEntryData.setTradeDate(dateUtil.getTimestamp(paymentInitiationEntryData.getNetworkTimeZone(), paymentInitiationEntryData.getCrossCurrencyPaymentData().getTradeDate().replace("-", "") + CommonConstant.ZERO_TIME_COMPONENT, dateFormatterWSS));
            paymentEntry.setContractTradeDate(paymentInitiationEntryData.getTradeDate());
        }
        if (paymentInitiationEntryData.getCrossCurrencyPaymentData().getValueDate() != null
                && !paymentInitiationEntryData.getCrossCurrencyPaymentData().getValueDate().isEmpty()) {
            paymentInitiationEntryData.setValueDate(dateUtil.getTimestamp(paymentInitiationEntryData.getNetworkTimeZone(), paymentInitiationEntryData.getCrossCurrencyPaymentData().getValueDate().replace("-", "") + CommonConstant.ZERO_TIME_COMPONENT, dateFormatterWSS));
            paymentEntry.setContractValueDate(paymentInitiationEntryData.getValueDate());
        }
    }

    /**
     * Confirm fx quote and then create payment and transaction
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    public void createPayment(RequestData<PaymentInitiationData> requestData)
            throws PaymentServiceException {
        // book quote
        fxService.bookQuote(requestData);
        super.createPayment(requestData);
    }

    @Override
    public void approvePayment(RequestData<PaymentInitiationData> requestData)
            throws PaymentServiceException {
        // book quote
        fxService.bookQuote(requestData);
        super.approvePayment(requestData);
    }

    /**
     * Populate transaction entry entity
     *
     * @param context          PaymentContext
     * @param transactionEntry TransactionEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateTransactionEntryEntity(PaymentContext context, TransactionEntryEntity transactionEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        super.populateTransactionEntryEntity(context, transactionEntry, paymentInitiationEntryData);

        // populate cross-currency data
        transactionMapper.mapTransactionEntryEntity(transactionEntry, paymentInitiationEntryData.getCrossCurrencyPaymentData());
        // populate dates
        transactionEntry.setContractTradeDate(paymentInitiationEntryData.getTradeDate());
        transactionEntry.setContractValueDate(paymentInitiationEntryData.getValueDate());
        /* override debit amount
         * credit amount will always be the transaction amount */
        transactionEntry.setDebitAmount(paymentInitiationEntryData.getDebitAccountData().getCcyAmt());
    }

    /**
     * Populate a host message with a transaction type
     *
     * @param context     PaymentContext
     * @param message     ProcessingMessage
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateHostMessage(PaymentContext context, ProcessingMessage message, RequestData<PaymentInitiationData> requestData) {
        super.populateHostMessage(context, message, requestData);

        PaymentInitiationEntryData entryData = requestData.getRequest().getEntries().getFirst();
        message.getPaymentData().setCrossCurrencyPaymentData(new CrossCurrencyPaymentData());

        // set cross-currency data
        kafkaHostMapper.mapHostMessage(message.getPaymentData(), entryData.getCrossCurrencyPaymentData());
        // set formatted dates to host a message
        message.getPaymentData().getCrossCurrencyPaymentData().setValueDate(dateUtil.getTimestamp(entryData.getValueDate(), entryData.getNetworkTimeZone(), dateFormatter));
        message.getPaymentData().getCrossCurrencyPaymentData().setTradeDate(dateUtil.getTimestamp(entryData.getTradeDate(), entryData.getNetworkTimeZone(), dateFormatter));
        // set formatted dates to back to a business object
        entryData.getCrossCurrencyPaymentData().setValueDate(message.getPaymentData().getCrossCurrencyPaymentData().getValueDate());
        entryData.getCrossCurrencyPaymentData().setTradeDate(message.getPaymentData().getCrossCurrencyPaymentData().getTradeDate());

        message.getPaymentData().setTxnType(PaymentConstant.TXN_TRA);
    }

    @Override
    protected void createRecurring(RequestData<PaymentInitiationData> requestData) {
        // no action
    }
}
