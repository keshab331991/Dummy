package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.payment.PaymentStatus;
import com.svb.gateway.payments.common.enums.payment.PaymentType;
import com.svb.gateway.payments.common.enums.payment.TransactionStatus;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.mapper.db.ActivityLogDbMapper;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.PaymentStatusDetails;
import com.svb.gateway.payments.common.model.payment.cancellation.PaymentCancellationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationEntryData;
import com.svb.gateway.payments.common.service.AccountsService;
import com.svb.gateway.payments.common.service.ApprovalsService;
import com.svb.gateway.payments.common.service.BanksService;
import com.svb.gateway.payments.common.util.CountryRulesUtil;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.payment.entity.*;
import com.svb.gateway.payments.payment.mapper.db.PaymentDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.RecurringDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.entity.PaymentMapper;
import com.svb.gateway.payments.payment.mapper.entity.RecurringMapper;
import com.svb.gateway.payments.payment.mapper.entity.TransactionMapper;
import com.svb.gateway.payments.payment.mapper.model.KafkaHostMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.service.LimitsService;
import com.svb.gateway.payments.payment.service.host.BillPayService;
import com.svb.gateway.payments.payment.service.host.PaymentKafkaHost;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import com.svb.gateway.payments.payment.util.RecurringUtil;
import com.svb.gateway.payments.payment.validator.DataValidator;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

import static com.svb.gateway.payments.common.constants.BankConfigConstant.ABA;
import static com.svb.gateway.payments.common.util.PaymentConstant.TRANSACTION;

@Service("CHK")
public class CHKPaymentManager extends PaymentManager {

    private final PaymentMapper paymentMapper;
    private final TransactionMapper transactionMapper;
    private final KafkaHostMapper kafkaHostMapper;
    private final BanksService banksService;
    private final DataValidator dataValidator;
    private final RecurringUtil recurringUtil;
    private final RecurringDBMapper recurringDBMapper;
    private final RecurringMapper recurringMapper;
    private final BillPayService billPayHost;
    private final DateUtil dateUtil;
    private final TransactionEntryDBMapper transactionEntryDBMapper;
    private final PaymentStatusUtil paymentStatusUtil;

    public CHKPaymentManager(AccountsService accountsService,
                             ApprovalsService approvalsService,
                             RecurringUtil recurringUtil,
                             DateUtil dateUtil,
                             RecurringMapper recurringMapper,
                             PaymentMapper paymentMapper,
                             TransactionMapper transactionMapper,
                             RecurringDBMapper recurringDBMapper,
                             PaymentDBMapper paymentDBMapper,
                             TransactionDBMapper transactionDBMapper,
                             TransactionEntryDBMapper transactionEntryDBMapper,
                             KafkaHostMapper kafkaHostMapper,
                             PaymentKafkaHost paymentKafkaHost,
                             BanksService banksService,
                             DataValidator dataValidator,
                             BillPayService billPayHost,
                             LimitsService limitsService,
                             CountryRulesUtil countryRulesUtil,
                             PaymentManagerFetch fetchManager,
                             PaymentManagerValidate validateManager,
                             PaymentManagerCreate createManager,
                             PaymentManagerEdit editManager,
                             ActivityLogDbMapper activityLogDBMapper,
                             PaymentStatusUtil paymentStatusUtil) {

        super(accountsService,
                approvalsService,
                recurringUtil,
                dateUtil,
                paymentMapper,
                paymentDBMapper,
                transactionDBMapper,
                transactionEntryDBMapper,
                kafkaHostMapper,
                paymentKafkaHost,
                limitsService,
                countryRulesUtil,
                fetchManager,
                validateManager,
                createManager,
                editManager,
                activityLogDBMapper,
                paymentStatusUtil);

        this.paymentMapper = paymentMapper;
        this.kafkaHostMapper = kafkaHostMapper;
        this.banksService = banksService;
        this.dataValidator = dataValidator;
        this.recurringUtil = recurringUtil;
        this.recurringDBMapper = recurringDBMapper;
        this.recurringMapper = recurringMapper;
        this.billPayHost = billPayHost;
        this.dateUtil = dateUtil;
        this.transactionEntryDBMapper = transactionEntryDBMapper;
        this.transactionMapper = transactionMapper;
        this.paymentStatusUtil = paymentStatusUtil;
    }

    /**
     * Populate debit account bank details
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    public void populateBankDetails(RequestData<PaymentInitiationData> requestData) {
        banksService.populateDebitBankDetails(requestData.getGatewayContext(), requestData.getRequest(), true, ABA);
    }

    /***
     * Populate payment entity and then recurring details
     * @param context     PaymentContext
     * @param payment     PaymentEntity
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populatePaymentEntity(PaymentContext context, PaymentEntity payment, RequestData<PaymentInitiationData> requestData) {
        super.populatePaymentEntity(context, payment, requestData);

        paymentMapper.mapPaymentEntity(payment, requestData.getRequest().getRecurringData());
        // override payment date
        if (requestData.getRequest().getRecurringData().isRecurring()) {
            payment.setPaymentDate(requestData.getRequest().getNextPaymentDate());
        }
    }

    /**
     * Populate payment entry
     *
     * @param context                    PaymentContext
     * @param paymentEntry               PaymentEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populatePaymentEntryEntity(PaymentContext context, PaymentEntryEntity paymentEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        super.populatePaymentEntryEntity(context, paymentEntry, paymentInitiationEntryData);
        paymentMapper.mapPaymentEntryEntity(paymentEntry, paymentInitiationEntryData.getBillPayData());
        // check and populate OBO data
        if (paymentInitiationEntryData.getOboData() != null) {
            paymentMapper.mapPaymentEntryEntity(paymentEntry, paymentInitiationEntryData.getOboData());
        }
    }

    /**
     * Populate transaction entry
     *
     * @param context                    PaymentContext
     * @param transactionEntry           TransactionEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateTransactionEntryEntity(PaymentContext context, TransactionEntryEntity transactionEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        super.populateTransactionEntryEntity(context, transactionEntry, paymentInitiationEntryData);
        transactionMapper.mapPaymentEntryEntity(transactionEntry, paymentInitiationEntryData.getBillPayData());
        // check and populate OBO data
        if (paymentInitiationEntryData.getOboData() != null) {
            transactionMapper.mapTransactionEntryEntity(transactionEntry, paymentInitiationEntryData.getOboData());
        }
    }

    /**
     * Populate the host message with additional bill pay attributes
     *
     * @param context     PaymentContext
     * @param message     ProcessingMessage
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateHostMessage(PaymentContext context, ProcessingMessage message, RequestData<PaymentInitiationData> requestData) {
        super.populateHostMessage(context, message, requestData);

        PaymentInitiationEntryData entryData = requestData.getRequest().getEntries().getFirst();
        // CHK is not eligible for split, hence there will always be a single entry
        kafkaHostMapper.mapHostMessage(message.getPaymentData(), entryData.getBillPayData());
        if (message.getPaymentData().getAddPayDetails() != null) {
            kafkaHostMapper.mapBillPayAttributes(message.getPaymentData().getAddPayDetails().getAdditionalBillPayAttributes(), requestData.getRequest());
            kafkaHostMapper.mapBillPayAttributes(message.getPaymentData().getAddPayDetails().getAdditionalBillPayAttributes(), entryData);
        }
        if (entryData.getOboData() != null) {
            kafkaHostMapper.mapHostMessage(message.getPaymentData(), entryData.getOboData());
        }
        message.getPaymentData().setTxnType(PaymentType.CHK.toString());
    }

    @Override
    protected void validatePayment(RequestData<PaymentInitiationData> requestData, PaymentInitiationData existingPayment) throws PaymentServiceException {
        super.validatePayment(requestData, existingPayment);
        dataValidator.validatePayee(requestData.getRequest(), existingPayment);
        validateRecurring(requestData, existingPayment);
    }

    private void validateRecurring(RequestData<PaymentInitiationData> requestData, PaymentInitiationData existingPayment) throws PaymentServiceException {
        if (!requestData.getRequest().getRecurringData().isRecurring()) {
            return;
        }
        dataValidator.validateRecurringData(requestData.getRequest(), existingPayment);
        int processedInstances = Optional.ofNullable(requestData.getRequest().getRecurringData().getProcessedInstances()).orElse(0);
        recurringUtil.populateRecurringDetails(requestData, existingPayment.getNextPaymentDate(), processedInstances);
    }

    @Override
    protected List<String> getAllowedPaymentStatusForCancellation() {
        return List.of(PaymentStatus.PNAP.toString(), PaymentStatus.PNFA.toString(), PaymentStatus.ACMP.toString(), PaymentStatus.COMP.toString());
    }

    @Override
    protected List<String> getAllowedTransactionStatusForCancellation() {
        return List.of(TransactionStatus.INPR.toString(), TransactionStatus.SENT.toString());
    }

    @Override
    protected boolean transactionStatusUpdateAllowed() {
        return true;
    }

    @Override
    protected List<String> getAllowedTransactionStatusForUpdate() {
        return List.of(TransactionStatus.INPR.toString(),
                TransactionStatus.SENT.toString(),
                TransactionStatus.PVOD.toString());
    }

    @Override
    public PaymentInitiationData populatePayment(long paymentId, String clientId) throws PaymentServiceException {
        PaymentInitiationData data = super.populatePayment(paymentId, clientId);
        if (data.getRecurringData() != null && data.getRecurringData().isRecurring()) {
            // get existing entry
            RecurrenceEntity recurring = recurringDBMapper.getRecurrence(data.getRecurringData().getRecurrenceId());
            recurringMapper.mapRecurringServiceObject(data.getRecurringData(), recurring);
        }
        return data;
    }

    /**
     * Cancel payment in DB or cancel payment in Bill_Pay MS
     * and update transaction in DB
     *
     * @param requestData RequestData<PaymentCancellationData>
     * @throws PaymentServiceException e
     */
    @Override
    public void cancelPayment(RequestData<PaymentCancellationData> requestData) throws PaymentServiceException {
        if (requestData.getRequest().getTransactionId() == 0) {
            super.cancelPayment(requestData);
        } else {
            TransactionStatus status = billPayHost.cancelPayment(requestData.getRequest());
            requestData.getRequest().setTransactionStatus(status);
            PaymentTransactionStatusEntity paymentTransactionStatusEntity = new PaymentTransactionStatusEntity();
            paymentTransactionStatusEntity.setStatus(status.toString());
            paymentTransactionStatusEntity.setUpdatedBy(requestData.getGatewayContext().getUserId());
            paymentTransactionStatusEntity.setTransactionId(requestData.getRequest().getTransactionId());
            paymentTransactionStatusEntity.setPaymentId(requestData.getRequest().getPaymentId());
            paymentStatusUtil.updateEntireStatus(paymentTransactionStatusEntity, true);
            // added to activity logs
            super.createActivityLog(TRANSACTION, requestData.getRequest().getTransactionId(), CommonConstant.LOG_CANCEL, 0, requestData.getGatewayContext().getUserId());
        }
    }

    /**
     * Update transaction status in transaction and transaction entry tables
     *
     * @param details List<PaymentStatusDetails>
     * @param context PaymentContext
     */
    @Override
    public void updateTransactionStatus(List<PaymentStatusDetails> details, PaymentContext context) {
        super.updateTransactionStatus(details, context);

        Timestamp now = dateUtil.getApplicationTimestamp();
        for (PaymentStatusDetails detail : details) {
            // transaction update
            transactionEntryDBMapper.updateTransactionEntryForACHCHK(detail.getStatus(),
                    detail.getBillPayReferenceNumber(),
                    detail.getCheckNumber(),
                    detail.getCheckStatus(),
                    context.getActor(),
                    now,
                    detail.getTransactionId(),
                    1);
        }
    }

    /**
     * Get key used for kafka posting
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return String
     */
    @Override
    protected String getKey(RequestData<PaymentInitiationData> requestData) {
        return requestData.getGatewayContext().getClientId();
    }
}
