package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.mapper.db.ActivityLogDbMapper;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationEntryData;
import com.svb.gateway.payments.common.model.payment.processing.PaymentProcessingData;
import com.svb.gateway.payments.common.model.rulesengine.RuleData;
import com.svb.gateway.payments.common.service.AccountsService;
import com.svb.gateway.payments.common.service.ApprovalsService;
import com.svb.gateway.payments.common.service.BanksService;
import com.svb.gateway.payments.common.util.AmountCurrencyUtil;
import com.svb.gateway.payments.common.util.CountryRulesUtil;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.payment.entity.PaymentEntryEntity;
import com.svb.gateway.payments.payment.entity.TransactionEntryEntity;
import com.svb.gateway.payments.payment.mapper.db.PaymentDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.entity.PaymentMapper;
import com.svb.gateway.payments.payment.mapper.entity.TransactionMapper;
import com.svb.gateway.payments.payment.mapper.model.KafkaHostMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.model.ProcessingSplitMessage;
import com.svb.gateway.payments.payment.service.FXService;
import com.svb.gateway.payments.payment.service.LimitsService;
import com.svb.gateway.payments.payment.service.host.PaymentKafkaHost;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import com.svb.gateway.payments.payment.util.RecurringUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service("FXW")
public class FXWPaymentManager extends FXGPaymentManager {

    private final PaymentMapper paymentMapper;
    private final TransactionMapper transactionMapper;
    private final KafkaHostMapper kafkaHostMapper;
    private final CountryRulesUtil countryRulesUtil;

    public FXWPaymentManager(AccountsService accountsService,
                             ApprovalsService approvalsService,
                             RecurringUtil recurringUtil,
                             DateUtil dateUtil,
                             PaymentMapper paymentMapper,
                             TransactionMapper transactionMapper,
                             PaymentDBMapper paymentDBMapper,
                             TransactionDBMapper transactionDBMapper,
                             TransactionEntryDBMapper transactionEntryDBMapper,
                             KafkaHostMapper kafkaHostMapper,
                             PaymentKafkaHost paymentKafkaHost,
                             BanksService banksService,
                             FXService fxService,
                             LimitsService limitsService,
                             AmountCurrencyUtil amountCurrencyUtil,
                             CountryRulesUtil countryRulesUtil,
                             PaymentManagerFetch fetchManager,
                             PaymentManagerValidate validateManager,
                             PaymentManagerCreate createManager,
                             PaymentManagerEdit editManager,
                             ActivityLogDbMapper activityLogDBMapper,
                             PaymentStatusUtil paymentStatusUtil) {

        super(accountsService,
                approvalsService,
                recurringUtil,
                dateUtil,
                paymentMapper,
                transactionMapper,
                paymentDBMapper,
                transactionDBMapper,
                transactionEntryDBMapper,
                kafkaHostMapper,
                paymentKafkaHost,
                banksService,
                fxService,
                limitsService,
                amountCurrencyUtil,
                countryRulesUtil,
                fetchManager,
                validateManager,
                createManager,
                editManager,
                activityLogDBMapper,
                paymentStatusUtil);

        this.paymentMapper = paymentMapper;
        this.transactionMapper = transactionMapper;
        this.kafkaHostMapper = kafkaHostMapper;
        this.countryRulesUtil = countryRulesUtil;
    }

    /**
     * Validate request data for country specific rules
     *
     * @param context     PaymentContext
     * @param paymentData PaymentInitiationData
     * @param entryData   PaymentInitiationEntryData
     * @param ruleData    RuleData
     */
    @Override
    protected void validatePayment(PaymentContext context, PaymentInitiationData paymentData, PaymentInitiationEntryData entryData, RuleData ruleData) throws PaymentServiceException {
        countryRulesUtil.validatePayeeAccount(context, entryData, ruleData);
        countryRulesUtil.validateLocalRouting(context, entryData, ruleData);
        countryRulesUtil.validatePaymentPurpose(context, entryData, ruleData);
    }

    /**
     * Populate payment entry entity
     *
     * @param context          PaymentContext
     * @param paymentEntry     PaymentEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populatePaymentEntryEntity(PaymentContext context, PaymentEntryEntity paymentEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        super.populatePaymentEntryEntity(context, paymentEntry, paymentInitiationEntryData);

        // check and populate IB data
        if (paymentInitiationEntryData.getIntermediaryBankData() != null) {
            /*REFACTOR*/
            //paymentInitiationEntryData.setIntermediaryBankData(bankService.getBankDetails(paymentInitiationEntryData.getIntermediaryBankData().getRoutingCode(), paymentInitiationEntryData.getIntermediaryBankData().getRoutingType()));
            paymentMapper.mapPaymentEntryEntity(paymentEntry, paymentInitiationEntryData.getIntermediaryBankData());
        }
    }

    /**
     * Populate transaction entry entity
     *
     * @param context          PaymentContext
     * @param transactionEntry TransactionEntryEntity
     * @param paymentInitiationEntryData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateTransactionEntryEntity(PaymentContext context, TransactionEntryEntity transactionEntry, PaymentInitiationEntryData paymentInitiationEntryData) {
        super.populateTransactionEntryEntity(context, transactionEntry, paymentInitiationEntryData);

        // check and populate IB data
        if (paymentInitiationEntryData.getIntermediaryBankData() != null) {
            transactionMapper.mapTransactionEntryEntity(transactionEntry, paymentInitiationEntryData.getIntermediaryBankData());
        }
    }

    /**
     * Populate host message with cross-currency and IB details, txnType
     *
     * @param context     PaymentContext
     * @param message     ProcessingMessage
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateHostMessage(PaymentContext context, ProcessingMessage message, RequestData<PaymentInitiationData> requestData) {
        super.populateHostMessage(context, message, requestData);

        PaymentInitiationEntryData entryData = requestData.getRequest().getEntries().getFirst();
        // check and set IB data
        if (entryData.getIntermediaryBankData() != null) {
            kafkaHostMapper.mapHostMessage(message.getPaymentData(), entryData.getIntermediaryBankData());
        }
    }

    /**
     * Populate host message with cross-currency and IB details, txnType
     *
     * @param context     PaymentContext
     * @param message     ProcessingSplitMessage
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateHostMessage(PaymentContext context, ProcessingSplitMessage message, RequestData<PaymentInitiationData> requestData) {
        super.populateHostMessage(context, message, requestData);
        long transactionId = requestData.getRequest().getTransactionId();
        for (PaymentInitiationEntryData entryData : requestData.getRequest().getEntries()) {
            PaymentProcessingData paymentData = message.getPaymentData().stream().
                    filter(p -> p.getRequestSerialNo().equals(entryData.getEntryNumber()))
                    .findFirst().orElse(null);
            if (paymentData != null && entryData.getIntermediaryBankData() != null) {
                // check and set IB data
                kafkaHostMapper.mapHostMessage(paymentData, entryData.getIntermediaryBankData());
            }
        }
    }
}