package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.payment.WireType;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.mapper.db.ActivityLogDbMapper;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.service.AccountsService;
import com.svb.gateway.payments.common.service.ApprovalsService;
import com.svb.gateway.payments.common.service.BanksService;
import com.svb.gateway.payments.common.util.AmountCurrencyUtil;
import com.svb.gateway.payments.common.util.CountryRulesUtil;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.payment.mapper.db.PaymentDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.RecurringDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.entity.PaymentMapper;
import com.svb.gateway.payments.payment.mapper.entity.RecurringMapper;
import com.svb.gateway.payments.payment.mapper.entity.TransactionMapper;
import com.svb.gateway.payments.payment.mapper.model.KafkaHostMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.service.LimitsService;
import com.svb.gateway.payments.payment.service.host.PaymentKafkaHost;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import com.svb.gateway.payments.payment.util.RecurringUtil;
import com.svb.gateway.payments.payment.validator.DataValidator;
import org.springframework.stereotype.Service;

@Service("ICA")
public class ICAPaymentManager extends USIPaymentManager {

    private final BanksService banksService;
    private final AccountsService accountsService;
    private final AmountCurrencyUtil amountCurrencyUtil;

    public ICAPaymentManager(AccountsService accountsService,
                             ApprovalsService approvalsService,
                             RecurringUtil recurringUtil,
                             DateUtil dateUtil,
                             RecurringMapper recurringMapper,
                             PaymentMapper paymentMapper,
                             TransactionMapper transactionMapper,
                             RecurringDBMapper recurringDBMapper,
                             PaymentDBMapper paymentDBMapper,
                             TransactionDBMapper transactionDBMapper,
                             TransactionEntryDBMapper transactionEntryDBMapper,
                             KafkaHostMapper kafkaHostMapper,
                             PaymentKafkaHost paymentKafkaHost,
                             BanksService banksService,
                             DataValidator dataValidator,
                             LimitsService limitsService,
                             AmountCurrencyUtil amountCurrencyUtil,
                             CountryRulesUtil countryRulesUtil,
                             PaymentManagerFetch fetchManager,
                             PaymentManagerValidate validateManager,
                             PaymentManagerCreate createManager,
                             PaymentManagerEdit editManager,
                             ActivityLogDbMapper activityLogDBMapper,
                             PaymentStatusUtil paymentStatusUtil) {

        super(accountsService,
                approvalsService,
                recurringUtil,
                dateUtil,
                recurringMapper,
                paymentMapper,
                transactionMapper,
                recurringDBMapper,
                paymentDBMapper,
                transactionDBMapper,
                transactionEntryDBMapper,
                kafkaHostMapper,
                paymentKafkaHost,
                banksService,
                dataValidator,
                limitsService,
                countryRulesUtil,
                fetchManager,
                validateManager,
                createManager,
                editManager,
                activityLogDBMapper,
                paymentStatusUtil);

        this.banksService = banksService;
        this.accountsService = accountsService;
        this.amountCurrencyUtil = amountCurrencyUtil;
    }

    /**
     * Populate debit account details
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    @Override
    public void populateAccountDetails(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        // populate debit account
        accountsService.populateDebitAccountDetails((PaymentContext) requestData.getGatewayContext(), requestData.getRequest(), "ICA,BMOICA");
    }

    /**
     * Populate debit account bank details
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    public void populateBankDetails(RequestData<PaymentInitiationData> requestData) {
        banksService.populateDebitBankDetails(requestData.getGatewayContext(), requestData.getRequest(), false, null);
    }

    /**
     * Validate request data
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    @Override
    public void validatePayment(RequestData<PaymentInitiationData> requestData, String operation) throws PaymentServiceException {
        amountCurrencyUtil.populateLimitAmount(requestData.getRequest());
        super.validatePayment(requestData, operation);
    }

    /**
     * Populate host message with IB details, txnType and wireType
     *
     * @param context     PaymentContext
     * @param message     ProcessingMessage
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateHostMessage(PaymentContext context, ProcessingMessage message, RequestData<PaymentInitiationData> requestData) {
        super.populateHostMessage(context, message, requestData);
        message.getPaymentData().setWireType(WireType.FCA);
    }
}
