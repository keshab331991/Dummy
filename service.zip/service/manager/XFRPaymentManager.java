package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.mapper.db.ActivityLogDbMapper;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.service.AccountsService;
import com.svb.gateway.payments.common.service.ApprovalsService;
import com.svb.gateway.payments.common.service.BanksService;
import com.svb.gateway.payments.common.util.CountryRulesUtil;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.payment.entity.PaymentEntity;
import com.svb.gateway.payments.payment.entity.RecurrenceEntity;
import com.svb.gateway.payments.payment.mapper.db.PaymentDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.RecurringDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.entity.PaymentMapper;
import com.svb.gateway.payments.payment.mapper.entity.RecurringMapper;
import com.svb.gateway.payments.payment.mapper.model.KafkaHostMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.service.LimitsService;
import com.svb.gateway.payments.payment.service.host.PaymentKafkaHost;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import com.svb.gateway.payments.payment.util.RecurringUtil;
import com.svb.gateway.payments.payment.validator.DataValidator;
import org.springframework.stereotype.Service;

import static com.svb.gateway.payments.common.constants.BankConfigConstant.ABA;

@Service("XFR")
public class XFRPaymentManager extends PaymentManager {

    private final AccountsService accountsService;
    private final PaymentMapper paymentMapper;
    private final BanksService banksService;
    private final DataValidator dataValidator;
    private final RecurringUtil recurringUtil;
    private final RecurringDBMapper recurringDBMapper;
    private final RecurringMapper recurringMapper;

    public XFRPaymentManager(AccountsService accountsService,
                             ApprovalsService approvalsService,
                             RecurringUtil recurringUtil,
                             DateUtil dateUtil,
                             RecurringMapper recurringMapper,
                             PaymentMapper paymentMapper,
                             RecurringDBMapper recurringDBMapper,
                             PaymentDBMapper paymentDBMapper,
                             TransactionDBMapper transactionDBMapper,
                             TransactionEntryDBMapper transactionEntryDBMapper,
                             KafkaHostMapper kafkaHostMapper,
                             PaymentKafkaHost paymentKafkaHost,
                             BanksService banksService,
                             DataValidator dataValidator,
                             LimitsService limitsService,
                             CountryRulesUtil countryRulesUtil,
                             PaymentManagerFetch fetchManager,
                             PaymentManagerValidate validateManager,
                             PaymentManagerCreate createManager,
                             PaymentManagerEdit editManager,
                             ActivityLogDbMapper activityLogDBMapper,
                             PaymentStatusUtil paymentStatusUtil) {

        super(accountsService,
                approvalsService,
                recurringUtil,
                dateUtil,
                paymentMapper,
                paymentDBMapper,
                transactionDBMapper,
                transactionEntryDBMapper,
                kafkaHostMapper,
                paymentKafkaHost,
                limitsService,
                countryRulesUtil,
                fetchManager,
                validateManager,
                createManager,
                editManager,
                activityLogDBMapper,
                paymentStatusUtil);

        this.accountsService = accountsService;
        this.paymentMapper = paymentMapper;
        this.banksService = banksService;
        this.dataValidator = dataValidator;
        this.recurringUtil = recurringUtil;
        this.recurringDBMapper = recurringDBMapper;
        this.recurringMapper = recurringMapper;
    }

    /**
     * Populate debit and credit account details
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    @Override
    public void populateAccountDetails(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        // populate debit account
        super.populateAccountDetails(requestData);
        // populate a credit account
        accountsService.populateCreditAccountDetails((PaymentContext)requestData.getGatewayContext(), requestData.getRequest(), null);
    }

    /**
     * Populate debit and credit account bank details
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    public void populateBankDetails(RequestData<PaymentInitiationData> requestData) {
        banksService.populateDebitBankDetails(requestData.getGatewayContext(), requestData.getRequest(), true, ABA);
        banksService.populateCreditBankDetails(requestData.getGatewayContext(), requestData.getRequest(), true, ABA);
    }

    /***
     * Populate payment entity and then recurring details
     * @param context     PaymentContext
     * @param payment     PaymentEntity
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populatePaymentEntity(PaymentContext context, PaymentEntity payment, RequestData<PaymentInitiationData> requestData) {
        super.populatePaymentEntity(context, payment, requestData);

        paymentMapper.mapPaymentEntity(payment, requestData.getRequest().getRecurringData());
        // override payment date
        if (requestData.getRequest().getRecurringData().isRecurring()) {
            payment.setPaymentDate(requestData.getRequest().getNextPaymentDate());
        }
    }

    /**
     * Populate host message with a transaction type
     *
     * @param context     PaymentContext
     * @param message     ProcessingMessage
     * @param requestData RequestData<PaymentInitiationData>
     */
    @Override
    protected void populateHostMessage(PaymentContext context, ProcessingMessage message, RequestData<PaymentInitiationData> requestData) {
        super.populateHostMessage(context, message, requestData);

        message.getPaymentData().setTxnType(PaymentConstant.TXN_TRA);
    }

    @Override
    protected void validatePayment(RequestData<PaymentInitiationData> requestData, PaymentInitiationData existingPayment) throws PaymentServiceException {
        super.validatePayment(requestData, existingPayment);
        validateRecurring(requestData, existingPayment);
    }

    private void validateRecurring(RequestData<PaymentInitiationData> requestData, PaymentInitiationData existingPayment) throws PaymentServiceException {
        if (!requestData.getRequest().getRecurringData().isRecurring()) {
            return;
        }
        dataValidator.validateRecurringData(requestData.getRequest(), existingPayment);
        recurringUtil.populateRecurringDetails(requestData, existingPayment.getNextPaymentDate(), existingPayment.getRecurringData().getProcessedInstances());
    }

    @Override
    public PaymentInitiationData populatePayment(long paymentId, String clientId) throws PaymentServiceException {
        PaymentInitiationData data = super.populatePayment(paymentId, clientId);
        if (data.getRecurringData().isRecurring()) {
            // get existing entry
            RecurrenceEntity recurring = recurringDBMapper.getRecurrence(data.getRecurringData().getRecurrenceId());
            recurringMapper.mapRecurringServiceObject(data.getRecurringData(), recurring);
        }
        return data;
    }
}
