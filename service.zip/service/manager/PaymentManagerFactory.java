package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.enums.payment.PaymentType;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class PaymentManagerFactory {

    private final PaymentManager paymentManager;
    private final ACHPaymentManager achPaymentManager;
    private final CHKPaymentManager chkPaymentManager;
    private final XFRPaymentManager xfrPaymentManager;
    private final XSDPaymentManager xsdPaymentManager;
    private final XSTPaymentManager xstPaymentManager;
    private final XMRPaymentManager xmrPaymentManager;
    private final XMCPaymentManager xmcPaymentManager;
    private final XMMPaymentManager xmmPaymentManager;
    private final FEDPaymentManager fedPaymentManager;
    private final RTPPaymentManager rtpPaymentManager;
    private final SAMPaymentManager samPaymentManager;
    private final USIPaymentManager usiPaymentManager;
    private final FXWPaymentManager fxwPaymentManager;
    private final FXGPaymentManager fxgPaymentManager;
    private final FETPaymentManager fetPaymentManager;
    private final ICAPaymentManager icaPaymentManager;
    private final MSIPaymentManager msiPaymentManager;
    private final MSGPaymentManager msgPaymentManager;
    private final MXWPaymentManager mxwPaymentManager;
    private final MXGPaymentManager mxgPaymentManager;

    public PaymentManagerFactory(PaymentManager paymentManager,
                                 @Qualifier("ACH") ACHPaymentManager achPaymentManager,
                                 @Qualifier("CHK") CHKPaymentManager chkPaymentManager,
                                 @Qualifier("XFR") XFRPaymentManager xfrPaymentManager,
                                 @Qualifier("XSD") XSDPaymentManager xsdPaymentManager,
                                 @Qualifier("XST") XSTPaymentManager xstPaymentManager,
                                 @Qualifier("XMR") XMRPaymentManager xmrPaymentManager,
                                 @Qualifier("XMC") XMCPaymentManager xmcPaymentManager,
                                 @Qualifier("XMM") XMMPaymentManager xmmPaymentManager,
                                 @Qualifier("FED") FEDPaymentManager fedPaymentManager,
                                 @Qualifier("RTP") RTPPaymentManager rtpPaymentManager,
                                 @Qualifier("SAM") SAMPaymentManager samPaymentManager,
                                 @Qualifier("USI") USIPaymentManager usiPaymentManager,
                                 @Qualifier("FXW") FXWPaymentManager fxwPaymentManager,
                                 @Qualifier("FXG") FXGPaymentManager fxgPaymentManager,
                                 @Qualifier("FET") FETPaymentManager fetPaymentManager,
                                 @Qualifier("ICA") ICAPaymentManager icaPaymentManager,
                                 @Qualifier("MSI") MSIPaymentManager msiPaymentManager,
                                 @Qualifier("MSG") MSGPaymentManager msgPaymentManager,
                                 @Qualifier("MXW") MXWPaymentManager mxwPaymentManager,
                                 @Qualifier("MXG") MXGPaymentManager mxgPaymentManager) {
        this.paymentManager = paymentManager;
        this.achPaymentManager = achPaymentManager;
        this.chkPaymentManager = chkPaymentManager;
        this.xfrPaymentManager = xfrPaymentManager;
        this.xsdPaymentManager = xsdPaymentManager;
        this.xstPaymentManager = xstPaymentManager;
        this.xmrPaymentManager = xmrPaymentManager;
        this.xmcPaymentManager = xmcPaymentManager;
        this.xmmPaymentManager = xmmPaymentManager;
        this.fedPaymentManager = fedPaymentManager;
        this.rtpPaymentManager = rtpPaymentManager;
        this.samPaymentManager = samPaymentManager;
        this.usiPaymentManager = usiPaymentManager;
        this.fxwPaymentManager = fxwPaymentManager;
        this.fxgPaymentManager = fxgPaymentManager;
        this.fetPaymentManager = fetPaymentManager;
        this.icaPaymentManager = icaPaymentManager;
        this.msiPaymentManager = msiPaymentManager;
        this.msgPaymentManager = msgPaymentManager;
        this.mxwPaymentManager = mxwPaymentManager;
        this.mxgPaymentManager = mxgPaymentManager;
    }

    public PaymentManager getPaymentManager(PaymentType paymentType) {
        if (paymentType == null) {
            return paymentManager;
        }
        return switch (paymentType) {
            case ACH -> achPaymentManager;
            case CHK -> chkPaymentManager;
            case XFR -> xfrPaymentManager;
            case XSD -> xsdPaymentManager;
            case XST -> xstPaymentManager;
            case XMR -> xmrPaymentManager;
            case XMC -> xmcPaymentManager;
            case XMM -> xmmPaymentManager;
            case FED -> fedPaymentManager;
            case RTP -> rtpPaymentManager;
            case SAM -> samPaymentManager;
            case USI -> usiPaymentManager;
            case FXW -> fxwPaymentManager;
            case FXG -> fxgPaymentManager;
            case FET -> fetPaymentManager;
            case ICA -> icaPaymentManager;
            case MSI -> msiPaymentManager;
            case MSG -> msgPaymentManager;
            case MXW -> mxwPaymentManager;
            case MXG -> mxgPaymentManager;
            default -> paymentManager;
        };
    }
}
