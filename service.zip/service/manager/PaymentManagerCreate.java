package com.svb.gateway.payments.payment.service.manager;

import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.payment.PaymentStatus;
import com.svb.gateway.payments.common.enums.payment.TransactionStatus;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.payment.entity.*;
import com.svb.gateway.payments.payment.mapper.db.*;
import com.svb.gateway.payments.payment.mapper.entity.RecurringMapper;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;

@Service
public class PaymentManagerCreate {

    private final RecurringMapper recurringMapper;
    private final RecurringDBMapper recurringDBMapper;
    private final PaymentDBMapper paymentDBMapper;
    private final PaymentEntryDBMapper paymentEntryDBMapper;
    private final TransactionDBMapper transactionDBMapper;
    private final TransactionEntryDBMapper transactionEntryDbMapper;

    private final DateUtil dateUtil;

    public PaymentManagerCreate(RecurringMapper recurringMapper,
                                RecurringDBMapper recurringDBMapper,
                                PaymentDBMapper paymentDBMapper,
                                PaymentEntryDBMapper paymentEntryDBMapper,
                                TransactionDBMapper transactionDBMapper,
                                TransactionEntryDBMapper transactionEntryDbMapper,
                                DateUtil dateUtil) {
        this.recurringMapper = recurringMapper;
        this.recurringDBMapper = recurringDBMapper;
        this.paymentDBMapper = paymentDBMapper;
        this.paymentEntryDBMapper = paymentEntryDBMapper;
        this.transactionDBMapper = transactionDBMapper;
        this.transactionEntryDbMapper = transactionEntryDbMapper;
        this.dateUtil = dateUtil;
    }

    /**
     * Create a recurring entry
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    protected void createRecurring(RequestData<PaymentInitiationData> requestData) {
        // populate recurring entity
        RecurrenceEntity recurring = new RecurrenceEntity();
        recurringMapper.mapRecurringEntity(recurring, requestData.getRequest());
        // create
        recurringDBMapper.createRecurrence(recurring);
        // update request
        requestData.getRequest().getRecurringData().setRecurrenceId(recurring.getRecurrenceId());
    }

    /**
     * Create payment and transaction (if criteria satisfied)
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @param payment     PaymentEntity
     */
    protected void createPayment(RequestData<PaymentInitiationData> requestData, PaymentEntity payment) {
        if (payment.getPaymentId() == 0) {
            payment.setPaymentId(paymentDBMapper.getNextPaymentId());
        }
        Timestamp now = dateUtil.getApplicationTimestamp();
        payment.setCreatedTimestamp(now);
        payment.setUpdatedTimestamp(now);
        // insert into database
        paymentDBMapper.createPayment(payment);

        // update request
        requestData.getRequest().setPaymentId(payment.getPaymentId());
        requestData.getRequest().setPaymentStatus(PaymentStatus.valueOf(payment.getStatus()));
        requestData.getRequest().getMetaInfo().setCreatedAt(payment.getCreatedTimestamp().toString());
        requestData.getRequest().getMetaInfo().setUpdatedAt(payment.getUpdatedTimestamp().toString());
    }

    /**
     * Create payment entry
     *
     * @param paymentId    long
     * @param paymentEntry PaymentEntryEntity
     */
    protected void createPaymentEntry(long paymentId, PaymentEntryEntity paymentEntry) {
        Timestamp now = dateUtil.getApplicationTimestamp();
        paymentEntry.setCreatedTimestamp(now);
        paymentEntry.setUpdatedTimestamp(now);
        paymentEntry.setPaymentId(paymentId);
        // insert into database
        paymentEntryDBMapper.createPaymentEntry(paymentEntry);
    }

    /**
     * Create transaction
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    protected void createTransaction(RequestData<PaymentInitiationData> requestData, TransactionEntity transaction) {
        // insert into database
        transactionDBMapper.createTransaction(transaction);

        // update request
        requestData.getRequest().setTransactionId(transaction.getTransactionId());
        requestData.getRequest().setTransactionStatus(TransactionStatus.valueOf(transaction.getStatus()));
        requestData.getRequest().getMetaInfo().setUpdatedAt(transaction.getUpdatedTimestamp().toString());
    }

    /**
     * Create transaction entry
     *
     * @param transactionId     long
     * @param transactionStatus String
     * @param transactionEntry  TransactionEntryEntity
     */
    protected void createTransactionEntry(long transactionId, String transactionStatus, TransactionEntryEntity transactionEntry) {
        Timestamp now = dateUtil.getApplicationTimestamp();

        // populate additional data
        transactionEntry.setTransactionId(transactionId);
        transactionEntry.setStatus(transactionStatus);
        transactionEntry.setCreatedTimestamp(now);
        transactionEntry.setUpdatedTimestamp(now);

        // insert into database
        transactionEntryDbMapper.createTransactionEntry(transactionEntry);
    }

    protected void createNextPaymentInstance(RequestData<PaymentInitiationData> requestData, PaymentEntity payment) {
        payment.setPaymentId(0);
        // create the next instance
        createPayment(requestData, payment);
    }
}
