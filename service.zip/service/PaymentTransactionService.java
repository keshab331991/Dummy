package com.svb.gateway.payments.payment.service;

import com.svb.gateway.payments.common.alert.GatewayAlert;
import com.svb.gateway.payments.common.alert.util.AlertEnum;
import com.svb.gateway.payments.common.model.payment.PaymentTransStatusUpdateRequest;
import com.svb.gateway.payments.payment.entity.PaymentTransactionEntity;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PaymentTransactionService {
    private final TransactionDBMapper transactionDBMapper;
    private final TransactionEntryDBMapper transactionEntryDBMapper;

    @Autowired
    public PaymentTransactionService(TransactionDBMapper transactionDBMapper,
                                     TransactionEntryDBMapper transactionEntryDBMapper) {
        this.transactionDBMapper = transactionDBMapper;
        this.transactionEntryDBMapper = transactionEntryDBMapper;
    }

    public void updateTxnStatusByTxnId(String clientId, String userId, Long txnId, String currentStatus){
        transactionEntryDBMapper.updateTxnStatusByPaymentId(clientId, userId, txnId, currentStatus);
    }

    public void updateEntityStatusByTxnId(Long txnId, String currentStatus){
        transactionEntryDBMapper.updateEntityStatusByPaymentId(txnId, currentStatus);
    }

    @Transactional
    public void updateTxnStatus(String clientId, String userId, Long txnId, String currentStatus){
        updateTxnStatusByTxnId(clientId, userId, txnId, currentStatus);
        updateEntityStatusByTxnId(txnId,currentStatus);
    }

    @GatewayAlert(alertEnum = AlertEnum.SVB_WRRET)
    public void updateWireReturn(PaymentTransStatusUpdateRequest paymentTransStatusUpdateRequest){
        transactionEntryDBMapper.updateWireReturn(paymentTransStatusUpdateRequest.getPaymentUpdateDetails().getFirst());
    }

    @GatewayAlert(alertEnum = AlertEnum.SVB_WRREP)
    public void updateWireRepair(PaymentTransStatusUpdateRequest paymentTransStatusUpdateRequest){
        transactionEntryDBMapper.updateWireRepair(paymentTransStatusUpdateRequest.getPaymentUpdateDetails().getFirst());
    }

}
