package com.svb.gateway.payments.payment.service;

import com.svb.gateway.payments.common.enums.TransactionStatusEnum;
import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.enums.WireReturnEnum;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.model.wires.WireReturnResponse;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service

public class WireService {

    private final TransactionDBMapper transactionDBMapper;
    private final PaymentStatusUtil paymentStatusUtil;

    public WireService(TransactionDBMapper transactionDBMapper,
                       PaymentStatusUtil paymentStatusUtil) {
        this.transactionDBMapper = transactionDBMapper;
        this.paymentStatusUtil = paymentStatusUtil;
    }

    public void consumeWireReturn(WireReturnResponse wireReturnResponse) {
        try {
            if (WireReturnEnum.fromValue(wireReturnResponse.getWireReturnStatus()) != null) {
                if ((wireReturnResponse.getWireReturnReason() == null || wireReturnResponse.getWireReturnReason().isEmpty())
                        && (wireReturnResponse.getWireReturnStatus().equalsIgnoreCase(WireReturnEnum.WIRE_RETURNED.getValue()))) {
                    log.error("Request failed as wire return reason is empty for txn id:{}",
                            wireReturnResponse.getWireOutgoingTxnId());
                    return;
                }

                PaymentTransactionStatusEntity paymentTransactionStatusEntity =
                        wireReturnResponse.getWireOutgoingTxnId().startsWith("GO")
                                ? transactionDBMapper.getPaymentTransactionWithInfoId(wireReturnResponse.getWireOutgoingTxnId())
                                : transactionDBMapper.getPaymentTransactions(Long.valueOf(wireReturnResponse.getWireOutgoingTxnId())).getFirst();
                if (paymentTransactionStatusEntity == null) {
                    log.error("Request failed as transaction not found in DB for txn id:{}",
                            wireReturnResponse.getWireOutgoingTxnId());
                    return;
                }

                paymentTransactionStatusEntity.setAppianCaseNum(wireReturnResponse.getAppianCaseNum());
                paymentTransactionStatusEntity.setSwiftRefNum(wireReturnResponse.getSwiftRefNum());
                paymentTransactionStatusEntity.setWireReturnDate(wireReturnResponse.getWireReturnDate());

                // Populating Wire return or repair details to persist in DB
                populateWireReturnDetails(wireReturnResponse, paymentTransactionStatusEntity);
                paymentStatusUtil.updateEntireStatus(paymentTransactionStatusEntity, true);
                log.info("Wire Return Status update is completed successfully for txn id:{}",
                        wireReturnResponse.getWireOutgoingTxnId());
            } else {
                log.error("Request failed as wire return status is invalid for txn id:{}",
                        wireReturnResponse.getWireOutgoingTxnId());
            }
        } catch (Exception e) {
            log.atError().setMessage("Error while processing Wire return for txn id:{}").addArgument(wireReturnResponse.getWireOutgoingTxnId()).setCause(e).log();
        }
    }

    private void populateWireReturnDetails(WireReturnResponse wireReturnResponse, PaymentTransactionStatusEntity paymentTransactionStatusEntity) {
        if (WireReturnEnum.WIRE_RETURNED.getValue().equalsIgnoreCase(wireReturnResponse.getWireReturnStatus())) {

            log.info("adding Wire return details for {}", wireReturnResponse.getWireReturnStatus());
            paymentTransactionStatusEntity.setStatus(TransactionStatusEnum.WRET.name());
            paymentTransactionStatusEntity.setDownstreamStatus(WireReturnEnum.WIRE_RETURNED.getStatus());
            paymentTransactionStatusEntity.setWireReturnAmount(wireReturnResponse.getWireReturnAmount().replace(",",""));
            paymentTransactionStatusEntity.setWireReturnCurrency(wireReturnResponse.getWireReturnCurrency());
            paymentTransactionStatusEntity.setWireReturnReason(wireReturnResponse.getWireReturnReason());

        } else {
            paymentTransactionStatusEntity.setWireRepairAmount(wireReturnResponse.getWireReturnAmount().replace(",",""));
            paymentTransactionStatusEntity.setWireRepairCurrency(wireReturnResponse.getWireReturnCurrency());
            if (WireReturnEnum.WIRE_REPAIR_PENDING.getValue().equalsIgnoreCase(wireReturnResponse.getWireReturnStatus())) {

                log.info("adding repair pending data for {}", wireReturnResponse.getWireReturnStatus());
                paymentTransactionStatusEntity.setStatus(TransactionStatusEnum.WREP.name());
                paymentTransactionStatusEntity.setDownstreamStatus(WireReturnEnum.WIRE_REPAIR_PENDING.getStatus());
                paymentTransactionStatusEntity.setWireRepairReason(WireReturnEnum.WIRE_REPAIR_PENDING.getReason());
            } else if (WireReturnEnum.WIRE_REPAIR_SENT.getValue().equalsIgnoreCase(wireReturnResponse.getWireReturnStatus())) {
                paymentTransactionStatusEntity.setStatus(TransactionStatusEnum.SENT.name());
                log.info("adding repair sent data for {}", wireReturnResponse.getWireReturnStatus());
                paymentTransactionStatusEntity.setDownstreamStatus(WireReturnEnum.WIRE_REPAIR_SENT.getStatus());
            }
        }
    }
}
