package com.svb.gateway.payments.payment.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.payments.common.client.ApigeeAuthTokenEnum;
import com.svb.gateway.payments.common.enums.DownstreamStatusEnum;
import com.svb.gateway.payments.common.enums.TransactionStatusEnum;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.model.payment.WirePaymentProcessingData;
import com.svb.gateway.payments.common.model.payment.processing.AddPayDetails;
import com.svb.gateway.payments.common.model.payment.processing.FraudParameters;
import com.svb.gateway.payments.common.model.payment.processing.PaymentProcessingData;
import com.svb.gateway.payments.common.properties.ApigeeProperties;
import com.svb.gateway.payments.common.service.ApigeeTokenService;
import com.svb.gateway.payments.common.service.GenericRestClient;
import com.svb.gateway.payments.common.service.mail.EmailService;
import com.svb.gateway.payments.common.util.HttpResponseContainer;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.common.util.PaymentUtil;
import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.model.RtpPayInitRequestMapper;
import com.svb.gateway.payments.payment.model.rtp.PaymentStatusNotification;
import com.svb.gateway.payments.payment.model.rtp.RtpPaymentInitationResponse;
import com.svb.gateway.payments.payment.model.rtp.initiateApi.RtpSinglePaymentRequest;
import com.svb.gateway.payments.payment.util.PaymentProcessingErrorUtil;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static com.svb.gateway.payments.common.util.PaymentConstant.*;

@Slf4j
@Service
public class RtpService {

    private final ApigeeProperties apigeeProperties;
    private final GenericRestClient genericRestClient;
    private final ApigeeTokenService apigeeTokenService;
    private final ObjectMapper objectMapper;
    public final RtpPayInitRequestMapper rtpPayInitRequestMapper;
    private final PaymentProcessingErrorUtil paymentErrorUtil;
    private final EmailService emailService;
    private final TransactionDBMapper transactionDBMapper;
    private final PaymentStatusUtil paymentStatusUtil;

    public static final String PAYMENT_INFO_PREFIX = "M";
    public static final String BANK_FIELD = "SGO";
    public static final String MESSAGE_SERIAL_NUMBER_PREFIX_DIGIT = "0";

    @Value("${spring.profiles.active}")
    private String activeProfile;

    @Value("${rtp.validation.msgGenerationSource}")
    private String msgGenerationSource;

    @Autowired
    public RtpService(ApigeeProperties apigeeProperties,
                      GenericRestClient genericRestClient,
                      ApigeeTokenService apigeeTokenService,
                      ObjectMapper objectMapper,
                      RtpPayInitRequestMapper rtpPayInitRequestMapper,
                      PaymentProcessingErrorUtil paymentErrorUtil,
                      EmailService emailService,
                      TransactionDBMapper transactionDBMapper,
                      PaymentStatusUtil paymentStatusUtil
    ) {
        this.apigeeProperties = apigeeProperties;
        this.genericRestClient = genericRestClient;
        this.apigeeTokenService = apigeeTokenService;
        this.objectMapper = objectMapper;
        this.rtpPayInitRequestMapper = rtpPayInitRequestMapper;
        this.paymentErrorUtil = paymentErrorUtil;
        this.emailService = emailService;
        this.transactionDBMapper = transactionDBMapper;
        this.paymentStatusUtil = paymentStatusUtil;
    }

    //TODO
    /* public PaymentStatusResponse getPaymentStatus() throws IOException, PaymentServiceException {
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put(HttpHeaders.AUTHORIZATION, PaymentsConstant.BEARER + " "
                + apigeeTokenService.getApigeeAuthToken(ApigeeAuthTokenEnum.RTP_CLIENT));

        String apigeeHostUrl = apigeeProperties.getUrl();
        if ("qa2".equals(activeProfile) || "dev2".equals(activeProfile)) {
            apigeeHostUrl = apigeeProperties.getUrlUat();
        }

        HttpResponseContainer<PaymentStatusJsonResponse> response = genericRestClient.get(apigeeHostUrl
                        + apigeeProperties.getCheckRtpStatusRelativePath(),
                null,
                PaymentStatusJsonResponse.class,
                Duration.ofSeconds(10L),
                headerMap,
                false);
        PaymentStatusJsonResponse paymentStatusJsonResponse = response.getSuccessResponse();
        PaymentStatusResponse paymentStatusResponse = new PaymentStatusResponse();
        paymentStatusResponse.setOnHold(paymentStatusJsonResponse.getOnHold());
        return paymentStatusResponse;
    }

    public ResponseEntity<ApiResponseContainer<BankCheckResponse, RtpBankCheckError>> getBankCheckDetails(String routingNumber) throws IOException, InterruptedException, PaymentServiceException {
        BankCheckResponse bankCheckSuccessResponse = null;
        RtpBankCheckError rtpBankCheckErrorRes = null;

        log.info("RTP bank check api: Request payload recieved: {}", routingNumber);

        Map<String, String> headerMap = new HashMap<>();
        headerMap.put(HttpHeaders.AUTHORIZATION, PaymentsConstant.BEARER + " "
                + apigeeTokenService.getApigeeAuthToken(ApigeeAuthTokenEnum.RTP_CLIENT));

        String apigeeHostUrl = apigeeProperties.getUrl();
        if ("qa2".equals(activeProfile) || "dev2".equals(activeProfile)) {
            apigeeHostUrl = apigeeProperties.getUrlUat();
        }

        HttpResponseContainer<String> response = genericRestClient.get(apigeeHostUrl
                        + apigeeProperties.getBankCheckDetailsRelativePath(),
                null,
                String.class,
                Duration.ofSeconds(10L),
                headerMap,
                false);
        if (null != response) {
            HttpStatus statusCode = response.getStatusCode();
            log.info("RTP bank check api: response Status code: {} ", statusCode);
            if (statusCode == HttpStatus.ACCEPTED || statusCode == HttpStatus.OK) {
                BankCheckJsonResponse bankCheckSuccessJsonResponse =
                        new ObjectMapper().readValue(response.getSuccessResponse(), new TypeReference<BankCheckJsonResponse>() { });
                log.info("RTP bank check API: Success response payload: {}", response.getSuccessResponse());
                bankCheckSuccessResponse = mapSuccessBankCheckResponse(bankCheckSuccessJsonResponse);
            } else if (statusCode == HttpStatus.BAD_REQUEST || statusCode == HttpStatus.NOT_FOUND) {
                log.info("RTP bank check API: BAD Response Received from RTP Bank Check API: {}", response.getErrorResponse());
                String errorName = mapBankCheckFailure(statusCode.value());
                BankCheckBadResponse bankCheckBadResponse = new ObjectMapper().readValue(response.getErrorResponse(), BankCheckBadResponse.class);
                rtpBankCheckErrorRes = RtpBankCheckError.builder().name(errorName)
                        .statusCode(String.valueOf(statusCode)).messageDesc(bankCheckBadResponse.getMessage()).build();
            }
        }

        return ResponseEntity.status(response.getStatusCode())
                .body(new ApiResponseContainer<>(bankCheckSuccessResponse, rtpBankCheckErrorRes));
    }

    private static String mapBankCheckFailure(int statusCode) {
        switch (statusCode) {
            case 404:
            case 400:
                return "BadRequestError";
            case 500:
                return "InternalServiceError";
            default:
                return "Failure";
        }
    }

    private BankCheckResponse mapSuccessBankCheckResponse(BankCheckJsonResponse bankCheckJsonResponse) throws JsonProcessingException {
        BankCheckResponse bankCheckResponse = new BankCheckResponse();
        bankCheckResponse.setRoutingNumber(bankCheckJsonResponse.getRoutingNumber());
        bankCheckResponse.setFinancialInstitutionId(bankCheckJsonResponse.getFinancialInstitutionId());
        bankCheckResponse.setFinancialInstitutionName(bankCheckJsonResponse.getFinancialInstitutionName());
        bankCheckResponse.setMessageSetVersion(bankCheckJsonResponse.getMessageSetVersion());
        bankCheckResponse.setParticipantActivationDate(bankCheckJsonResponse.getParticipantActivationDate());
        bankCheckResponse.setParticipantId(bankCheckJsonResponse.getParticipantId());
        bankCheckResponse.setParticipantName(bankCheckJsonResponse.getParticipantName());
        bankCheckResponse.setReceiveConnection(bankCheckJsonResponse.getReceiveConnection());
        bankCheckResponse.setReceiveServices(bankCheckJsonResponse.getReceiveServices());
        return bankCheckResponse;
    } */

    public void consumeRTPPaymentStatus(PaymentStatusNotification rtpPaymentStatusResponse) {
        log.info("Entering consumeRTPPaymentStatus service.");
        if (rtpPaymentStatusResponse.getOriginalPaymentInformationIdentification() != null) {
            //Calling method to compare EventStatus and PaymentStatus to update DB
            String rtpStatus = setRTPStatuses(rtpPaymentStatusResponse);
            log.info("Checking if payment exists in table for info id:{}",
                    rtpPaymentStatusResponse.getOriginalPaymentInformationIdentification());
            PaymentTransactionStatusEntity paymentTransactionStatusEntity =
                    transactionDBMapper.getPaymentTransactionWithInfoId(rtpPaymentStatusResponse.getOriginalPaymentInformationIdentification());

            if (paymentTransactionStatusEntity != null) {
                log.info("Updating RTP Payment Status Entity for info id:{}",
                        rtpPaymentStatusResponse.getOriginalPaymentInformationIdentification());

                if (RTP_PAYMENT_RJCT_STATUS.equals(rtpPaymentStatusResponse.getTransactionStatus())
                        && DownstreamStatusEnum.IN_PROCESS.toString().equals(rtpStatus.split(",")[0])) {
                    String rtpTransformationFailedSubject = "SVB Go - RTP Payment Processing Failed: "
                            + rtpPaymentStatusResponse.getOriginalPaymentInformationIdentification();
                    String rtpTransformationFailedBody = buildRtpTransformationFailedBody(paymentTransactionStatusEntity, rtpPaymentStatusResponse);
                    emailService.sendEmail(rtpTransformationFailedSubject, rtpTransformationFailedBody);

                    log.info("An email alert has been sent to App Support team for the payment Info Id:{}",
                            rtpPaymentStatusResponse.getOriginalPaymentInformationIdentification());
                }

                // Update the payment status response received from RTP into the GW_PAYMENT_TRANSACTION table
                String[] statusArr = rtpStatus.split(",");
                paymentTransactionStatusEntity.setDownstreamStatus(statusArr[0]);
                paymentTransactionStatusEntity.setStatus(statusArr[1]);
                if (statusArr.length > 2) {
                    paymentTransactionStatusEntity.setRemarks(statusArr[2]);
                }
                paymentTransactionStatusEntity.setErrorCode(rtpPaymentStatusResponse.getStatusReason());
                paymentTransactionStatusEntity.setErrorDetails(rtpPaymentStatusResponse.getAdditionalInformation());
                paymentTransactionStatusEntity.setRemarks(rtpPaymentStatusResponse.getAdditionalInformation());
                paymentTransactionStatusEntity.setRtpRefNum(rtpPaymentStatusResponse.getAccountServicerReference());
                paymentStatusUtil.updateEntireStatus(paymentTransactionStatusEntity, true);
                log.info("RTP Payment Status update is completed successfully for info id:{}", rtpPaymentStatusResponse.getOriginalPaymentInformationIdentification());
            }
        }
    }

    //ACCC completed RTP_PAYMENT_ENTITY_PROCESSED_STATUS
    //REJC check status reason (array): "ED06" RTP_PAYMENT_ENTITY_CANCELLED_STATUS
    //PNDG DB_PAYMENT_STATUS_IN_PROCESS
    public String setRTPStatuses(PaymentStatusNotification rtpPaymentStatusResponse) {
        String status = "";
        if (RTP_PAYMENT_ACCC_STATUS.equals(rtpPaymentStatusResponse.getTransactionStatus())) {
            status = RTP_PAYMENT_ENTITY_PROCESSED_STATUS + "," + TransactionStatusEnum.PROC.name();
        } else if (RTP_PAYMENT_RJCT_STATUS.equals(rtpPaymentStatusResponse.getTransactionStatus())) {
            status = TECH_ERROR_REASON_CODES_STATUS_MAPPING.contains(rtpPaymentStatusResponse.getStatusReason())
                    ? DownstreamStatusEnum.IN_PROCESS + "," + TransactionStatusEnum.INPR.name()
                    : RTP_PAYMENT_ENTITY_CANCELLED_STATUS + "," + TransactionStatusEnum.FAIL.name() + "," + PAYMENT_CANCELLED_BY_BANK_REASON;
        } else if (RTP_PAYMENT_PNDG_STATUS.equals(rtpPaymentStatusResponse.getTransactionStatus())) {
            status = DownstreamStatusEnum.IN_PROCESS + "," + TransactionStatusEnum.INPR.name();
        }
        return status;
    }

    public String buildRtpTransformationFailedBody(PaymentTransactionStatusEntity paymentTransactionStatusEntity,
                                                   PaymentStatusNotification rtpPaymentStatusResponse) {
        return RTP_EMAIL_CONTENT1
                + RTP_EMAIL_CONTENT2 + paymentTransactionStatusEntity.getTransactionId()
                + RTP_EMAIL_CONTENT3 + paymentTransactionStatusEntity.getPaymentInfoId() // originalPaymentInformationIdentification
                + "\n RTP Payment reference: " + paymentTransactionStatusEntity.getPaymentRefId()//accountServiceReference
                + RTP_EMAIL_CONTENT4 + rtpPaymentStatusResponse.getAdditionalInformation()   //additional information + status code
                + RTP_EMAIL_CONTENT5 + rtpPaymentStatusResponse.getStatusReason() //additional information + additional information
                + "\n\n Next steps:\n Please contact RTP Support team \"Group IT Wires Support <SDLITWiresSupport@svb.com>\" and SVB Go Payment Tech or Product team to see if the payment can be re-triggered.";
    }

    public RtpPaymentInitationResponse sendPaymentToRtp(WirePaymentProcessingData wirePaymentData) throws IOException, PaymentServiceException {
        RtpSinglePaymentRequest rtpPaymentInitRequest = rtpPayInitRequestMapper.convertPaymentToRtpPayInitRequest(wirePaymentData);
        rtpPaymentInitRequest.setPaymentInformationId(generatePaymentInfoId(wirePaymentData.getPaymentData()));
        rtpPaymentInitRequest.setChannelName("APIBanking");

        if (null == rtpPaymentInitRequest.getPayment().getEndToEndId()) {
            rtpPaymentInitRequest.getPayment().setEndToEndId(generateRTPEndToEndId(wirePaymentData.getPaymentData()));
        }

        Long olbPaymentId = Long.parseLong(wirePaymentData.getPaymentData().getTxRefNum());

        String paymentInitRequestMessage = objectMapper.writeValueAsString(rtpPaymentInitRequest);
        log.info("RTP post init request body payload:{}", paymentInitRequestMessage);

        Map<String, String> headerMap = new HashMap<>();
        headerMap.put(HttpHeaders.AUTHORIZATION, PaymentConstant.BEARER + " " +
                apigeeTokenService.getApigeeAuthToken(ApigeeAuthTokenEnum.RTP_CLIENT));
        headerMap.put("x-idempotency-key", UUID.randomUUID().toString());

        String apigeeHostUrl = apigeeProperties.getUrl();
        if ("qa2".equals(activeProfile) || "dev2".equals(activeProfile)) {
            apigeeHostUrl = apigeeProperties.getUrlUat();
        }

        HttpResponseContainer<String> response = genericRestClient.post(apigeeHostUrl
                        + apigeeProperties.getInitiateRtpRelativePath(),
                paymentInitRequestMessage,
                String.class,
                Duration.ofSeconds(10L),
                headerMap,
                false);

        RtpPaymentInitationResponse rtpPaymentResponse = new RtpPaymentInitationResponse();
        if (null != response) {
            FraudParameters.RecPmtEnum recPmtEnum  = Optional.ofNullable(wirePaymentData.getPaymentData()).map(PaymentProcessingData::getAddPayDetails).map(AddPayDetails::getFraudParameters)
                    .map(FraudParameters::getRecPmt).orElse(FraudParameters.RecPmtEnum.NO);
            if (response.getStatusCode() == HttpStatus.CREATED || response.getStatusCode() == HttpStatus.OK) {
                rtpPaymentResponse = new ObjectMapper().readValue(response.getSuccessResponse(), RtpPaymentInitationResponse.class);
                log.info("{} payment submitted with payment_ref_id:{}, payment_info_id:{}, state:{}, update_date_time:{}",
                        wirePaymentData.getPaymentData().getPaymentType(),
                        rtpPaymentResponse.getPaymentManagerId(), rtpPaymentInitRequest.getPaymentInformationId(),
                        rtpPaymentResponse.getStatus().getState(), rtpPaymentResponse.getStatus().getUpdateDateTime());
            } else if (response.getStatusCode() == HttpStatus.BAD_REQUEST) {
                String message = response.getStatusCode() + response.getErrorResponse().replaceAll(SPM_MESSAGE_REGEX, "");
                log.info("Error BAD REQUEST Response Received from RTP:{}", message);
                setRtpPaymentInfoIdAndRefId(rtpPaymentResponse, response.getErrorResponse(), rtpPaymentInitRequest.getPaymentInformationId());
                handlerRtpError(olbPaymentId,
                        wirePaymentData.getPaymentData().getPaymentType(),
                        rtpPaymentInitRequest.getPaymentInformationId(),
                        message,
                        FraudParameters.RecPmtEnum.YES.equals(recPmtEnum));
            } else {
                String message = response.getStatusCode() + response.getErrorResponse().replaceAll(SPM_MESSAGE_REGEX, "");
                log.info("Error Response Received from RTP: {}", message);
                handlerRtpError(olbPaymentId,
                        wirePaymentData.getPaymentData().getPaymentType(),
                        rtpPaymentInitRequest.getPaymentInformationId(),
                        message,
                        FraudParameters.RecPmtEnum.YES.equals(recPmtEnum));
            }
        } else {
            log.info("Empty Error Response Received from RTP Initiate API for TxRefNum:{}", olbPaymentId);
        }

        return rtpPaymentResponse;
    }


    private void handlerRtpError(Long paymentTransId,
                                 String paymentType,
                                 String paymentInfoId,
                                 String errorMsg,
                                 boolean recurring) {
        String rtpServiceFailedSubject = "SVB Go - RTP Payment Processing Failed - " + paymentInfoId;
        String rtpTransformationFailedBody = buildRtpServiceFailedBody(paymentTransId, paymentInfoId, errorMsg);

        paymentErrorUtil.handlerProcessingError(paymentTransId,
                paymentType,
                errorMsg,
                rtpServiceFailedSubject,
                rtpTransformationFailedBody,
                recurring);
    }

    public String buildRtpServiceFailedBody(Long olbPaymentId, String paymentInfoId, String errorMsg) {
        return SPM_EMAIL_CONTENT1
                + SPM_EMAIL_CONTENT2 + olbPaymentId
                + SPM_EMAIL_CONTENT3 + paymentInfoId
                + "\n RTP Payment reference: N/A"
                + SPM_EMAIL_CONTENT4 + errorMsg
                + "\n\n Next steps:\n Please contact RTP Support team \"Group IT Wires Support <SDLITWiresSupport@svb.com>\" and SVB Go Payment Tech or Product team to see if the payment can be re-triggered.";
    }

    private void setRtpPaymentInfoIdAndRefId(RtpPaymentInitationResponse rtpPaymentResponse, String response, String paymentInfoId) {
        JSONObject rtpMessage = new JSONObject(response);
        rtpPaymentResponse.setPaymentInformationId(paymentInfoId);
        Optional.ofNullable(rtpMessage.getString("payment_manager_id")).ifPresent(rtpPaymentResponse::setPaymentManagerId);
    }

    private String generatePaymentInfoId(PaymentProcessingData paymentData) {

        String paymentCreationDate = PaymentUtil.convertDate(paymentData.getProcessingDate());
        String routingNum = paymentData.getDebtorBankData().getRoutingCode();
        String olbPaymentId = paymentData.getTxRefNum();
        String formattedSerialNumber = StringUtils.leftPad(olbPaymentId, 11, MESSAGE_SERIAL_NUMBER_PREFIX_DIGIT);
        return PAYMENT_INFO_PREFIX +
                paymentCreationDate +
                routingNum +
                msgGenerationSource +
                BANK_FIELD +
                formattedSerialNumber;
    }

    private String generateRTPEndToEndId(PaymentProcessingData paymentData) {
        String fileTimeStamp = PaymentUtil.convertDate(paymentData.getProcessingDate());
        String olbPaymentId = paymentData.getTxRefNum();

        return fileTimeStamp + olbPaymentId;
    }
}

