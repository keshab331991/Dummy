package com.svb.gateway.payments.payment.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.enums.ErrorCodeEnum;
import com.svb.gateway.payments.common.enums.Mode;
import com.svb.gateway.payments.common.enums.payment.PaymentType;
import com.svb.gateway.payments.common.exception.CollectException;
import com.svb.gateway.payments.common.exception.PaymentBadRequestException;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.mapper.model.LimitsMapper;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.model.payment.limits.*;
import com.svb.gateway.payments.common.properties.PaymentProperties;
import com.svb.gateway.payments.common.service.GenericRestClient;
import com.svb.gateway.payments.common.util.CommonUtil;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.common.util.HttpResponseContainer;
import com.svb.gateway.payments.common.util.PaymentConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class LimitsService {

    private final GenericRestClient genericRestClient;
    private final PaymentProperties paymentProperties;
    private final LimitsMapper limitsMapper;
    private final DateUtil dateUtil;
    private final ObjectMapper objectMapper;

    public LimitsService(GenericRestClient genericRestClient,
                         PaymentProperties paymentProperties,
                         LimitsMapper limitsMapper,
                         DateUtil dateUtil, ObjectMapper objectMapper) {
        this.genericRestClient = genericRestClient;
        this.paymentProperties = paymentProperties;
        this.limitsMapper = limitsMapper;
        this.dateUtil = dateUtil;
        this.objectMapper = objectMapper;
    }

    /**
     * validate or consume limits
     *
     * @param context        PaymentContext
     * @param initiationData PaymentInitiationData
     * @throws PaymentBadRequestException e
     * @throws PaymentServiceException    e
     */
    @CollectException
    public void process(PaymentContext context, PaymentInitiationData initiationData)
            throws PaymentBadRequestException, PaymentServiceException {

        // Don't process limits for Transfer payment types
        String paymentType = Optional.ofNullable(initiationData.getPaymentType()).map(PaymentType::toString).orElse("");
        if (CommonConstant.TRANSFER_TYPES.contains(paymentType)) {
            log.info("process limit::skipped {} {}", context.log(), paymentType);
            return;
        }

        LimitInItem limitItem;
        String url;
        if (context.getMode().equals(Mode.VALIDATE)) {
            limitItem = limitsMapper.getLimitValidationItem(initiationData);
            limitItem.setPaymentType(initiationData.getTemplateId() > 0 ? String.format("%sT", initiationData.getPaymentType().toString()) : initiationData.getPaymentType().toString());

            url = paymentProperties.getLimitHostUrl() + String.format(paymentProperties.getValidateLimitPath(), context.getClientId(), context.getUserId());
        } else {
            limitItem = limitsMapper.getLimitConsumptionItem(initiationData);
            limitItem.setPaymentType(initiationData.getTemplateId() > 0 ? String.format("%sT", initiationData.getPaymentType().toString()) : initiationData.getPaymentType().toString());

            url = paymentProperties.getLimitHostUrl() + String.format(paymentProperties.getConsumeLimitPath(), context.getClientId(), context.getUserId());
        }
        limitItem.setPaymentDate(dateUtil.getTimestamp(initiationData.getPaymentDate()));
        limitItem.setLimitCategory("E");
        LimitRequest request = new LimitRequest();
        request.setEntriesRequestList(List.of(limitItem));
        log.info("process limit::{}, url {}, request {}, {}", initiationData.getPaymentType(), url, request.log(), context.log());
        HttpResponseContainer<LimitResponse> responseContainer;
        try {
            if (context.getMode().equals(Mode.VALIDATE)) {
                responseContainer = genericRestClient.put(url, request,
                        LimitResponse.class, null, null, true);
            } else {
                responseContainer = genericRestClient.post(url, request,
                        LimitResponse.class, null, null, true);
            }
            processResponse(initiationData, context, responseContainer, url);
        } catch (PaymentServiceException e) {
            log.error("process limit::{} error {}, {}", initiationData.getPaymentType(), e.getMessage(), context.log());
            CommonUtil.raiseException(context, e.getErrorNumber(), e.getErrorCode(),
                    e.getErrorDescription(), e, false);
        }
    }

    /**
     * process response of consume-validate api
     *
     * @param paymentData       PaymentInitiationData
     * @param context           PaymentContext
     * @param responseContainer HttpResponseContainer<LimitResponse>
     * @param url               String
     * @throws PaymentServiceException e
     */
    private void processResponse(PaymentInitiationData paymentData, PaymentContext context, HttpResponseContainer<LimitResponse> responseContainer, String url) throws PaymentServiceException {
        if (responseContainer.getStatusCode().is2xxSuccessful()) {
            LimitResponse response = responseContainer.getSuccessResponse();
            if (response.getEntriesResponseList().getFirst().getLimitResponse().equals("Y")) {
                if (context.getMode().equals(Mode.CREATE)) {
                    paymentData.setLimitConsumed(true);
                }
            } else {
                log.error("process limit::{} 2XX failure, response {}, {}", paymentData.getPaymentType(), response.log(), context.log());
                throw new PaymentBadRequestException(1057, ErrorCodeEnum.LIMITS_PROCESSING_ERROR, String.format("Limit failed in %s", context.getMode()));
            }
            return;
        } else if (responseContainer.getStatusCode().is4xxClientError()) {
            log.error("process limit::{}, 4XX failure, response {}, {}", paymentData.getPaymentType(), responseContainer.getErrorResponse(), context.log());
            try {
                LimitError error = objectMapper.readValue(responseContainer.getErrorResponse(), LimitError.class);
                List<LimitErrorItem> errorItems = Optional.ofNullable(error).map(LimitError::getErrors).orElseGet(List::of);
                if(!errorItems.isEmpty()){
                    if (PaymentConstant.LIMIT_ERROR_PER_TRANSACTION.equals(errorItems.getFirst().getErrorCode())) {
                        throw new PaymentServiceException(111772, ErrorCodeEnum.LIMITS_PROCESSING_ERROR, "Per transaction limit failed.");
                    } else if (PaymentConstant.LIMIT_ERROR_DAILY.equals(errorItems.getFirst().getErrorCode())) {
                        throw new PaymentServiceException(111694, ErrorCodeEnum.LIMITS_PROCESSING_ERROR, "Daily limit failed.");
                    }
                }
            } catch (JsonProcessingException e) {
                log.error("process limit::{}, failure parsing error {}, {}", paymentData.getPaymentType(), e.getMessage(), context.log(), e);
            }
        } else {
            log.error("process limit::{}, failure {}, {}", paymentData.getPaymentType(), responseContainer.getErrorResponse(), context.log());
        }
        throw new PaymentServiceException(1058, ErrorCodeEnum.HOST_CALL_FAILURE, String.format("Limit failed, %s - %s", responseContainer.getStatusCode(), responseContainer.getErrorResponse()));
    }

    /**
     * Revert limits
     *
     * @param paymentData PaymentInitiationData
     * @param context     PaymentContext
     * @throws PaymentBadRequestException e
     * @throws PaymentServiceException    e
     */
    public void revert(PaymentInitiationData paymentData, PaymentContext context)
            throws PaymentBadRequestException, PaymentServiceException {

        // Don't process limits for Transfer payment types
        String paymentType = Optional.ofNullable(paymentData.getPaymentType()).map(PaymentType::toString).orElse("");
        if (CommonConstant.TRANSFER_TYPES.contains(paymentType)) {
            log.info("revert limit::skipped {} {}", context.log(), paymentType);
            return;
        }

        LimitReversalRequest request = limitsMapper.getLimitReversalRequest(paymentData);
        request.setPaymentType(paymentData.getTemplateId() > 0 ? String.format("%sT", paymentData.getPaymentType().toString()) : paymentData.getPaymentType().toString());

        request.setPaymentDate(dateUtil.getTimestamp(paymentData.getPaymentDate()));

        String url = paymentProperties.getLimitHostUrl() + String.format(paymentProperties.getRevertLimitPath(), context.getClientId(), context.getUserId());
        log.info("revert limit::{}, url {}, request {}, {}", paymentData.getPaymentType(), url, request.log(), context.log());
        try {
            HttpResponseContainer<LimitReversalResponse> responseContainer = genericRestClient.put(url, request,
                    LimitReversalResponse.class, null, null, true);

            if (responseContainer.getStatusCode().is2xxSuccessful()) {
                LimitReversalResponse response = responseContainer.getSuccessResponse();
                if (response.getLimitResponse().equals("N")) {
                    log.info("revert limit::{} failure, response {}, {}", paymentData.getPaymentType(), response.log(), context.log());
                    throw new PaymentBadRequestException(1019, ErrorCodeEnum.LIMITS_REVERSAL_ERROR, "Limit reversal failed");
                }
            } else {
                throw new PaymentServiceException(5000, ErrorCodeEnum.HOST_CALL_FAILURE, String.format("Limit reversal failed, %s:%s", responseContainer.getStatusCode(), responseContainer.getErrorResponse()));
            }
        } catch (PaymentServiceException e) {
            log.error("revert limit::{} error {}, {}", paymentData.getPaymentType(), e.getMessage(), context.log());
            throw new PaymentServiceException(1020, ErrorCodeEnum.LIMITS_PROCESSING_ERROR, String.format("Limit reversal failed in %s", context.getMode()));
        }
    }
}

