package com.svb.gateway.payments.payment.service;

import com.svb.gateway.payments.common.enums.CountryEnum;
import com.svb.gateway.payments.common.enums.ErrorCodeEnum;
import com.svb.gateway.payments.common.enums.PaymentTypeEnum;
import com.svb.gateway.payments.common.enums.payment.PayeeType;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.exception.model.ErrorInstance;
import com.svb.gateway.payments.common.model.ibanvalidation.IbanValidationRequest;
import com.svb.gateway.payments.common.model.ibanvalidation.IbanValidationResponse;
import com.svb.gateway.payments.common.model.payment.PaymentMode;
import com.svb.gateway.payments.common.model.payment.TxnType;
import com.svb.gateway.payments.common.model.payment.processing.AccountData;
import com.svb.gateway.payments.common.model.payment.processing.IntermediaryBankData;
import com.svb.gateway.payments.common.model.payment.processing.PaymentProcessingData;
import com.svb.gateway.payments.common.model.rulesengine.*;
import com.svb.gateway.payments.common.service.IbanValidationService;
import com.svb.gateway.payments.common.service.StaticDetailsService;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.common.util.PaymentUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.*;
import java.util.function.Function;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.svb.gateway.payments.common.util.PaymentConstant.PAYMENT_METHOD_GLOBAL_ACH;


@Slf4j
@Service
public class PaymentRulesService {

    private final IbanValidationService ibanValidationService;
    private final StaticDetailsService staticDataService;

    @Autowired
    public PaymentRulesService(IbanValidationService ibanValidationService,
                               StaticDetailsService staticDataService) {
        this.ibanValidationService = ibanValidationService;
        this.staticDataService = staticDataService;
    }

    public List<ErrorInstance> performCountrySpecificValidations(PaymentProcessingData paymentProcessingData, String confirmationMode) {
        LinkedList<ErrorInstance> errorInstances = new LinkedList<>();
        if (!StringUtils.hasLength(paymentProcessingData.getCreditorBankData().getAddress().getCountry())) {
            //TODO return
            PaymentUtil.buildErrorInstances(ErrorCodeEnum.MANDATORY_COUNTRY_CODE, errorInstances);
        } else {
            //TODO: Cache the rule Engine response for the given country to improve performance
            CountryRuleResponse countryRuleResponse = staticDataService.fetchCountrySpecificRules(null, CountryEnum.valueOf(paymentProcessingData.getCreditorBankData().getAddress().getCountry()));

            Map<String, GACHInfo> currencyGlobalAchInfoMap;
            if (!"N".equalsIgnoreCase(countryRuleResponse.getData().getGACHAllowed()) &&
                    countryRuleResponse.getData().getGACHInfo() != null &&
                    !countryRuleResponse.getData().getGACHInfo().isEmpty()) {
                currencyGlobalAchInfoMap = countryRuleResponse.getData().getGACHInfo().stream().collect(Collectors.toMap(GACHInfo::getCurrency, Function.identity()));
            } else {
                PaymentUtil.buildErrorInstances(ErrorCodeEnum.GACH_NOT_ALLOWED_CODE, errorInstances);
                return errorInstances;
            }
            //If payment type is GACH and TXN_TYPE is MSG, MXG, FXG perform necessary validations
            String paymentType = paymentProcessingData.getPaymentType();
            if (PaymentTypeEnum.MSG.toString().equals(paymentType)
                    || PaymentTypeEnum.MXG.toString().equals(paymentType)
                    || PaymentTypeEnum.FXG.toString().equals(paymentType)) {
                performGlobalAchValidations(paymentProcessingData, countryRuleResponse, currencyGlobalAchInfoMap, confirmationMode, errorInstances);
            } else
                performWireValidations(paymentProcessingData, confirmationMode, countryRuleResponse, errorInstances, currencyGlobalAchInfoMap);
        }
        return errorInstances;
    }

    public PaymentMode getCountryRule(CountryRuleResponse countryRuleResponse, String paymentType, String transactionCcy,
                                      PaymentMode paymentMode) {

        String localRoutingInformationPrefix = PaymentConstant.EMPTY;
        String localRoutingInformationType = PaymentConstant.EMPTY;
        String purposeOfPaymentPrefix = PaymentConstant.EMPTY;
        String purposeOfPaymentPosition = PaymentConstant.EMPTY;
        String purposeOfPaymentPositionWire = PaymentConstant.EMPTY;
        String purposeOfPaymentPrefixCode = PaymentConstant.EMPTY;
        String purposeOfPaymentFormat = PaymentConstant.EMPTY;
        String isoClearingSystemId = PaymentConstant.EMPTY;


        if (Optional.ofNullable(countryRuleResponse).isPresent() &&
                Optional.ofNullable(countryRuleResponse.getData()).isPresent()) {
            RuleData data = countryRuleResponse.getData();
            localRoutingInformationPrefix = Optional.of(data)
                    .map(RuleData::getBeneficiaryBankInfo)
                    .map(BeneficiaryBankInfo::getLocalRoutingCode)
                    .map(LocalRoutingCode::getPrefix)
                    .orElse(PaymentConstant.EMPTY);
            localRoutingInformationType = Optional.of(data)
                    .map(RuleData::getBeneficiaryBankInfo)
                    .map(BeneficiaryBankInfo::getLocalRoutingCode)
                    .map(LocalRoutingCode::getType)
                    .orElse(PaymentConstant.EMPTY);
            purposeOfPaymentPrefix = Optional.of(data)
                    .map(RuleData::getPurposeOfPayment)
                    .map(PurposeOfPayment::getPrefix)
                    .orElse(PaymentConstant.EMPTY);
            purposeOfPaymentPrefixCode = Optional.of(data)
                    .map(RuleData::getPurposeOfPayment)
                    .map(PurposeOfPayment::getPrefixCode)
                    .orElse(PaymentConstant.EMPTY);
            purposeOfPaymentFormat = Optional.of(data)
                    .map(RuleData::getPurposeOfPayment)
                    .map(PurposeOfPayment::getFormat)
                    .orElse(PaymentConstant.EMPTY);
            purposeOfPaymentPositionWire = Optional.of(data)
                    .map(RuleData::getPurposeOfPaymentPositionWire)
                    .orElse(PaymentConstant.EMPTY);
            isoClearingSystemId = Optional.of(data)
                    .map(RuleData::getBeneficiaryBankInfo)
                    .map(BeneficiaryBankInfo::getIsoClearingSystemId)
                    .orElse(null);

            if (PAYMENT_METHOD_GLOBAL_ACH.contains(paymentType)) {
                if (Optional.ofNullable(countryRuleResponse.getData().getGACHInfo()).isPresent()) {
                    LocalRoutingCode localRoutingCode = getLocalRoutingCodeFromGachInfo(countryRuleResponse, transactionCcy);
                    if (localRoutingCode != null) {
                        localRoutingInformationPrefix = localRoutingCode.getPrefix();
                        localRoutingInformationType = localRoutingCode.getType();
                    }
                    purposeOfPaymentPosition = Optional.of(data)
                            .map(RuleData::getGACHInfo)
                            .map(gachInfoList -> gachInfoList.stream()
                                    .filter(gachInfo -> gachInfo.getCurrency().equals(transactionCcy)).findFirst())
                            .flatMap(gachInfo -> gachInfo.map(GACHInfo::getPurposeOfPaymentPositionGACH))
                            .orElse(PaymentConstant.EMPTY);
                }
            } else {
                purposeOfPaymentPosition = Optional.of(data)
                        .map(RuleData::getPurposeOfPaymentPositionWire)
                        .orElse(PaymentConstant.EMPTY);
            }
        }
        paymentMode.setLocalRoutingInformationType(localRoutingInformationType);
        paymentMode.setLocalRoutingInformationPrefix(localRoutingInformationPrefix);
        paymentMode.setPurposeOfPaymentPrefix(purposeOfPaymentPrefix);
        paymentMode.setPurposeOfPaymentPosition(purposeOfPaymentPosition);
        paymentMode.setPurposeOfPaymentPositionWire(purposeOfPaymentPositionWire);
        paymentMode.setPurposeOfPaymentPrefixCode(purposeOfPaymentPrefixCode);
        paymentMode.setPurposeOfPaymentFormat(purposeOfPaymentFormat);
        paymentMode.setIsoClearingSystemId(isoClearingSystemId);
        if ("MSG".equals(paymentType)) {
            String isoGachUnstructRemittanceLength = getIsoGachUnstructRemittanceLength(countryRuleResponse, transactionCcy);
            if (Objects.nonNull(isoGachUnstructRemittanceLength)) {
                paymentMode.setIsoGachUnstructRemittanceLength(Integer.parseInt(isoGachUnstructRemittanceLength));
            }
        }
        return paymentMode;
    }

    private LocalRoutingCode getLocalRoutingCodeFromGachInfo(CountryRuleResponse countryRuleResponse, String transactionCcy) {
        return Optional.ofNullable(countryRuleResponse.getData())
                .map(RuleData::getGACHInfo)
                .map(gachInfoList -> gachInfoList.stream()
                        .filter(gachInfo -> gachInfo.getCurrency().equals(transactionCcy)).findFirst())
                .flatMap(gachInfo -> gachInfo.map(GACHInfo::getBeneficiaryBankInfo))
                .map(BeneficiaryBankInfo::getLocalRoutingCode)
                .orElse(null);
    }

    private String getIsoGachUnstructRemittanceLength(CountryRuleResponse countryRuleResponse, String transactionCcy) {
        return Optional.ofNullable(countryRuleResponse.getData())
                .map(RuleData::getGACHInfo)
                .map(gachInfoList -> gachInfoList.stream()
                        .filter(gachInfo -> gachInfo.getCurrency().equals(transactionCcy)).findFirst())
                .flatMap(gachInfo -> gachInfo.map(GACHInfo::getUnstructuredRemittanceLength))
                .orElse(null);
    }

    private void performWireValidations(PaymentProcessingData paymentProcessingData, String confirmationMode, CountryRuleResponse countryRuleResponse, LinkedList<ErrorInstance> errorInstances, Map<String, GACHInfo> currencyGlobalAchInfoMap) {
        String creditCurrency = paymentProcessingData.getCreditAccountData().getAccCcy();
        LocalRoutingCode localRoutingCode = countryRuleResponse.getData().getBeneficiaryBankInfo().getLocalRoutingCode();
        if (localRoutingCode != null) {
            paymentProcessingData.getCreditorBankData().setRoutingType(localRoutingCode.getType());
        } else {
            paymentProcessingData.getCreditorBankData().setRoutingType("");
        }
        // For Templated payment import skip below validations
        if (PayeeType.R.equals(paymentProcessingData.getPayeeType())) {
            // Validate Beneficiary Account details and check iban
            validateBeneficiaryAccount(paymentProcessingData, confirmationMode, null, countryRuleResponse, creditCurrency, errorInstances);
            // Validate Beneficiary Bank information and check local routing code
            validateBeneficiaryBankInfo(paymentProcessingData, confirmationMode, null, countryRuleResponse, creditCurrency, errorInstances);
        }

        validateSwiftBic(paymentProcessingData, countryRuleResponse, errorInstances);

        //validate purpose of payment
        validatePurposeOfPayment(paymentProcessingData, currencyGlobalAchInfoMap, countryRuleResponse, confirmationMode, errorInstances);

        //validate Reason of payment length check
        validatePurposeOfPaymentLength(paymentProcessingData, countryRuleResponse, null, errorInstances);

        //IB currency validation
        validateTxnCurrencySupByIBBankCountry(paymentProcessingData, countryRuleResponse, confirmationMode, errorInstances);
    }

    private void validateTxnCurrencySupByIBBankCountry(PaymentProcessingData paymentProcessingData,
                                                       CountryRuleResponse countryRuleResponse,
                                                       String confirmationMode,
                                                       LinkedList<ErrorInstance> errorInstances) {
        if (List.of("FXW", "MXW").contains(paymentProcessingData.getPaymentType())) {
            List<String> countryRuleSupportedCurrencies = countryRuleResponse.getData().getSupportedCurrencies();
            // if transaction currency is not part of countryRuleSupportedCurrencies
            if (!CollectionUtils.isEmpty(countryRuleSupportedCurrencies) && countryRuleSupportedCurrencies.contains(paymentProcessingData.getTransactionCcy())) {
                String intermediaryRoutingCd = Optional.ofNullable(paymentProcessingData.getIntermediaryBankData())
                        .map(IntermediaryBankData::getRoutingCode)
                        .orElse("");
                if (!StringUtils.hasText(intermediaryRoutingCd)) {
                    PaymentUtil.buildErrorInstances(ErrorCodeEnum.ERROR_CODE_EMPTY_IB, errorInstances);
                }

                String intermediaryBankCountryCd = intermediaryRoutingCd.substring(4, 6);
                String payeeBankCountryCd = paymentProcessingData.getCreditorBankData().getAddress().getCountry();

                if (!payeeBankCountryCd.equalsIgnoreCase(intermediaryBankCountryCd) && "N".equals(confirmationMode)) {
                    PaymentUtil.buildErrorInstances(ErrorCodeEnum.PAYMENT_EXT_WARNING_CODE_INVALID_IB, errorInstances);
                }
            }
        }
    }

    private void validatePurposeOfPaymentLength(PaymentProcessingData paymentProcessingData,
                                                CountryRuleResponse countryRuleResponse,
                                                Map<String, GACHInfo> currencyGlobalAchInfoMap,
                                                LinkedList<ErrorInstance> errorInstances) {
        String purposeOfPaymentRequired;
        String purposeOfPaymentPosition;
        if (CollectionUtils.isEmpty(currencyGlobalAchInfoMap)) {
            //wire
            purposeOfPaymentRequired = countryRuleResponse.getData().getPurposeOfPaymentRequired();
            purposeOfPaymentPosition = countryRuleResponse.getData().getPurposeOfPaymentPositionWire();
        } else {
            //gACH
            purposeOfPaymentRequired = currencyGlobalAchInfoMap.get(paymentProcessingData.getTransactionCcy()).getPurposeOfPaymentRequired();
            purposeOfPaymentPosition = currencyGlobalAchInfoMap.get(paymentProcessingData.getTransactionCcy()).getPurposeOfPaymentPositionGACH();
        }
        if ("77B".equals(purposeOfPaymentPosition) && (List.of("M", "O").contains(purposeOfPaymentRequired))) {
            String purposeOfPaymentFormat = Optional.ofNullable(countryRuleResponse.getData())
                    .map(RuleData::getPurposeOfPayment)
                    .map(PurposeOfPayment::getFormat).orElse("");
            if ("TEXT".equals(purposeOfPaymentFormat)) {
                Optional<String> paymentReason = Optional.ofNullable(paymentProcessingData.getRemarks());
                boolean isNOKCurrency = ("NOK".equals(paymentProcessingData.getTransactionCcy()));

                String reasonOfPaymentLengthLimit = isNOKCurrency ? "25" : "35";
                if (paymentReason.isPresent()) {
                    String paymentReasonText = paymentReason.get();
                    //length check
                    if (paymentReasonText.length() > Integer.parseInt(reasonOfPaymentLengthLimit)) {
                        PaymentUtil.buildErrorInstances(ErrorCodeEnum.GACH_PAYMENT_REASON_PMT_LENGTH_LIMIT_MSG_POP, errorInstances, reasonOfPaymentLengthLimit);
                    }
                    //numeric check for NOK
                    else if (isNOKCurrency && StringUtils.hasLength(paymentReasonText) && !paymentReasonText.matches("^\\d+$")) {
                        PaymentUtil.buildErrorInstances(ErrorCodeEnum.GACH_PAYMENT_REASON_PMT_NUMERIC_CHECK_CODE_POP, errorInstances);
                    }
                }
            }
        }
    }

    private void performGlobalAchValidations(PaymentProcessingData paymentProcessingData,
                                             CountryRuleResponse countryRuleResponse,
                                             Map<String, GACHInfo> currencyGlobalAchInfoMap,
                                             String confirmationMode,
                                             LinkedList<ErrorInstance> errorInstances) {
        String debitCurrency = paymentProcessingData.getDebitAccountData().getAccCcy();
        if (debitCurrency == null) {
            PaymentUtil.buildErrorInstances(ErrorCodeEnum.GACH_CURRENCY_UND_CODE, errorInstances);
        } else if (!currencyGlobalAchInfoMap.containsKey(debitCurrency)) {
            PaymentUtil.buildErrorInstances(ErrorCodeEnum.GACH_CURRENCY_NOT_ALLOWED_CODE, errorInstances);
        } else {
            BigDecimal payableAmount = paymentProcessingData.getTransactionAmt() != null && StringUtils.hasLength(paymentProcessingData.getTransactionAmt()) ?
                    new BigDecimal(paymentProcessingData.getTransactionAmt()) : new BigDecimal("0");
            // Amount Validation for MSG
            if (PaymentTypeEnum.MSG.toString().equals(paymentProcessingData.getPaymentType())
                    && payableAmount.intValue() > 0) {
                globalAchAmountValidation(paymentProcessingData, currencyGlobalAchInfoMap, errorInstances, payableAmount);
            } else if (PaymentTypeEnum.FXG.toString().equals(paymentProcessingData.getPaymentType()) ||
                    PaymentTypeEnum.MXG.toString().equals(paymentProcessingData.getPaymentType())) {
                fxgMxgAmountValidation(paymentProcessingData, currencyGlobalAchInfoMap, errorInstances);
            }

            performGLobalAchOtherValidations(paymentProcessingData, countryRuleResponse, currencyGlobalAchInfoMap, confirmationMode, errorInstances, debitCurrency);
            // processDate purpose of payment
            validatePurposeOfPayment(paymentProcessingData, currencyGlobalAchInfoMap, countryRuleResponse, confirmationMode, errorInstances);
            //validate Reason of payment length check
            validatePurposeOfPaymentLength(paymentProcessingData, countryRuleResponse, currencyGlobalAchInfoMap, errorInstances);
        }
    }

    private void performGLobalAchOtherValidations(PaymentProcessingData paymentProcessingData, CountryRuleResponse countryRuleResponse, Map<String, GACHInfo> currencyGlobalAchInfoMap, String confirmationMode, LinkedList<ErrorInstance> errorInstances, String debitCurrency) {
        // Other Field Validations
        // TODO Might be used in future
        // Optional<PayeeType> payeeType = Optional.ofNullable(paymentProcessingData.getPayeeType());
        String payeeName = paymentProcessingData.getCreditorData().getName();
        // TODO Verify should this be debit currency or credit currency
        String payeeNameLimit = currencyGlobalAchInfoMap.get(debitCurrency).getBeneficiaryInformation().getBeneficiaryNameLength();
        if (payeeName.length() > Integer.parseInt(payeeNameLimit)) {
            PaymentUtil.buildErrorInstances(ErrorCodeEnum.GACH_PAYEE_NAME_LENGTH_EXCEED_CODE, errorInstances);
        }
        // TODO Verify Add local Routing Network details in payment processing data.
        // Optional<String> localRoutingCode = Optional.of(paymentProcessingData.getCreditorBankData())
        //          .map(BankData::getLocalRoutingInformation)
        //          .map(LocalRoutingInformation::getRoutingCode);

        LocalRoutingCode localRoutingCode = countryRuleResponse.getData().getBeneficiaryBankInfo().getLocalRoutingCode();
        if (localRoutingCode != null) {
            paymentProcessingData.getCreditorBankData().setRoutingType(localRoutingCode.getType());
        } else {
            paymentProcessingData.getCreditorBankData().setRoutingType("");
        }
        // processDate Beneficiary Data
        if (PayeeType.R.equals(paymentProcessingData.getPayeeType())) {
            // Validate Beneficiary Bank information and check local routing code
            validateBeneficiaryBankInfo(paymentProcessingData, confirmationMode, currencyGlobalAchInfoMap, countryRuleResponse, debitCurrency, errorInstances);
            // Validate Beneficiary Account details and check iban
            validateBeneficiaryAccount(paymentProcessingData, confirmationMode, currencyGlobalAchInfoMap, countryRuleResponse, debitCurrency, errorInstances);
        }
    }

    private static void fxgMxgAmountValidation(PaymentProcessingData paymentProcessingData, Map<String, GACHInfo> currencyGlobalAchInfoMap, LinkedList<ErrorInstance> errorInstances) {
        BigDecimal debitAmount = Optional.ofNullable(paymentProcessingData.getDebitAccountData().getCcyAmount()).isEmpty() ?
                null : new BigDecimal(paymentProcessingData.getCreditAccountData().getCcyAmount());
        BigDecimal creditAmount = Optional.ofNullable(paymentProcessingData.getTransactionAmt()).isEmpty() ?
                null : new BigDecimal(paymentProcessingData.getTransactionAmt());
        if (creditAmount != null) {
            BigDecimal limitAmount = new BigDecimal(currencyGlobalAchInfoMap.get(paymentProcessingData.getDebitAccountData().getAccCcy()).getAmtLimit());
            if (creditAmount.compareTo(limitAmount) > 0) {
                PaymentUtil.buildErrorInstances(ErrorCodeEnum.GACH_EXCEED_AMOUNT_LIMIT_CODE, errorInstances);
            }
        }
        if (creditAmount == null && debitAmount != null && debitAmount.compareTo(new BigDecimal("0")) > 0) {
            PaymentUtil.buildErrorInstances(ErrorCodeEnum.GACH_PAYMENT_TEMPLATE_DEBIT_AMOUNT_INVALID_CODE, errorInstances);
            PaymentUtil.buildErrorInstances(ErrorCodeEnum.GACH_PAYMENT_TEMPLATE_CREDIT_AMOUNT_INVALID_CODE, errorInstances);
        }
    }

    private void globalAchAmountValidation(PaymentProcessingData paymentProcessingData,
                                           Map<String, GACHInfo> currencyGlobalAchInfoMap,
                                           LinkedList<ErrorInstance> errorInstances,
                                           BigDecimal payableAmount) {

        BigDecimal limitAmount = new BigDecimal(currencyGlobalAchInfoMap.get(paymentProcessingData.getDebitAccountData().getAccCcy()).getAmtLimit());
        if (payableAmount.compareTo(limitAmount) > 0) {
            if (paymentProcessingData.getTemplateId() != 0) {
                PaymentUtil.buildErrorInstances(ErrorCodeEnum.GACH_EXCEED_AMOUNT_LIMIT_CODE_TEMP_PYMT, errorInstances,
                        PaymentUtil.currencyNumberFormat(limitAmount, null), paymentProcessingData.getDebitAccountData().getAccCcy());
            } else {
                PaymentUtil.buildErrorInstances(ErrorCodeEnum.GACH_EXCEED_AMOUNT_LIMIT_CODE, errorInstances);
            }

        }
    }

    private void validatePurposeOfPayment(PaymentProcessingData paymentProcessingData,
                                          Map<String, GACHInfo> currencyGlobalAchInfoMap,
                                          CountryRuleResponse countryRuleResponse,
                                          String confirmationMode,
                                          LinkedList<ErrorInstance> errorInstances) {

        String purposeOfPaymentRequired = CollectionUtils.isEmpty(currencyGlobalAchInfoMap) ? countryRuleResponse.getData().getPurposeOfPaymentRequired() :
                currencyGlobalAchInfoMap.get(paymentProcessingData.getTransactionCcy()).getPurposeOfPaymentRequired();

        String purposeOfPaymentCode = paymentProcessingData.getPurposeOfPaymentCode();
        PurposeOfPayment purposeOfPayment = countryRuleResponse.getData().getPurposeOfPayment();
        if ("M".equals(purposeOfPaymentRequired) && purposeOfPayment != null) {
            switch (purposeOfPayment.getFormat()) {
                case "LOV" -> purposeOfPaymentLovValidation(purposeOfPayment, purposeOfPaymentCode, errorInstances);
                case "TEXT" ->
                        purposeOfPaymentTextValidation(paymentProcessingData, purposeOfPayment.getFormat(), errorInstances);
                case "BOTH" -> {
                    purposeOfPaymentLovValidation(purposeOfPayment, purposeOfPaymentCode, errorInstances);
                    purposeOfPaymentTextValidation(paymentProcessingData, purposeOfPayment.getFormat(), errorInstances);
                }
                default -> log.error("Purpose of payment format mismatch");
            }
        } else if (StringUtils.hasLength(purposeOfPaymentCode) &&
                ("NA".equals(purposeOfPaymentRequired) || TxnType.FED.toString().equals(paymentProcessingData.getTxnType())) &&
                "N".equals(confirmationMode)) {
            PaymentUtil.buildErrorInstances(ErrorCodeEnum.PURPOSE_OF_PAYMENT_NOT_APPLICABLE, errorInstances);
        }
    }

    private void purposeOfPaymentLovValidation(PurposeOfPayment purposeOfPayment,
                                               String paymentPurposeCode, LinkedList<ErrorInstance> errorInstances) {
        if (!StringUtils.hasLength(paymentPurposeCode)) {
            // TODO Existing code returns here
            PaymentUtil.buildErrorInstances(ErrorCodeEnum.PURPOSE_OF_PAYMENT_MANDATORY, errorInstances);
            return;
        }
        if (!purposeOfPayment.getListOfValues().isEmpty()) {
            List<String> values = purposeOfPayment.getListOfValues().stream().map(ListOfValues::getPurposeCode).toList();
            if (!values.contains(paymentPurposeCode))
                PaymentUtil.buildErrorInstances(ErrorCodeEnum.PURPOSE_OF_PAYMENT, errorInstances);
        }
    }

    private void purposeOfPaymentTextValidation(PaymentProcessingData paymentProcessingData,
                                                String purposeOfPaymentFormat,
                                                LinkedList<ErrorInstance> errorInstances) {
        String reasonForPayment = paymentProcessingData.getRemarks();
        if (!StringUtils.hasLength(reasonForPayment)) {
            //TODO verify custom message in info attribute in old code
            PaymentUtil.buildErrorInstances(ErrorCodeEnum.REASON_FOR_PAYMENT_MANDATORY, errorInstances);
        }
        // TODO verify with Arun if the POP is both, don't set purpose of free form, in other words, only set purpose of free form when POP is text
        if ("TEXT".equals(purposeOfPaymentFormat)) {
            paymentProcessingData.setPurposeOfPaymentFreeForm(StringUtils.hasLength(reasonForPayment) ? reasonForPayment : "");
        } else {
            paymentProcessingData.setPurposeOfPaymentFreeForm("");
        }
    }


    private void validateSwiftBic(PaymentProcessingData paymentProcessingData,
                                  CountryRuleResponse countryRuleResponse,
                                  LinkedList<ErrorInstance> errorInstances) {
        String routingCode = paymentProcessingData.getCreditorBankData().getRoutingCode();
        String swiftCountryCode = countryRuleResponse.getData().getCountryCodeInSWIFTCode();
        if (StringUtils.hasLength(routingCode)) {
            boolean shouldValidateRoutingCode = false;
            if (routingCode.length() == 9) {
                shouldValidateRoutingCode = routingCode.matches("\\d{9}");
            } else if (routingCode.length() == 8 || routingCode.length() == 11) {
                shouldValidateRoutingCode = routingCode.matches("[a-zA-Z0-9]{8}|[a-zA-Z0-9]{11}") && swiftCountryCode.equals(routingCode.substring(4, 6));
            }

            if (shouldValidateRoutingCode) {
                PaymentUtil.buildErrorInstances(ErrorCodeEnum.SWIFT_BIC, errorInstances);
            }
        } else {
            PaymentUtil.buildErrorInstances(ErrorCodeEnum.EMPTY_SWIFT_BIC, errorInstances);
        }
    }

    private void validateBeneficiaryBankInfo(PaymentProcessingData paymentProcessingData, String confirmationMode, Map<String, GACHInfo> currencyGlobalAchInfoMap, CountryRuleResponse countryRuleResponse, String debitCurrency, LinkedList<ErrorInstance> errorInstances) {
        // processDate Beneficiary Bank Info
        BeneficiaryBankInfo beneficiaryBankInfo = CollectionUtils.isEmpty(currencyGlobalAchInfoMap)
                ? countryRuleResponse.getData().getBeneficiaryBankInfo()
                : currencyGlobalAchInfoMap.get(debitCurrency).getBeneficiaryBankInfo();

        String routingCode = paymentProcessingData.getCreditorBankData().getLocalRoutingInformation().getRoutingCode();
        if ("M".equals(beneficiaryBankInfo.getLocalRoutingCodeRequired()) || "O".equals(beneficiaryBankInfo.getLocalRoutingCodeRequired())) {
            // Validate Local Routing Code
            localRoutingCodeValidator(beneficiaryBankInfo, routingCode, paymentProcessingData, confirmationMode,
                    countryRuleResponse, errorInstances);
        } else if (StringUtils.hasLength(routingCode)) {
            paymentProcessingData.getCreditorBankData().getLocalRoutingInformation().setRoutingCode("");
            if ("N".equals(confirmationMode)) {
                PaymentUtil.buildErrorInstances(ErrorCodeEnum.ROUTING_CODE_NOT_APPLICABLE, errorInstances);
            }
        }
    }

    private void localRoutingCodeValidator(BeneficiaryBankInfo beneficiaryBankInfo,
                                           String routingCode,
                                           PaymentProcessingData paymentProcessingData,
                                           String confirmationMode,
                                           CountryRuleResponse countryRuleResponse,
                                           LinkedList<ErrorInstance> errorInstances) {
        if ("M".equals(beneficiaryBankInfo.getLocalRoutingCodeRequired())) {
            String creditorAccountNumber = paymentProcessingData.getCreditAccountData().getAccNum();
            BeneficiaryAccount beneficiaryAccount = countryRuleResponse.getData().getBeneficiaryAccount();
            if (StringUtils.hasLength(creditorAccountNumber) && beneficiaryAccount.getIban() != null &&
                    StringUtils.startsWithIgnoreCase(creditorAccountNumber, beneficiaryAccount.getIban().getIbanISOCountryCode()) &&
                    StringUtils.hasLength(routingCode)) {
                if (confirmationMode.equals("N")) {
                    paymentProcessingData.getCreditorBankData().getLocalRoutingInformation().setRoutingCode("");
                    PaymentUtil.buildErrorInstances(ErrorCodeEnum.LOCAL_ROUTING_CODE_WARNING_CODE, errorInstances);
                }
            } else if (!StringUtils.hasLength(routingCode)) {
                PaymentUtil.buildErrorInstances(ErrorCodeEnum.ROUTING_CODE_MANDATORY, errorInstances);
            }
        }
    }

    private void validateBeneficiaryAccount(PaymentProcessingData paymentProcessingData,
                                            String confirmationMode,
                                            Map<String, GACHInfo> currencyGlobalAchInfoMap,
                                            CountryRuleResponse countryRuleResponse,
                                            String debitCurrency,
                                            LinkedList<ErrorInstance> errorInstances) {

        String creditorAccNum = Optional.ofNullable(paymentProcessingData.getCreditAccountData())
                .map(AccountData::getAccNum)
                .map(value -> value.replaceAll("\\s", ""))
                .orElse("");

        BeneficiaryAccount beneficiaryAccount = CollectionUtils.isEmpty(currencyGlobalAchInfoMap)
                ? countryRuleResponse.getData().getBeneficiaryAccount()
                : currencyGlobalAchInfoMap.get(debitCurrency).getBeneficiaryAccount();

        if (beneficiaryAccount != null && StringUtils.hasLength(creditorAccNum)) {
            if ("M".equals(beneficiaryAccount.getIbanRequired())) {
                if (isValidIban(beneficiaryAccount, creditorAccNum)) {
                    callIBANService(creditorAccNum, confirmationMode, errorInstances);
                } else {
                    // TODO returned in old code
                    PaymentUtil.buildErrorInstances(ErrorCodeEnum.INVALID_IBAN, errorInstances, beneficiaryAccount.getAccountNumberAssistText());
                }
            } else if ("O".equals(beneficiaryAccount.getIbanRequired())) {
                if (isValidIban(beneficiaryAccount, creditorAccNum)) {
                    callIBANService(creditorAccNum, confirmationMode, errorInstances);
                } else {
                    validateAccountNumber(beneficiaryAccount, creditorAccNum, errorInstances, paymentProcessingData.getTransactionCcy());
                }
            }
            validateAccountNumber(beneficiaryAccount, creditorAccNum, errorInstances, paymentProcessingData.getTransactionCcy());
        }
    }

    private boolean isValidIban(BeneficiaryAccount beneficiaryAccount, String creditorAccNum) {
        return Objects.nonNull(beneficiaryAccount.getIban()) && StringUtils.startsWithIgnoreCase(creditorAccNum, beneficiaryAccount.getIban().getIbanISOCountryCode());
    }

    private void validateAccountNumber(BeneficiaryAccount beneficiaryAccount, String creditorAccNum, LinkedList<ErrorInstance> errorInstances, String transactionCurrency) {
        if ("USD".equals(transactionCurrency) &&
                StringUtils.hasLength(beneficiaryAccount.getAccountNumberRegex()) &&
                !Pattern.matches(beneficiaryAccount.getAccountNumberRegex(), creditorAccNum)) {
            log.info("Creditor account number:{} failed to match pattern:{} with assist text {}", creditorAccNum,
                    beneficiaryAccount.getAccountNumberRegex(),
                    beneficiaryAccount.getAccountNumberAssistText());
            PaymentUtil.buildErrorInstances(ErrorCodeEnum.INVALID_ACC, errorInstances);
        }
    }

    private void callIBANService(String counterPartyAcc, String confirmationMode, LinkedList<ErrorInstance> errorInstances) {
        //default response is success(no error or warning)
        IbanValidationRequest ibanValidationRequest = new IbanValidationRequest();
        ibanValidationRequest.setIbanToValidate(counterPartyAcc);
        try {
            IbanValidationResponse ibanValidationResponse = ibanValidationService.validateBankInfoGraphql(ibanValidationRequest);
            //0 = success; 1 = error; 2 = warning
            if ("1".equals(ibanValidationResponse.getResponseCode().getCode())) {
                //TODO Missing dynamic description
                PaymentUtil.buildErrorInstances(ErrorCodeEnum.INVALID_IBAN, errorInstances);
                log.info("Invalid IBAN: {}", ibanValidationResponse.getResponseCode().getDescription());
            } else if ("2".equalsIgnoreCase(ibanValidationResponse.getResponseCode().getCode()) && "N".equals(confirmationMode)) {
                //TODO Missing dynamic description
                PaymentUtil.buildErrorInstances(ErrorCodeEnum.IBAN_WARNING_CODE, errorInstances);
            }
        } catch (PaymentServiceException e) {
            log.atError().setMessage("Payment Service Exception occurred").setCause(e).log();
        }
    }
}


