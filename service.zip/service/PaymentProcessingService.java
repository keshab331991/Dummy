package com.svb.gateway.payments.payment.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.payments.common.alert.GatewayAlert;
import com.svb.gateway.payments.common.alert.util.AlertEnum;
import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.enums.*;
import com.svb.gateway.payments.common.enums.payment.PaymentStatus;
import com.svb.gateway.payments.common.enums.payment.TransactionStatus;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.model.ClientServiceUpdateRequest;
import com.svb.gateway.payments.common.model.approvals.ApprovalCallBackRequest;
import com.svb.gateway.payments.common.model.payment.FXWPaymentProcessingData;
import com.svb.gateway.payments.common.model.payment.PaymentMode;
import com.svb.gateway.payments.common.model.payment.TransferPaymentProcessingData;
import com.svb.gateway.payments.common.model.payment.WirePaymentProcessingData;
import com.svb.gateway.payments.common.model.payment.fxw.FXWPayments;
import com.svb.gateway.payments.common.model.payment.payinit.PaymentResponse;
import com.svb.gateway.payments.common.model.payment.processing.AddPayDetails;
import com.svb.gateway.payments.common.model.payment.processing.FraudParameters;
import com.svb.gateway.payments.common.model.payment.processing.PaymentProcessingData;
import com.svb.gateway.payments.common.model.rulesengine.CountryRuleResponse;
import com.svb.gateway.payments.common.properties.KafkaTopicProperties;
import com.svb.gateway.payments.common.service.StaticDetailsService;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.common.util.PaymentUtil;
import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.entity.TransactionEntryEntity;
import com.svb.gateway.payments.payment.enums.ContractStatusEnum;
import com.svb.gateway.payments.payment.mapper.db.PaymentRequestDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.model.PaymentTransactionStatusMapper;
import com.svb.gateway.payments.payment.model.fxservices.FXContract;
import com.svb.gateway.payments.payment.model.fxservices.FXRetrieveContractsResponse;
import com.svb.gateway.payments.payment.model.fxservices.FxEndToEndStatusRes;
import com.svb.gateway.payments.payment.model.rtp.RtpPaymentInitationResponse;
import com.svb.gateway.payments.payment.util.PaymentProcessingErrorUtil;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.shaded.com.google.protobuf.ServiceException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

import static com.svb.gateway.payments.common.util.PaymentConstant.*;

@Slf4j
@Service
public class PaymentProcessingService {

    private final TransactionEntryDBMapper transactionEntryDBMapper;
    @Value("${spm.enabled}")
    private boolean isSPMEnabled;

    @Value("${usi.spm.enabled}")
    private boolean isUSI_SPMEnabled;

    @Value("${mca.spm.enabled}")
    private boolean isMCA_SPMEnabled;

    @Value("${ica.spm.enabled}")
    private boolean isICA_SPMEnabled;

    @Value("${isoFx.enabled}")
    private boolean isIsoFxFeatureFlagEnabled;

    private final Predicate<String> isFXSplitTransactionId = PaymentUtil::isFXSplitTransactionId;

    private final PaymentInitValidationService paymentInitValidationService;
    private final PaymentProcessingErrorUtil paymentErrorUtil;
    private final PaymentRequestDBMapper paymentRequestDBMapper;
    private final TransactionDBMapper transactionDBMapper;
    private final PaymentTransactionStatusMapper paymentProcessingStatusModelMapper;
    private final KafkaTemplate<String, Object> template;
    private final KafkaTopicProperties kafkaTopicProperties;
    private final RtpService rtpService;
    private final SpmService spmOrchestrationService;
    private final TransferService transferService;
    private final FXService fxService;
    private final StaticDetailsService staticDataService;
    private final ObjectMapper objectMapper;
    private final PaymentStatusUtil paymentStatusUtil;
    private final GTEXService gtexService;

    private static final Character ACTIVATED = 'A';
    private static final Character DEACTIVATED = 'D';


    @Autowired
    public PaymentProcessingService(PaymentInitValidationService paymentInitValidationService,
                                    PaymentProcessingErrorUtil paymentErrorUtil,
                                    PaymentRequestDBMapper paymentRequestDBMapper,
                                    TransactionDBMapper transactionDBMapper,
                                    PaymentTransactionStatusMapper paymentProcessingStatusModelMapper,
                                    KafkaTemplate<String, Object> template,
                                    KafkaTopicProperties kafkaTopicProperties,
                                    RtpService rtpService,
                                    SpmService spmOrchestrationService,
                                    TransferService transferService,
                                    FXService fxService,
                                    StaticDetailsService staticDataService,
                                    ObjectMapper objectMapper,
                                    PaymentStatusUtil paymentStatusUtil,
                                    GTEXService gtexService,
                                    TransactionEntryDBMapper transactionEntryDBMapper) {
        this.paymentInitValidationService = paymentInitValidationService;
        this.paymentErrorUtil = paymentErrorUtil;
        this.paymentRequestDBMapper = paymentRequestDBMapper;
        this.transactionDBMapper = transactionDBMapper;
        this.paymentProcessingStatusModelMapper = paymentProcessingStatusModelMapper;
        this.template = template;
        this.kafkaTopicProperties = kafkaTopicProperties;
        this.rtpService = rtpService;
        this.spmOrchestrationService = spmOrchestrationService;
        this.transferService = transferService;
        this.fxService = fxService;
        this.staticDataService = staticDataService;
        this.objectMapper = objectMapper;
        this.paymentStatusUtil = paymentStatusUtil;
        this.gtexService = gtexService;
        this.transactionEntryDBMapper = transactionEntryDBMapper;
    }

    public void processWirePayment(WirePaymentProcessingData wirePaymentData) {
        PaymentProcessingData paymentProcessingData = wirePaymentData.getPaymentData();
        log.info("Processing Wire Payment : txRefNum:{}", paymentProcessingData.getTxRefNum());

        FraudParameters.RecPmtEnum recPmtEnum = Optional.ofNullable(wirePaymentData.getPaymentData()).map(PaymentProcessingData::getAddPayDetails).map(AddPayDetails::getFraudParameters)
                .map(FraudParameters::getRecPmt).orElse(FraudParameters.RecPmtEnum.NO);
        try {
            // here verify the payment status is in progress or processed it.
            List<PaymentTransactionStatusEntity> statusEntityList = transactionDBMapper.getPaymentTransactions(Long.valueOf(paymentProcessingData.getTxRefNum()));
            if (!CollectionUtils.isEmpty(statusEntityList)) {
                PaymentTransactionStatusEntity statusEntity = statusEntityList.getFirst();
                verifyPaymentProcessingStatus(List.of(statusEntity), FraudParameters.RecPmtEnum.YES.equals(recPmtEnum));
                paymentInitValidationService.validateWirePayment(paymentProcessingData);
                //wire payment to RTP method, post payment to RTP
                if (paymentProcessingData.getPaymentType().equals(PaymentTypeEnum.RTP.toString())) {
                    wirePaymentToRTP(wirePaymentData, statusEntity);
                } else {
                    // Adding leading zeros to the account number if length is < 10
                    PaymentUtil.formatDebitAcctNumForCBSPayment(paymentProcessingData);
                    String creditorBankCountryCode = PaymentUtil.getCreditBankCountryCode(paymentProcessingData);
                    CountryRuleResponse countryRuleResponse = staticDataService.fetchCountrySpecificRules(null, CountryEnum.valueOf(creditorBankCountryCode));
                    paymentInitValidationService.updateCreditorAccountIsIban(paymentProcessingData, countryRuleResponse);
                    PaymentUtil.updateOboDetails(paymentProcessingData);
                    PaymentMode paymentMode = paymentInitValidationService.getPaymentMode(paymentProcessingData,
                            countryRuleResponse);
                    paymentInitValidationService.populateIsIban(paymentProcessingData, countryRuleResponse);
                    wirePaymentToSPM(wirePaymentData, statusEntity, paymentMode);
                }
                paymentStatusUtil.updateEntireStatus(statusEntity, true);
            } else {
                log.info("Not able to fetch transaction with transactionId:{}", paymentProcessingData.getTxRefNum());
            }
        } catch (Exception ex) {
            log.error(UNEXPECTED_ERROR_MESSAGE, ex);
            paymentErrorUtil.handlerConsumerError(
                    Long.valueOf(paymentProcessingData.getTxRefNum()),
                    PaymentUtil.isMCAPayment(paymentProcessingData.getPaymentType()) ||
                            PaymentUtil.isICAPayment(paymentProcessingData.getPaymentType()) ?
                            paymentProcessingData.getPaymentType() : "WIRE",
                    "Unexpected error while processing the wire payment : ", ex);
        }
    }

    @GatewayAlert(alertEnum = AlertEnum.SVB_TRCMPL)
    public void processTransfer(TransferPaymentProcessingData transferPaymentData) throws PaymentServiceException {
        FraudParameters.RecPmtEnum recPmtEnum = Optional.ofNullable(transferPaymentData.getPaymentData()).map(PaymentProcessingData::getAddPayDetails).map(AddPayDetails::getFraudParameters)
                .map(FraudParameters::getRecPmt).orElse(FraudParameters.RecPmtEnum.NO);

        // here verify the payment status is in progress or processed it.
        Long transactionId = Optional.ofNullable(transferPaymentData.getPaymentData()).map(PaymentProcessingData::getTxRefNum).map(Long::parseLong).orElse(0L);
        PaymentTransactionStatusEntity statusEntity = transactionDBMapper.getPaymentTransactions(transactionId).getFirst();
        if (statusEntity != null) {
            verifyPaymentProcessingStatus(List.of(statusEntity), FraudParameters.RecPmtEnum.YES.equals(recPmtEnum));
            log.info("Now Posting to CBS for txn reference Id : {} ", transferPaymentData
                    .getPaymentData().getTxRefNum());
            transferService.postToCBS(statusEntity, transferPaymentData, false);
            log.info("Posting to CBS SUCCESS for txn reference Id: {} ", transferPaymentData
                    .getPaymentData().getTxRefNum());
        } else {
            log.info("Returning FAILED status for txn reference Id: {} ", Optional.of(transferPaymentData)
                    .map(TransferPaymentProcessingData::getPaymentData)
                    .map(PaymentProcessingData::getTxRefNum).orElse(""));
        }
    }

    public void processFXWPaymentFromInitiation(FXWPaymentProcessingData fxwPaymentData) throws ServiceException {
        PaymentProcessingData paymentProcessingData = fxwPaymentData.getPaymentData();
        String txRefNum = paymentProcessingData.getTxRefNum();
        log.info("Entered processFXWPayment method in PaymentProcessingService: TxRefNum:{}", txRefNum);
        paymentProcessingData.getAddPayDetails().setCif(PaymentUtil.cifLeftPadding(paymentProcessingData.getAddPayDetails().getCif()));
        try {
            PaymentTransactionStatusEntity transactionStatus = paymentProcessingStatusModelMapper.convertPaymentToEntity(paymentProcessingData);
            FraudParameters.RecPmtEnum recPmtEnum = Optional.ofNullable(paymentProcessingData.getAddPayDetails()).map(AddPayDetails::getFraudParameters)
                    .map(FraudParameters::getRecPmt).orElse(FraudParameters.RecPmtEnum.NO);

            transactionStatus.setRecurring(FraudParameters.RecPmtEnum.YES.equals(recPmtEnum) ? "Y" : "N");
            // Adding leading zeros to the account number if length is < 10
            PaymentUtil.formatDebitAcctNumForCBSPayment(paymentProcessingData);
            transactionStatus.setStatus(TransactionStatusEnum.INPR.name());
            fxService.processFXWPayment(fxwPaymentData, transactionStatus);
        } catch (Exception e) {
            throw new ServiceException(e);
        }
    }

    public void processFXWPaymentForPostingRetry(FXWPaymentProcessingData fxwPaymentData,
                                                 PaymentTransactionStatusEntity transactionStatus) throws ServiceException {
        PaymentProcessingData paymentProcessingData = fxwPaymentData.getPaymentData();
        String txRefNum = paymentProcessingData.getTxRefNum();
        log.info("Entered processFXWPayment method in PaymentProcessingService: TxRefNum:{}", txRefNum);
        paymentProcessingData.getAddPayDetails().setCif(PaymentUtil.cifLeftPadding(paymentProcessingData.getAddPayDetails().getCif()));
        try {
            FraudParameters.RecPmtEnum recPmtEnum = Optional.ofNullable(paymentProcessingData.getAddPayDetails()).map(AddPayDetails::getFraudParameters)
                    .map(FraudParameters::getRecPmt).orElse(FraudParameters.RecPmtEnum.NO);

            transactionStatus.setRecurring(FraudParameters.RecPmtEnum.YES.equals(recPmtEnum) ? "Y" : "N");
            // Adding leading zeros to the account number if length is < 10
            PaymentUtil.formatDebitAcctNumForCBSPayment(paymentProcessingData);
            transactionStatus.setStatus(TransactionStatusEnum.INPR.name());
            fxService.processFXWPayment(fxwPaymentData, transactionStatus);
        } catch (Exception e) {
            throw new ServiceException(e);
        }
    }

    public void processSplitFXWPayment(FXWPayments fxwPayments) {
        log.info("Entered consume FXW Payment  method in PaymentProcessingService");
        try {
            PaymentProcessingData parentPaymentData = fxwPayments.getPaymentData().getFirst();
            FraudParameters.RecPmtEnum recPmtEnum = Optional.ofNullable(parentPaymentData).map(PaymentProcessingData::getAddPayDetails).map(AddPayDetails::getFraudParameters)
                    .map(FraudParameters::getRecPmt).orElse(FraudParameters.RecPmtEnum.NO);
            if (parentPaymentData != null) {
                List<PaymentTransactionStatusEntity> statusEntityList = transactionDBMapper.getPaymentTransactions(Long.parseLong(parentPaymentData.getTxRefNum()));
                verifyPaymentProcessingStatus(statusEntityList, FraudParameters.RecPmtEnum.YES.equals(recPmtEnum));
                if (!CollectionUtils.isEmpty(statusEntityList)) {
                    log.info("Processing Split FXW payment for transaction_id:{} ", parentPaymentData.getTxRefNum());
                    fxService.processFXWSplitPayments(fxwPayments, statusEntityList);
                    log.info("Completed processing Split FXW payment for transaction_id:{} ", parentPaymentData.getTxRefNum());
                }
            }
        } catch (Exception ex) {
            log.error(UNEXPECTED_ERROR_MESSAGE, ex);
        }
    }

    private void verifyPaymentProcessingStatus(List<PaymentTransactionStatusEntity> paymentTransactionStatusEntityList, boolean isRecurring) throws PaymentServiceException {
        for (PaymentTransactionStatusEntity entity : paymentTransactionStatusEntityList) {
            if (entity == null) {
                throw new PaymentServiceException(ErrorCodeEnum.PAYMENT_TRANSACTION_NOT_FOUND, "The posted payment transaction is not present.");
            }
            if (!StringUtils.hasLength(entity.getDownstreamStatus())) {
                entity.setDownstreamStatus(DownstreamStatusEnum.INITIATED.toString());
            }
            if (isRecurring) {
                entity.setRecurring("Y");
            }
            if (isInProgress(entity)) {
                log.info("Processing payment & status as In-Progress state (valid) -> the payment transaction reference {} ", entity.getTransactionId());
                continue;
            }
            // here log the error because the payment is already processed.
            log.info("The Payment has previously been processed, Payment transaction reference ID : {},  current status :  {} ",
                    entity.getTransactionId(), entity.getStatus() + " -> Insert to error table ");
            paymentErrorUtil.handlerConsumerError(entity.getTransactionId(), entity.getPaymentType(), DUPLICATE_PAYMENT_RECEIVED);
        }
    }

    private void wirePaymentToRTP(WirePaymentProcessingData wirePaymentData, PaymentTransactionStatusEntity statusEntity) throws IOException, PaymentServiceException {
        if (wirePaymentData.getPaymentData().getPaymentType().equals(PaymentTypeEnum.RTP.toString())) {
            RtpPaymentInitationResponse paymentResponse =
                    rtpService.sendPaymentToRtp(wirePaymentData);
            statusEntity.setPaymentRefId(paymentResponse.getPaymentManagerId());
            if (paymentResponse.getPaymentInformationId() != null) {
                statusEntity.setPaymentInfoId(paymentResponse.getPaymentInformationId());
            }
        }
    }

    private void wirePaymentToSPM(WirePaymentProcessingData wirePayment, PaymentTransactionStatusEntity statusEntity, PaymentMode paymentMode) throws IOException, PaymentServiceException {
        if (PaymentConstant.SPM_PAYMENTS.contains(wirePayment.getPaymentData().getPaymentType()) ||
                (FED_XSD_TRANSACTION_TYPES.contains(wirePayment.getPaymentData().getPaymentType()) && isSPMEnabled) ||
                (USI_TRANSACTION_TYPE.contains(wirePayment.getPaymentData().getPaymentType()) && isUSI_SPMEnabled) ||
                (MCA_PAYMENTS.contains(wirePayment.getPaymentData().getPaymentType()) && isMCA_SPMEnabled) ||
                (ICA_PAYMENTS.contains(wirePayment.getPaymentData().getPaymentType()) && isICA_SPMEnabled)) {
            PaymentResponse paymentResponse = spmOrchestrationService.sendWirePaymentToSpm(wirePayment, paymentMode);
            statusEntity.setPaymentRefId(paymentResponse.getPaymentReferenceId());
            if (paymentResponse.getPaymentInformationId() != null) {
                statusEntity.setPaymentInfoId(paymentResponse.getPaymentInformationId());
            }
        } else {
            log.info("Post Payment to Wires Transfer Posting Topic for {}", wirePayment.getPaymentData().getTxRefNum());
            String requestPayload = objectMapper.writeValueAsString(wirePayment);
            log.debug("SPM posting to Kafka : SPM Request Payload : {}", requestPayload);
            template.send(kafkaTopicProperties.getWiresTransferPosting(), requestPayload);
            log.info("Successfully posted to Kafka, update paymentMessage and status to IN_PROCESS for {}", wirePayment.getPaymentData().getTxRefNum());
        }
    }

    private boolean isInProgress(PaymentTransactionStatusEntity statusEntity) {
        return TransactionStatus.INPR.toString().equals(Optional.ofNullable(statusEntity)
                .map(PaymentTransactionStatusEntity::getStatus).orElse(""));
    }

    public void updateApprovalCallBack(ApprovalCallBackRequest approvalCallBackRequest) {
        paymentRequestDBMapper.updateApprovalCallBack(
                approvalCallBackRequest.getEntityId(),
                approvalCallBackRequest.getWorkflowIdStr(),
                approvalCallBackRequest.getCurrentStateCd()
        );
    }

    public void updatePaymentForClosedAccount(String fromAccount, String reason) {
        List<String> paymentIds = paymentRequestDBMapper.getPaymentsForAccount(fromAccount);
        if (paymentIds != null && !paymentIds.isEmpty()) {
            Timestamp now = new Timestamp(System.currentTimeMillis());
            paymentRequestDBMapper.updatePaymentEntityForClosedAccount(
                    fromAccount, reason, now);
            paymentRequestDBMapper.updatePaymentForClosedAccount(paymentIds, reason, PaymentStatus.PNAP, PaymentStatus.CBNK, now);
        }
    }

    private ClientServiceUpdateRequest.ClientServices transformServiceName(ClientServiceUpdateRequest.ClientServices clientService) {
        if (PaymentTypeEnum.GLOBAL_ACH.toString().equals(clientService.getServiceName())) {
            clientService.setServiceName("GACH");
        } else if (PaymentTypeEnum.CHECK.toString().equals(clientService.getServiceName())) {
            clientService.setServiceName("CHK");
        } else if (PaymentTypeEnum.INT_TRANSFER.toString().equals(clientService.getServiceName())) {
            clientService.setServiceName("TRANSFERS");
        }
        return clientService;
    }

    public void retrieveFXPaymentStatus(PaymentTransactionStatusEntity txnStatus) {
        log.info("FXPaymentStatusJob : Processing retrieveFXPaymentStatus for Transaction Id: {} and status {}",
                txnStatus.getTransactionId(), txnStatus.getStatus());
        Long transactionId = txnStatus.getTransactionId();
        FXRetrieveContractsResponse fxRetrieveContractsResponse;

        try {
            if ("SDMC".equalsIgnoreCase(txnStatus.getPaymentCategory())) {
                log.info("FXPaymentStatusJob : Get FXRetrieveContracts for split payment : Transaction Id: {} ",
                        txnStatus.getTransactionId());
                fxRetrieveContractsResponse = fxService.getFXRetrieveContractsResponseByDealLinkId(txnStatus.getClientId(), txnStatus.getContractId(), txnStatus.getSplitDebitType(), transactionId);
                processSplitPaymentContracts(txnStatus, transactionId, fxRetrieveContractsResponse);
            } else {
                log.info("FXPaymentStatusJob : Get FXRetrieveContracts payment : Transaction Id: {} ",
                        txnStatus.getTransactionId());
                fxRetrieveContractsResponse = fxService.getFXRetrieveContractsResponse(txnStatus.getClientId(), txnStatus.getContractId(), transactionId);
                if (isNotSingleRecord(transactionId, fxRetrieveContractsResponse == null ? 0 : fxRetrieveContractsResponse.getContracts().size())) {
                    return;
                }
                if (fxRetrieveContractsResponse != null) {
                    List<TransactionEntryEntity> transactions = transactionEntryDBMapper.getTransactionEntries(transactionId);
                    processPaymentContractFromFx(txnStatus, transactionId, fxRetrieveContractsResponse.getContracts().getFirst(), transactions.getFirst());
                }
            }
        } catch (Exception e) {
            log.error("Exception while retrieving FX Payment Status :: for transaction Id: {} with message: {}", txnStatus.getTransactionId(), e.getMessage());
        }
    }

    boolean isNotSingleRecord(Long paymentId, int numberOfRecords) {

        if (numberOfRecords == 0) {
            log.info("Transaction Id: {} not available on WSS.", paymentId);
            return true;
        } else if (numberOfRecords > 1) {
            log.info("Transaction Id: {}  has multiple records in WSS.", paymentId);
            return true;
        }
        return false;
    }

    private void processSplitPaymentContracts(PaymentTransactionStatusEntity parentEntity, Long transactionId,
                                              FXRetrieveContractsResponse fxRetrieveContractsResponse) {
        log.info("FXPaymentStatusJob : Processing list of contracts for parent transactionId: {} ", transactionId);
        String childPaymentId = null;

        //Fetch all the individual split payments statuses, specific to a parent paymentId
        List<TransactionEntryEntity> splitTransactions = transactionEntryDBMapper.getTransactionEntries(transactionId);

        List<Long> processedSplitPaymentIds = splitTransactions.stream()
                .filter(e -> e.getStatus() != null && (CONTRACT_PROCESS_FINAL_STATUSES.contains(e.getStatus().toUpperCase())))
                .map(TransactionEntryEntity::getTransactionId).toList();

        for (FXContract fxContract : fxRetrieveContractsResponse.getContracts()) {
            try {
                //Remove 'GW_' from the WireTransactionId
                childPaymentId = fxContract.getWireTransactionId() != null ? PaymentUtil.trimWireTransactionId(fxContract.getWireTransactionId()) : "";

                //Skip split payment contract process if it is already processed
                if (!childPaymentId.isEmpty() && isFXSplitTransactionId.test(childPaymentId)
                        && !processedSplitPaymentIds.contains(Long.valueOf(childPaymentId.substring(0, childPaymentId.indexOf("SP"))))) {
                    log.info("FXPaymentStatusJob : processing the contract : contract transaction Id : {} : Payment Transaction Id: {} ",
                            childPaymentId, transactionId);
                    final long finalChildPaymentId = Long.parseLong(childPaymentId.substring(0, childPaymentId.indexOf("SP")));
                    TransactionEntryEntity matchingEntity = splitTransactions.stream()
                            .filter(e -> e.getTransactionId() == finalChildPaymentId).toList().getFirst();
                    processPaymentContractFromFx(parentEntity, Long.valueOf(childPaymentId), fxContract, matchingEntity);
                }
            } catch (Exception e) {
                log.error("FXPaymentStatusJob : An error has been occurred while processing the FX Split payment contract for the contract transaction Id:{} - {} ", childPaymentId, e.getMessage());
            }
        }

    }

    private void processPaymentContractFromFx(PaymentTransactionStatusEntity txnStatus, Long paymentId, FXContract contractResponse, TransactionEntryEntity txnEntry) {
        if (contractResponse != null) {
            PaymentTransactionStatusEntity paymentProcessingStatusEntity = new PaymentTransactionStatusEntity();

            boolean isValidContract = false;
            log.info("FXPaymentStatusJob : Processing list of contracts for transaction Id: {}", paymentId);
            String contractStatus = contractResponse.getContractStatus();
            boolean isContractCancelled = contractStatus.equalsIgnoreCase(ContractStatusEnum.CANCELLED.toString());
            boolean isTransactionTypeBuyback = isBuybackTransaction(contractResponse);
            String dealNumber = contractResponse.getDealNumber();
            paymentProcessingStatusEntity.setTransactionId(paymentId);
            paymentProcessingStatusEntity.setDealNumber(dealNumber);
            paymentProcessingStatusEntity.setContractId(txnEntry.getFxContractId());

            /*If Contract is processed on WSS set the payment status to PROCESSED and update OCH status to SUC*/
            FxEndToEndStatusRes fxEndToEndStatusRes = isContractSuccess(dealNumber, contractStatus, txnStatus, txnEntry);
            if (fxEndToEndStatusRes != null && FX_DEAL_PROCESSED.equalsIgnoreCase(fxEndToEndStatusRes.getPaymentStatus())) {
                //update status to PROCESSED in DB
                paymentProcessingStatusEntity.setStatus(TransactionStatusEnum.SENT.name());
                paymentProcessingStatusEntity.setSwiftRefNum(fxEndToEndStatusRes.getUetr());
                paymentProcessingStatusEntity.setUetr(fxEndToEndStatusRes.getUetr());
                paymentProcessingStatusEntity.setPaymentInfoId(fxEndToEndStatusRes.getSourceReferenceId());
                isValidContract = true;
                log.info("FXPaymentStatusJob: Updated payment status to PROCESSED in Payments DB for transaction Id {} the dealNumber {}", paymentId, dealNumber);
            } else if (isContractCancelled || isTransactionTypeBuyback) {
                paymentProcessingStatusEntity.setStatus(TransactionStatusEnum.FAIL.name());
                paymentProcessingStatusEntity.setRemarks("FX Contract Cancelled");
                isValidContract = true;
                log.info("FXPaymentStatusJob: Updated payment status to FAIL in Payments DB for transaction Id {}, " +
                        "isContractCancelled {}, isTransactionTypeBuyback {}", paymentId, isContractCancelled, isTransactionTypeBuyback);
            }
            if (isValidContract) {
                updateFXResponse(paymentId, paymentProcessingStatusEntity);
            }
        }
    }

    private void processPaymentContractFromGtex(PaymentTransactionStatusEntity txnEntity, Long transactionId, FXContract contractResponse, TransactionEntryEntity txnEntry) {
        if (contractResponse != null) {
            PaymentTransactionStatusEntity paymentProcessingStatusEntity = new PaymentTransactionStatusEntity();

            boolean isValidContract = false;
            log.info("FXPaymentStatusJob: Processing list of contracts (FromGtex) for transaction Id: {}", transactionId);
            String contractStatus = contractResponse.getContractStatus();
            boolean isContractCancelled = contractStatus.equalsIgnoreCase(ContractStatusEnum.CANCELLED.toString());
            boolean isTransactionTypeBuyback = isBuybackTransaction(contractResponse);
            String dealNumber = contractResponse.getDealNumber();
            paymentProcessingStatusEntity.setTransactionId(txnEntity.getTransactionId());
            paymentProcessingStatusEntity.setDealNumber(dealNumber);
            paymentProcessingStatusEntity.setSwiftRefNum(dealNumber);
            paymentProcessingStatusEntity.setContractId(txnEntry.getFxContractId());

            /*If Contract is processed on WSS set the payment status to PROCESSED and update OCH status to SUC*/
            if (isContractSuccess(txnEntity, contractStatus, dealNumber, txnEntry)) {

                //update status to PROCESSED in DB
                paymentProcessingStatusEntity.setStatus(TransactionStatusEnum.SENT.name());

                isValidContract = true;
                log.info("FXPaymentStatusJob: FromGtex: Updated payment status to PROCESSED in Payments DB for transaction Id {}, " +
                        "the dealNumber {} ", transactionId, dealNumber);
            } else if (isContractCancelled || isTransactionTypeBuyback) {
                paymentProcessingStatusEntity.setStatus(TransactionStatusEnum.FAIL.name());
                paymentProcessingStatusEntity.setRemarks("FX Contract Cancelled");
                isValidContract = true;
                log.info("FXPaymentStatusJob: FromGtex : Updated payment status to FAIL in Payments DB for transaction Id {}, " +
                        "isContractCancelled {}, isTransactionTypeBuyback {}", transactionId, isContractCancelled, isTransactionTypeBuyback);
            }
            if (isValidContract) {
                updateFXResponse(transactionId, paymentProcessingStatusEntity);
            }
        }
    }

    private boolean isBuybackTransaction(FXContract fxContract) {
        return fxContract.getContractStatus().equalsIgnoreCase(ContractStatusEnum.BOUGHT_BACK.toString());
    }

    private FxEndToEndStatusRes isContractSuccess(String dealNumber, String contractStatus, PaymentTransactionStatusEntity txnStatus, TransactionEntryEntity txnEntry) {
        //MCA Fx transaction (XMM, XMC) ——> don’t check E2E status
        //IF the Recipient bank routing number starts with "SVBKUS" OR "121140399"  ——> don’t check E2E status
        boolean isContractProcessed = contractStatus.equalsIgnoreCase(ContractStatusEnum.PROCESSED.toString());
        String routingCode = Optional.ofNullable(txnEntry.getPayeeRoutingCode()).orElse(CommonConstant.EMPTY);
        String routingType = Optional.ofNullable(txnEntry.getPayeeRoutingType()).orElse(CommonConstant.EMPTY);
        String localRoutingCode = Optional.ofNullable(txnEntry.getPayeeLocalRoutingCode()).orElse(CommonConstant.EMPTY);
        String localRoutingType = Optional.ofNullable(txnEntry.getPayeeLocalRoutingType()).orElse(CommonConstant.EMPTY);

        FxEndToEndStatusRes fxEndToEndStatusRes = null;
        if (isContractProcessed) {
            if (MCA_FX_TRANSFER_TYPES.contains(txnStatus.getPaymentType()) ||
                    (PAYMENT_ROUTING_TYPE_SWIFT.equals(routingType) && routingCode.startsWith(CommonConstant.SVB_BANK_US)) ||
                    ("ABA".equals(localRoutingType) && localRoutingCode.startsWith(CommonConstant.SVB_ABA_ROUTING_CODE))) {
                fxEndToEndStatusRes = FxEndToEndStatusRes.builder().uetr(dealNumber).sourceReferenceId(dealNumber).paymentStatus(FX_DEAL_PROCESSED).build();
            } else {
                fxEndToEndStatusRes = fxService.getE2EStatus(dealNumber);
            }
        }
        return fxEndToEndStatusRes;
    }


    private boolean isContractSuccess(PaymentTransactionStatusEntity statusEntity, String contractStatus, String dealNumber, TransactionEntryEntity fxwPayment) {

        boolean isContractProcessed = contractStatus.equalsIgnoreCase(ContractStatusEnum.PROCESSED.toString());

        boolean isRecBankInUS = isRecBankInUSForTxnTypeMXWOrFXW(statusEntity.getPaymentType(), fxwPayment);
        boolean isTxnCcyUSDForMXW = isTxnCcyUSDForMXW(statusEntity.getPaymentType(), statusEntity.getPaymentCurrency());

        return (isContractProcessed
                && (MCA_FX_TRANSFER_TYPES.contains(statusEntity.getPaymentType()) || isRecBankInUS || isTxnCcyUSDForMXW
                || GTEX_ACKNOWLEDGED.equalsIgnoreCase(gtexService.getE2EStatus(dealNumber))));
    }

    private static boolean isRecBankInUSForTxnTypeMXWOrFXW(String paymentType, TransactionEntryEntity txnEntry) {
        return PAYMENTS_FXW_MXW.contains(paymentType) && COUNTRY_US.equalsIgnoreCase(txnEntry.getPayeeBankCountry())
                && (PAYMENT_ROUTING_TYPE_ABA.equals(txnEntry.getPayeeLocalRoutingType()) || (PAYMENT_ROUTING_TYPE_SWIFT.equals(txnEntry.getPayeeRoutingType())
                && getCountryCode(txnEntry.getPayeeRoutingCode()).equals(COUNTRY_US)));
    }

    private boolean isTxnCcyUSDForMXW(String paymentType, String txnCurrency) {
        String transactionCcy = txnCurrency != null ? txnCurrency : CommonConstant.EMPTY;
        return PaymentConstant.MXW_TRANSACTION_TYPE.equals(paymentType)
                && transactionCcy.equalsIgnoreCase(CURRENCY_USD);
    }

    private static String getCountryCode(String routingCode) {
        return routingCode.length() >= 6 ? routingCode.substring(4, 6) : "";
    }

    private void updateFXResponse(Long paymentId, PaymentTransactionStatusEntity txnStatusEntity) {
        if (isFXSplitTransactionId.test(String.valueOf(paymentId))) {
            //Update contractId, it might be missed if WSS posting response sends an empty splits response
            paymentStatusUtil.updateFxTxnEntryStatusAndRefInfos(txnStatusEntity);
        } else {
            paymentStatusUtil.setE2ERefNo(txnStatusEntity);
            paymentStatusUtil.updateEntireStatus(txnStatusEntity, true);
        }
    }
}

