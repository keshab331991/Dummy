package com.svb.gateway.payments.payment.service.host;

import com.svb.gateway.payments.common.enums.ErrorCodeEnum;
import com.svb.gateway.payments.common.enums.payment.PaymentType;
import com.svb.gateway.payments.common.enums.payment.TransactionStatus;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.model.payment.billpay.CancelResponse;
import com.svb.gateway.payments.common.model.payment.cancellation.PaymentCancellationData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BillPayService {
    private final BillPayRetryComponent billPayRetryComponent;

    public BillPayService(BillPayRetryComponent billPayRetryComponent) {
        this.billPayRetryComponent = billPayRetryComponent;
    }

    /**
     * Cancel payment in bill pay and return status to be updated in DB accordingly
     *
     * @param cancellationData PaymentCancellationData
     * @return TransactionStatus
     * @throws PaymentServiceException e
     */
    public TransactionStatus cancelPayment(PaymentCancellationData cancellationData) throws PaymentServiceException {
        try {
            // check for void vs cancel
            boolean voidPayment = cancellationData.getTransactionStatus().equals(TransactionStatus.SENT);
            // call bill-pay
            CancelResponse response = billPayRetryComponent.cancelPayment(cancellationData.getTransactionId(), voidPayment);

            TransactionStatus status;
            // process response
            if (!voidPayment
                    && response.getStatus().equals("3")) {
                status = TransactionStatus.CURT;
            } else if (voidPayment
                    && cancellationData.getPaymentType().equals(PaymentType.ACH)
                    && response.getVoidRequests().getFirst().getStatus().equals("1")) {
                status = TransactionStatus.VOID;
            } else if (voidPayment
                    && cancellationData.getPaymentType().equals(PaymentType.CHK)
                    && response.getVoidRequests().getFirst().getStatus().equals("0")) {
                status = TransactionStatus.PVOD;
            } else {
                log.error("Error cancelling payment {} invalid status", cancellationData.getTransactionId());
                throw new PaymentServiceException(ErrorCodeEnum.PAYMENT_CANCELLATION_ERROR, "Invalid status from bill pay");
            }
            return status;
        } catch (PaymentServiceException e) {
            log.error("Error cancelling payment {} {}", cancellationData.getTransactionId(), e.getMessage(), e);
            throw e;
        }
    }
}