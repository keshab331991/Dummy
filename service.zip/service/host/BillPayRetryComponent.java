package com.svb.gateway.payments.payment.service.host;

import com.svb.gateway.payments.common.enums.ErrorCodeEnum;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.model.payment.billpay.CancelResponse;
import com.svb.gateway.payments.common.properties.PaymentProperties;
import com.svb.gateway.payments.common.service.GenericRestClient;
import com.svb.gateway.payments.common.util.HttpResponseContainer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.retry.RetryContext;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.retry.support.RetrySynchronizationManager;
import org.springframework.stereotype.Component;

import java.net.http.HttpTimeoutException;
import java.time.Duration;
import java.util.Optional;

@Component
@Slf4j
public class BillPayRetryComponent {

    private final GenericRestClient genericRestClient;
    private final PaymentProperties paymentProperties;

    public BillPayRetryComponent(GenericRestClient genericRestClient,
                                 PaymentProperties paymentProperties) {
        this.genericRestClient = genericRestClient;
        this.paymentProperties = paymentProperties;
    }

    @Retryable(exceptionExpression = "@customHttpTimeoutRetryChecker.shouldRetry(#root)",
            backoff = @Backoff(delay = 1000, multiplier = 2),
            recover = "retryCancelPaymentTimeout")
    public CancelResponse cancelPayment(long transactionId, boolean voidPayment) throws PaymentServiceException {
        HttpResponseContainer<CancelResponse> response;

        Integer retryCount = Optional.ofNullable(RetrySynchronizationManager.getContext())
                .map(RetryContext::getRetryCount)
                .orElse(0);

        String url;
        if (voidPayment) {
            url = paymentProperties.getBillPayHostUrl() +
                    String.format(paymentProperties.getBillPayVoidPath(), transactionId);
        } else {
            url = paymentProperties.getBillPayHostUrl() +
                    String.format(paymentProperties.getBillPayCancelPath(), transactionId);
        }

        log.info("attempt {} cancel transactionId:{} request URL:{}", retryCount, transactionId, url);

        response = genericRestClient.post(url,
                "{}",
                CancelResponse.class,
                Duration.ofSeconds(10L),
                null,
                true);

        if (response.getStatusCode().is2xxSuccessful()) {
            log.info("attempt {} cancel transaction id {} response from {}: {}", retryCount, transactionId, url, response.getSuccessResponse());
            return response.getSuccessResponse();
        } else {
            log.error("attempt {} cancel transaction id {} response from {}: {}", retryCount, transactionId, url, response.getErrorResponse());
            throw new PaymentServiceException(1, ErrorCodeEnum.PAYMENT_CANCELLATION_ERROR,
                    "Error cancelling transaction in bill-pay " + response.getErrorResponse());
        }
    }

    /**
     * Callback method to accept HttpTimeoutException and throw PaymentServiceException
     * after 3 timeouts
     *
     * @param e HttpTimeoutException
     * @throws PaymentServiceException ex
     */
    @Recover
    public CancelResponse retryCancelPaymentTimeout(HttpTimeoutException e) throws PaymentServiceException {
        log.error("Timeout while creating approval workflow {} after 3 attempts", e.getMessage(), e);
        throw new PaymentServiceException(ErrorCodeEnum.HOST_CALL_FAILURE, "BillPay MS call timeout after 3 attempts", e);
    }
}