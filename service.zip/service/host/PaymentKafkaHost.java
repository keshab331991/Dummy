package com.svb.gateway.payments.payment.service.host;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.payment.PaymentType;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.properties.KafkaTopicProperties;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.model.ProcessingSplitMessage;
import com.svb.gateway.payments.payment.service.manager.PaymentManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Service
public class PaymentKafkaHost {

    private final KafkaTopicProperties kafkaTopicProperties;
    private final KafkaTemplate<String, Object> template;
    private final ObjectMapper objectMapper;

    public PaymentKafkaHost(KafkaTopicProperties kafkaTopicProperties,
                            KafkaTemplate<String, Object> template,
                            ObjectMapper objectMapper) {
        this.kafkaTopicProperties = kafkaTopicProperties;
        this.template = template;
        this.objectMapper = objectMapper;
    }

    /**
     * Sending a message to a kafka topic (producer)
     *
     * @param requestData    RequestData<PaymentInitiationData> requestData
     * @param key            String
     * @param message        ProcessingSplitMessage
     * @param paymentManager PaymentManager
     */
    public void send(RequestData<PaymentInitiationData> requestData, String key, ProcessingSplitMessage message, PaymentManager paymentManager) {
        // for split payment transaction id is the same
        long transactionId = requestData.getRequest().getTransactionId();
        try {
            CompletableFuture<SendResult<String, Object>> future = CompletableFuture.completedFuture(null);
            if (kafkaTopicProperties.isProduceMessageEnabled()) {
                future = template.send(Objects.requireNonNull(getTopic(requestData.getRequest().getPaymentType())), key, objectMapper.writeValueAsString(message));
            }
            triggerKafka(requestData, paymentManager, future, transactionId, true);
        } catch (Exception e) {
            log.error(CommonConstant.ATTENTION + " transaction {} failed to post", transactionId, e);
            paymentManager.kafkaHostCallbackOnFailure(transactionId, requestData.getGatewayContext().getUserId());
        }
    }

    /**
     * Sending messages to a kafka topic (producer)
     *
     * @param requestData    RequestData<PaymentInitiationData> requestData
     * @param key            String
     * @param message        ProcessingSplitMessage
     * @param paymentManager PaymentManager
     */
    public void send(RequestData<PaymentInitiationData> requestData, String key, ProcessingMessage message, PaymentManager paymentManager) {
        long transactionId = requestData.getRequest().getTransactionId();
        try {
            CompletableFuture<SendResult<String, Object>> future = CompletableFuture.completedFuture(null);
            if (kafkaTopicProperties.isProduceMessageEnabled()) {
                future = template.send(Objects.requireNonNull(getTopic(requestData.getRequest().getPaymentType())), key, objectMapper.writeValueAsString(message));
            } else {
                log.info("Kafka Produce Message is disabled");
            }
            triggerKafka(requestData, paymentManager, future, transactionId, false);
        } catch (Exception e) {
            log.error(CommonConstant.ATTENTION + " transaction {} failed to post", transactionId, e);
            paymentManager.kafkaHostCallbackOnFailure(transactionId, requestData.getGatewayContext().getUserId());
        }
    }

    private void triggerKafka(RequestData<PaymentInitiationData> requestData,
                                     PaymentManager paymentManager,
                                     CompletableFuture<SendResult<String, Object>> future,
                              long transactionId,
                              boolean isSplit) {
        future.whenComplete((result, ex) -> {
            if (ex == null) {
                if (isSplit) {
                    log.info("split transaction {} posted to kafka successfully", transactionId);
                } else {
                    log.info("transaction {} posted to kafka successfully", transactionId);
                }
            } else {
                log.error(CommonConstant.ATTENTION + " transaction {} failed to post exception during future completion ", transactionId, ex);
                paymentManager.kafkaHostCallbackOnFailure(transactionId, requestData.getGatewayContext().getUserId());
            }
        });
    }

    /**
     * Get kafka topic name for a payment type
     *
     * @param paymentType PaymentType
     * @return String
     */
    private String getTopic(PaymentType paymentType) {
        return switch (paymentType) {
            case ACH -> kafkaTopicProperties.getAch();
            case CHK -> kafkaTopicProperties.getChk();
            case XFR -> kafkaTopicProperties.getTransfer();
            case FED, USI, MSI, MSG, XMR, SAM, XST, XSD, ICA, ICT, FET -> kafkaTopicProperties.getWire();
            case FXW, FXG, MXW, MXG, XMC, XMM -> kafkaTopicProperties.getFx();
            case RTP -> kafkaTopicProperties.getRtp();
        };
    }
}
