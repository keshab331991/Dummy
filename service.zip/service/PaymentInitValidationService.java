package com.svb.gateway.payments.payment.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.entity.ClientDetailEntity;
import com.svb.gateway.payments.common.enums.PaymentTypeEnum;
import com.svb.gateway.payments.common.enums.payment.IsIban;
import com.svb.gateway.payments.common.enums.payment.WireType;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.mapper.db.ClientDetailsDBMapper;
import com.svb.gateway.payments.common.model.Address;
import com.svb.gateway.payments.common.model.mdm.MDMClient;
import com.svb.gateway.payments.common.model.payment.PaymentMode;
import com.svb.gateway.payments.common.model.payment.processing.*;
import com.svb.gateway.payments.common.model.rulesengine.*;
import com.svb.gateway.payments.common.service.MDMService;
import com.svb.gateway.payments.common.service.StaticDetailsService;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.common.util.PaymentUtil;
import com.svb.gateway.payments.payment.mapper.PaymentMapperUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.function.BiPredicate;

import static com.svb.gateway.payments.common.util.PaymentConstant.*;

@Slf4j
@Service
public class PaymentInitValidationService {

    @Value("${mdm.skipOnFailure}")
    private boolean mdmSkipOnFailure;

    @Value("${gfbClient.enabled}")
    private boolean isGFBClientFeatureFlagEnabled;

    @Value("${mca.spm.enabled}")
    private boolean isMCA_SPMEnabled;

    private final MDMService mdmService;
    private final StaticDetailsService staticDetailsService;
    private final PaymentRulesService paymentRulesService;
    private final ClientDetailsDBMapper clientDetailsDBMapper;
    private final ObjectMapper objectMapper;

    @Autowired
    public PaymentInitValidationService(MDMService mdmService,
                                        StaticDetailsService staticDetailsService,
                                        PaymentRulesService paymentRulesService,
                                        ClientDetailsDBMapper clientDetailsDBMapper,
                                        ObjectMapper objectMapper) {
        this.mdmService = mdmService;
        this.staticDetailsService = staticDetailsService;
        this.paymentRulesService = paymentRulesService;
        this.clientDetailsDBMapper = clientDetailsDBMapper;
        this.objectMapper = objectMapper;
    }

    public void validateWirePayment(PaymentProcessingData paymentData) {
        if (paymentData != null) {
            String debtorCif = PaymentUtil.getCif(paymentData);
            Data debtorData = null;
            try {
                MDMClient mdmClient = mdmService.fetchCifAddressInformationFromMDM(debtorCif);
                debtorData = PaymentMapperUtil.constructAccountDetails(mdmClient, paymentData.getDebtorData(), PaymentMapperUtil.getTxRefNum(paymentData));
                paymentData.setDebtorData(debtorData);
            } catch (PaymentServiceException e) {
                log.atError().setMessage("mdmService failed for cif:{} during DebtorData population").addArgument(debtorCif).setCause(e).log();
                ClientDetailEntity clientDetailEntity = clientDetailsDBMapper.getClientDetails(debtorCif);
                paymentData.setDebtorData(PaymentMapperUtil.constructDebtorData(paymentData, clientDetailEntity));

            }
            log.info("exiting debtor data set");
            setWireType(paymentData);
            Optional.of(paymentData)
                    .map(PaymentProcessingData::getCreditAccountData)
                    .map(AccountData::getAccNum)
                    .map(PaymentUtil::sanitizeString)
                    .map(PaymentUtil::convertToUpperCase)
                    .ifPresentOrElse(creditAccountNum -> paymentData.getCreditAccountData().setAccNum(creditAccountNum), () -> paymentData.getCreditAccountData().setAccNum(CommonConstant.EMPTY));
            log.info("update creditor data start");
            updateCreditorData(paymentData, debtorData, debtorCif);
            log.info("update creditor data end");
            updateCreditorBankData(paymentData);
            updateIntermediaryBankData(paymentData);
        }
    }

    public void updateCreditorData(PaymentProcessingData paymentData, Data debtorData, String debtorCif) {
        Data creditorData = paymentData.getCreditorData();
        String creditorCif = Optional.ofNullable(paymentData.getCreditAccountData()).map(AccountData::getCif).orElse(EMPTY);
        String creditAccountType = Optional.ofNullable(paymentData.getCreditAccountData()).map(AccountData::getAccType).orElse(EMPTY);
        log.info("creditAccountType:{}, creditorCif:{}, paymentType:{}", creditAccountType, creditorCif, paymentData.getPaymentType());
        if (CommonConstant.TRANSFER_TYPES.contains(paymentData.getPaymentType()) &&
                !PaymentTypeEnum.XFR.toString().equals(paymentData.getPaymentType()) &&
                StringUtils.hasLength(creditorCif) &&
                !"SAM".equals(creditAccountType)) {
            if (creditorCif.equals(debtorCif)) {
                try {
                    // Creating a clone object and assigning it to creditor Data
                    creditorData = objectMapper.readValue(objectMapper.writeValueAsString(debtorData), Data.class);
                } catch (JsonProcessingException e) {
                    log.error("Unable to parse debtor data as JSON", e);
                }
            } else {
                try {
                    MDMClient mdmClient = mdmService.fetchCifAddressInformationFromMDM(creditorCif);
                    creditorData = PaymentMapperUtil.constructAccountDetails(mdmClient, paymentData.getCreditorData(), PaymentMapperUtil.getTxRefNum(paymentData));
                } catch (PaymentServiceException e) {
                    log.atError().setMessage("mdmService failed for cif:{} during CreditorData population").addArgument(debtorCif).setCause(e).log();
                }
            }
        } else {
            // here combine creditor address line1 & address line 2
            if (creditorData != null && creditorData.getAddress() != null
                    && creditorData.getAddress().getAddLine2() != null) {
                creditorData.getAddress().setAddLine1(creditorData.getAddress().getAddLine1()
                        + " " + creditorData.getAddress().getAddLine2());
                creditorData.getAddress().setAddLine2(null);
            }
        }
        paymentData.setCreditorData(creditorData);
    }

    public void populateIsIban(PaymentProcessingData paymentProcessingData, CountryRuleResponse countryRuleResponse) {
        if ("ICA".equals(paymentProcessingData.getPaymentType())) {
            boolean isIban = false;
            try {
                AccountData debtorAccountData = paymentProcessingData.getDebitAccountData();
                BankData debtorBankData = paymentProcessingData.getDebtorBankData();
                String routingType = StringUtils.hasLength(debtorBankData.getRoutingType()) ?
                        debtorBankData.getRoutingType() :
                        PaymentUtil.getRoutingType(debtorBankData.getRoutingCode());
                if (StringUtils.hasText(routingType) &&
                        (PaymentConstant.PAYMENT_ROUTING_TYPE_SWIFT.equals(routingType) || PAYMENT_ROUTING_TYPE_BIC.equals(routingType)) &&
                        (StringUtils.hasLength(debtorAccountData.getAccNum()) && PaymentUtil.areFirstTwoCharsAlphabet(debtorAccountData.getAccNum())) &&
                        debtorBankData.getAddress() != null &&
                        !debtorBankData.getAddress().getCountry().isEmpty()) {
                    String ibanISOCountryCode = Optional.ofNullable(countryRuleResponse)
                            .map(CountryRuleResponse::getData)
                            .map(RuleData::getBeneficiaryAccount)
                            .map(BeneficiaryAccount::getIban)
                            .map(RuleEngineIban::getIbanISOCountryCode)
                            .orElse("");
                    String debitAccountNum = debtorAccountData.getAccNum();
                    if (StringUtils.hasLength(ibanISOCountryCode) &&
                            StringUtils.hasLength(debitAccountNum) &&
                            debitAccountNum.length() > 2) {
                        isIban = debitAccountNum.substring(0, 2).equals(ibanISOCountryCode);
                    }
                }
                log.info("Payment debtor account IBAN status: {}, transactionId: {}", isIban, paymentProcessingData.getTxRefNum());
            } catch (Exception e) {
                log.error("Exception Occurred in isDebtorAccountIban: {}", String.valueOf(e));
                isIban = false;
            }
            paymentProcessingData.getDebitAccountData().setIsIban(isIban ? IsIban.Y : IsIban.N);
        }
    }

    public PaymentMode getPaymentMode(PaymentProcessingData paymentData,
                                      CountryRuleResponse countryRuleResponse) {
        log.info("Calling Rules Engine service");
        PaymentMode paymentMode = new PaymentMode();
        paymentMode = paymentRulesService.getCountryRule(countryRuleResponse, paymentData.getPaymentType(),
                paymentData.getTransactionCcy(), paymentMode);
        if (Objects.nonNull(paymentData.getCreditorBankData().getLocalRoutingInformation())) {
            paymentData.getCreditorBankData()
                    .getLocalRoutingInformation().setPrefix(paymentMode.getLocalRoutingInformationPrefix());
        }
        paymentData.setPurposeOfPaymentPrefix(paymentMode.getPurposeOfPaymentPrefix());
        paymentData.setPurposeOfPaymentPosition(paymentMode.getPurposeOfPaymentPosition());
        paymentData.getCreditorBankData().setIsoClearingSystemId(paymentMode.getIsoClearingSystemId());
        if ((paymentData.getPurposeOfPayment() != null) && (!paymentData.getPurposeOfPayment().isEmpty())) {
            if (isMCA_SPMEnabled && "MSG".equals(paymentData.getPaymentType()) &&
                    "77B".equals(paymentData.getPurposeOfPaymentPosition())) {
                paymentData.setPurposeOfPayment(paymentData.getPurposeOfPayment());
            } else {
                paymentData.setPurposeOfPayment(Optional.ofNullable(paymentMode.getPurposeOfPaymentPrefixCode())
                        .orElse(PaymentConstant.EMPTY) + paymentData.getPurposeOfPayment());
            }
        }

        //checking for GFB client and adding fee waiver for purpose of payment or reason for payment
        if (isGFBClientFeatureFlagEnabled) {
            processGFBClient(paymentData, countryRuleResponse);
        }
        return paymentMode;
    }


    public void updateCreditorAccountIsIban(PaymentProcessingData paymentData,
                                            CountryRuleResponse countryRuleResponse) {
        String wireOrGAch = getWireOrGach(paymentData.getPaymentType());
        if (StringUtils.hasLength(wireOrGAch)) {
            AccountData creditAccountData = Optional.of(paymentData).map(PaymentProcessingData::getCreditAccountData).orElse(new AccountData());
            String isIban = creditAccountData.getIsIban().toString();
            String paymentType = paymentData.getPaymentType();
            String paymentId = paymentData.getTxRefNum();
            String creditAccountNum = creditAccountData.getAccNum();
            log.info("IsIban: {} for transaction type {} with paymentId: {}", isIban, paymentType, paymentId);
            if (!StringUtils.hasLength(isIban)) {
                String transactionCcy = paymentData.getTransactionCcy();
                String creditorBankRoutingType = getCreditorBankRoutingType(paymentData);
                isIban = verifyAndGetIfCreditorAccountIsIban(transactionCcy, creditorBankRoutingType, creditAccountNum, countryRuleResponse, wireOrGAch, paymentId);
                paymentData.getCreditAccountData().setIsIban(IsIban.valueOf(isIban));
                log.info("Updated IsIban:{} for transaction type:{} with paymentId:{} from rule engine response", paymentData.getCreditAccountData().getIsIban(), paymentType, paymentId);
            } else if (IS_IBAN_YES.equalsIgnoreCase(isIban)) {
                isIban = validatedCreditorAccAgainstSpmPattern(creditAccountNum, paymentId);
                paymentData.getCreditAccountData().setIsIban(IsIban.valueOf(isIban));
                log.info("Updated IsIban: {} for transaction type {} with paymentId: {}", paymentData.getCreditAccountData().getIsIban(), paymentType, paymentId);
            }
        }
    }

    private void setWireType(PaymentProcessingData paymentData) {
        paymentData.setWireType(WireType.USD);

        if (PaymentUtil.isMCAPayment(paymentData.getPaymentType())) {
            paymentData.setWireType(WireType.MCA);
        }

        if (PaymentUtil.isICAPayment(paymentData.getPaymentType())) {
            paymentData.setWireType(WireType.FCA);
        }
    }

    private void updateCreditorBankData(PaymentProcessingData paymentData) {
        Optional<Address> creditorAddress = Optional.ofNullable(paymentData)
                .map(PaymentProcessingData::getCreditorBankData)
                .map(BankData::getAddress);

        String recipientBankAddress1 = creditorAddress
                .map(Address::getAddLine1).orElse(EMPTY);

        String recipientBankAddress2 = creditorAddress
                .map(Address::getAddLine2).orElse(EMPTY);

        String recipientBankAddress3 = creditorAddress
                .map(Address::getAddLine3).orElse(EMPTY);


        String recipientBankName = Optional.ofNullable(paymentData)
                .map(PaymentProcessingData::getCreditorBankData)
                .map(BankData::getBankName)
                .orElse(EMPTY);

        // Update Recipient BankName and Bank Location to trim to 35 chars as per MT103 standards
        if (paymentData != null && paymentData.getCreditorBankData() != null) {
            if (StringUtils.hasLength(recipientBankAddress1)) {
                paymentData.getCreditorBankData().getAddress().setAddLine1(PaymentUtil.formatLengthToSupportSwiftStandard(recipientBankAddress1));
            }

            if (StringUtils.hasLength(recipientBankAddress2)) {
                paymentData.getCreditorBankData().getAddress().setAddLine2(PaymentUtil.formatLengthToSupportSwiftStandard(recipientBankAddress2));
            }

            if (StringUtils.hasLength(recipientBankAddress3)) {
                paymentData.getCreditorBankData().getAddress().setAddLine3(PaymentUtil.formatLengthToSupportSwiftStandard(recipientBankAddress3));
            }

            if (StringUtils.hasLength(recipientBankName)) {
                paymentData.getCreditorBankData().setBankName(PaymentUtil.formatLengthToSupportSwiftStandard(recipientBankName));
            }
        }
    }

    private void updateIntermediaryBankData(PaymentProcessingData paymentData) {
        Optional<Address> intermediaryAddress = Optional.ofNullable(paymentData)
                .map(PaymentProcessingData::getIntermediaryBankData)
                .map(IntermediaryBankData::getAddress);

        String intermediaryBankAddress1 = intermediaryAddress
                .map(Address::getAddLine1).orElse(EMPTY);

        String intermediaryBankAddress2 = intermediaryAddress
                .map(Address::getAddLine2).orElse(EMPTY);

        String intermediaryBankAddress3 = intermediaryAddress
                .map(Address::getAddLine3).orElse(EMPTY);

        String intermediaryBankName = Optional.ofNullable(paymentData)
                .map(PaymentProcessingData::getIntermediaryBankData)
                .map(IntermediaryBankData::getBankName)
                .orElse(EMPTY);


        if (paymentData != null && paymentData.getIntermediaryBankData() != null) {
            // Update Intermediary BankName and Bank Location to trim to 35 chars as per MT103 standards
            if (StringUtils.hasLength(intermediaryBankAddress1)) {
                paymentData.getIntermediaryBankData().getAddress().setAddLine1(PaymentUtil.formatLengthToSupportSwiftStandard(intermediaryBankAddress1));
            }

            if (StringUtils.hasLength(intermediaryBankAddress2)) {
                paymentData.getIntermediaryBankData().getAddress().setAddLine2(PaymentUtil.formatLengthToSupportSwiftStandard(intermediaryBankAddress2));
            }

            if (StringUtils.hasLength(intermediaryBankAddress3)) {
                paymentData.getIntermediaryBankData().getAddress().setAddLine3(PaymentUtil.formatLengthToSupportSwiftStandard(intermediaryBankAddress3));
            }

            if (StringUtils.hasLength(intermediaryBankName)) {
                paymentData.getIntermediaryBankData().setBankName(PaymentUtil.formatLengthToSupportSwiftStandard(intermediaryBankName));
            }
        }

    }

    private String verifyAndGetIfCreditorAccountIsIban(String transactionCcy, String creditorBankRoutingType, String creditAccountNum,
                                                       CountryRuleResponse countryRuleResponse, String wireOrGAch, String paymentId) {
        if (StringUtils.hasLength(creditorBankRoutingType)
                && (PAYMENT_ROUTING_TYPE_SWIFT.equals(creditorBankRoutingType) ||
                PAYMENT_ROUTING_TYPE_BIC.equals(creditorBankRoutingType))
                && PaymentUtil.areFirstNCharsAlphabet(creditAccountNum, 2)) {
            BeneficiaryAccount beneficiaryAccount = getBeneficiaryAccountByWireOrGAch(countryRuleResponse, transactionCcy, wireOrGAch);
            if (beneficiaryAccount != null) {
                RuleEngineIban countrySpecificIban = beneficiaryAccount.getIban();
                String ibanISOCountryCode = countrySpecificIban.getIbanISOCountryCode();
                if (PaymentUtil.areFirstNCharsEqual(creditAccountNum, ibanISOCountryCode, 2)) {
                    log.info("Creditor account first 2 chars matches with ibanISOCountryCode");
                    return validatedCreditorAccAgainstSpmPattern(creditAccountNum, paymentId);
                }
            }
        }
        return IS_IBAN_NO;
    }

    private String getWireOrGach(String paymentType) {
        return WIRE_TXNS_IBAN_DETERMINATION.contains(paymentType) ? WIRE : GACH_TXNS_IBAN_DETERMINATION.contains(paymentType) ? GACH : "";
    }

    private String getCreditorBankRoutingType(PaymentProcessingData paymentData) {
        return Optional.ofNullable(paymentData)
                .map(PaymentProcessingData::getCreditorBankData)
                .map(BankData::getRoutingType)
                .orElse(EMPTY);
    }

    private BeneficiaryAccount getBeneficiaryAccountByWireOrGAch(CountryRuleResponse countryRuleResponse,
                                                                 String transactionCcy,
                                                                 String wireOrGAch) {
        //Get beneficiaryAccount object from payment rules API response
        BeneficiaryAccount beneficiaryAccount = null;
        RuleData data = getDataFromRuleEngineAPIResponse(countryRuleResponse);
        if (WIRE.equals(wireOrGAch))
            beneficiaryAccount = data.getBeneficiaryAccount();
        if (GACH.equals(wireOrGAch)) {
            String isGAchAllowed = getIsGAchAllowed(countryRuleResponse);
            if (GACH_ALLOWED_YES.equalsIgnoreCase(isGAchAllowed)) {
                beneficiaryAccount = getBenAccMatchedWithTxnCcy(transactionCcy, data);
            }
        }
        return beneficiaryAccount;
    }

    private BeneficiaryAccount getBenAccMatchedWithTxnCcy(String transactionCcy, RuleData data) {
        Optional<GACHInfo> gAchInfo = data.getGACHInfo().stream().filter(e -> e.getCurrency().equalsIgnoreCase(transactionCcy)).findFirst();
        return gAchInfo.map(GACHInfo::getBeneficiaryAccount).orElse(null);
    }

    private RuleData getDataFromRuleEngineAPIResponse(CountryRuleResponse countryRuleResponse) {
        return Optional.ofNullable(countryRuleResponse)
                .map(CountryRuleResponse::getData).orElse(new RuleData());
    }

    private String getIsGAchAllowed(CountryRuleResponse countryRuleResponse) {
        return Optional.ofNullable(countryRuleResponse)
                .map(CountryRuleResponse::getData)
                .map(RuleData::getGACHAllowed)
                .orElse(EMPTY);
    }

    private String validatedCreditorAccAgainstSpmPattern(String creditAccountNum, String paymentId) {
        boolean isPatternMatched = PaymentUtil.matchesPattern(creditAccountNum, CREDITOR_ACC_PATTERN);
        log.info("Is creditor account num matches against the spm required pattern: {} for the paymentId: {}", isPatternMatched, paymentId);
        return isPatternMatched ? IS_IBAN_YES : IS_IBAN_NO;
    }

    private void processGFBClient(PaymentProcessingData paymentData, CountryRuleResponse countryRuleResponse) {
        BiPredicate<String, String> checkGfbClient = (teamCode, paymentType) -> (USI_TRANSACTION_TYPE.equals(paymentType)
                && staticDetailsService.retrieveTeamCode(teamCode) != null);

        String reasonForPayment = Optional.ofNullable(paymentData.getInstructions()).map(Instructions::getRemittanceInformation).orElse(EMPTY);
        if (checkGfbClient.test(paymentData.getAddPayDetails().getTeamCode(), paymentData.getPaymentType())) {
            String purposeOfPaymentRequired = countryRuleResponse.getData().getPurposeOfPaymentRequired();

            if (MANDATORY.equals(purposeOfPaymentRequired) || OPTIONAL.equals(purposeOfPaymentRequired)) {
                checkPurposeOfPaymentPositionWire(paymentData, countryRuleResponse);
            } else if (paymentData.getInstructions() != null) {
                paymentData.getInstructions().setRemittanceInformation(checkLengthAndAppendSuffix(reasonForPayment));
            }
        }
    }

    private void checkPurposeOfPaymentPositionWire(PaymentProcessingData paymentData, CountryRuleResponse countryRuleResponse) {
        Set<String> popPositionWireForRFP = new HashSet<>(List.of("70", "72", "77B"));
        String purposeOfPaymentPositionWire = countryRuleResponse.getData().getPurposeOfPaymentPositionWire();
        PurposeOfPayment purposeOfPayment = countryRuleResponse.getData().getPurposeOfPayment();
        String purposeOfPaymentInput = paymentData.getPurposeOfPayment();
        String reasonForPayment = Optional.ofNullable(paymentData.getInstructions()).map(Instructions::getRemittanceInformation).orElse(EMPTY);
        if (Objects.nonNull(purposeOfPayment)) {
            if (PURPOSE_OF_PAYMENT_TEXT.equals(purposeOfPayment.getFormat())) {
                if ("70".equals(purposeOfPaymentPositionWire)) {
                    paymentData.setPurposeOfPayment(checkLengthAndAppendSuffix(purposeOfPaymentInput));
                } else if (paymentData.getInstructions() != null) {
                    paymentData.getInstructions().setRemittanceInformation(checkLengthAndAppendSuffix(reasonForPayment));
                }
            } else if (paymentData.getInstructions() != null
                    && (PURPOSE_OF_PAYMENT_BOTH.equals(purposeOfPayment.getFormat()) || (PURPOSE_OF_PAYMENT_LOV.equals(purposeOfPayment.getFormat()) &&
                    popPositionWireForRFP.contains(purposeOfPaymentPositionWire)))) {
                paymentData.getInstructions().setRemittanceInformation(checkLengthAndAppendSuffix(reasonForPayment));
            }
        }
    }

    private String checkLengthAndAppendSuffix(String field) {
        if (StringUtils.hasLength(field) && field.length() > 135) {
            field = field.substring(0, 135);
        }
        return StringUtils.hasLength(field) ? field : EMPTY + FEE_WAIVER_CODE;
    }
}
