package com.svb.gateway.payments.payment.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.payments.common.client.ApigeeAuthTokenEnum;
import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.entity.ClientDetailEntity;
import com.svb.gateway.payments.common.enums.*;
import com.svb.gateway.payments.common.exception.CollectException;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.mapper.db.ClientDetailsDBMapper;
import com.svb.gateway.payments.common.model.Address;
import com.svb.gateway.payments.common.model.GatewayContext;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.mdm.MDMClient;
import com.svb.gateway.payments.common.model.payment.FXWPaymentProcessingData;
import com.svb.gateway.payments.common.model.payment.PaymentMode;
import com.svb.gateway.payments.common.model.payment.fxw.FXWPayments;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationEntryData;
import com.svb.gateway.payments.common.model.payment.processing.*;
import com.svb.gateway.payments.common.model.rulesengine.BeneficiaryAccount;
import com.svb.gateway.payments.common.model.rulesengine.CountryRuleResponse;
import com.svb.gateway.payments.common.model.rulesengine.GACHInfo;
import com.svb.gateway.payments.common.model.rulesengine.RuleData;
import com.svb.gateway.payments.common.model.staticdata.BankBranchDetail;
import com.svb.gateway.payments.common.properties.ApigeeProperties;
import com.svb.gateway.payments.common.properties.KafkaTopicProperties;
import com.svb.gateway.payments.common.properties.PaymentProperties;
import com.svb.gateway.payments.common.service.ApigeeTokenService;
import com.svb.gateway.payments.common.service.GenericRestClient;
import com.svb.gateway.payments.common.service.MDMService;
import com.svb.gateway.payments.common.service.StaticDetailsService;
import com.svb.gateway.payments.common.service.mail.EmailService;
import com.svb.gateway.payments.common.util.*;
import com.svb.gateway.payments.payment.entity.FXErrorInfoMappingEntity;
import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.mapper.PaymentMapperUtil;
import com.svb.gateway.payments.payment.mapper.db.CountryCodeToCurrencyDbMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.model.FXMapper;
import com.svb.gateway.payments.payment.model.fxservices.*;
import com.svb.gateway.payments.payment.service.retry.FxRetryComponent;
import com.svb.gateway.payments.payment.util.MetadataCache;
import com.svb.gateway.payments.payment.util.PaymentProcessingErrorUtil;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.function.Predicate;

import static com.svb.gateway.payments.common.util.PaymentConstant.*;


@Slf4j
@Service
public class FXService {
    private static final String EQUAL_TO = "=";
    private static final String CUSTOMER_ID = "customer_id";

    private final KafkaTemplate<String, Object> template;
    private final KafkaTopicProperties kafkaTopicProperties;
    private final PaymentProperties paymentProperties;
    private final ApigeeProperties apigeeProperties;

    private final MDMService mdmService;
    private final PaymentRulesService paymentRulesService;
    private final EmailService emailService;
    private final GenericRestClient genericRestClient;
    private final MetadataCache metadataCache;
    private final ApigeeTokenService apigeeTokenService;

    private final TransactionDBMapper transactionDBMapper;
    private final TransactionEntryDBMapper transactionEntryDBMapper;
    private final CountryCodeToCurrencyDbMapper countryCodeToCurrencyDbMapper;
    private final ObjectMapper objectMapper;
    private final PaymentProcessingErrorUtil paymentErrorUtil;
    private final StaticDetailsService staticDataService;
    private final ClientDetailsDBMapper clientDetailsDBMapper;
    private final PaymentInitValidationService paymentInitValidationService;
    private final FXMapper fxMapper;
    private final FxRetryComponent fxRetryComponent;
    private final PaymentStatusUtil paymentStatusUtil;
    private final DateUtil dateUtil;

    @Autowired
    public FXService(KafkaTemplate<String, Object> template,
                     KafkaTopicProperties kafkaTopicProperties,
                     PaymentProperties paymentProperties,
                     ApigeeProperties apigeeProperties,
                     MDMService mdmService,
                     PaymentRulesService paymentRulesService,
                     StaticDetailsService staticDataService,
                     EmailService emailService,
                     GenericRestClient genericRestClient,
                     MetadataCache metadataCache,
                     ApigeeTokenService apigeeTokenService,
                     TransactionDBMapper transactionDBMapper,
                     TransactionEntryDBMapper transactionEntryDBMapper,
                     CountryCodeToCurrencyDbMapper countryCodeToCurrencyDbMapper,
                     ObjectMapper objectMapper,
                     PaymentProcessingErrorUtil paymentErrorUtil,
                     ClientDetailsDBMapper clientDetailsDBMapper,
                     PaymentInitValidationService paymentInitValidationService,
                     FXMapper fxMapper,
                     FxRetryComponent fxRetryComponent,
                     PaymentStatusUtil paymentStatusUtil,
                     DateUtil dateUtil) {
        this.template = template;
        this.kafkaTopicProperties = kafkaTopicProperties;
        this.paymentProperties = paymentProperties;
        this.apigeeProperties = apigeeProperties;
        this.mdmService = mdmService;
        this.paymentRulesService = paymentRulesService;
        this.emailService = emailService;
        this.genericRestClient = genericRestClient;
        this.metadataCache = metadataCache;
        this.apigeeTokenService = apigeeTokenService;
        this.countryCodeToCurrencyDbMapper = countryCodeToCurrencyDbMapper;
        this.transactionDBMapper = transactionDBMapper;
        this.transactionEntryDBMapper = transactionEntryDBMapper;
        this.objectMapper = objectMapper;
        this.paymentErrorUtil = paymentErrorUtil;
        this.staticDataService = staticDataService;
        this.clientDetailsDBMapper = clientDetailsDBMapper;
        this.paymentInitValidationService = paymentInitValidationService;
        this.fxMapper = fxMapper;
        this.fxRetryComponent = fxRetryComponent;
        this.paymentStatusUtil = paymentStatusUtil;
        this.dateUtil = dateUtil;
    }

    public void processFXWPayment(FXWPaymentProcessingData fxwPaymentData, PaymentTransactionStatusEntity statusEntity) {
        try {
            log.info("Entered processFXWPayment method");
            String txRefNum = fxwPaymentData.getPaymentData().getTxRefNum();
            log.info("Processing FXW Payment for txRefNum:{}", txRefNum);

            String contractReference = fxwPaymentData.getPaymentData().getCrossCurrencyPaymentData().getFxContractId();
            log.info("ContractReferenceId:{}", contractReference);
            // GWP5-362- If fxContractId is already available and quoteConfirmationId is null/empty, treat the payment as deal based payment
            // Thus skipping call to WSS
            if (!StringUtils.hasLength(contractReference)) {
                contractReference = getContractReference(fxwPaymentData.getPaymentData(), statusEntity);
            } else if (!"SDMC".equalsIgnoreCase(statusEntity.getPaymentCategory())) {
                //Else update isDealPayment in db
                statusEntity.setIsDealPayment(DEAL_PAYMENT);
                transactionEntryDBMapper.updateTxnEntryIsDealPayment(statusEntity.getTransactionId());
            }
            if (StringUtils.hasLength(contractReference)) {
                // The contract reference field must be updated to the "CONTRACT_ID" column on to the payment record inserted into the "PAYMENT_PROCESSING_STATUS_INFO" table
                log.info("Updating FXW contractReference:{} for txRefNum:{}", contractReference, txRefNum);
                statusEntity.setContractId(contractReference);
                // * The payment payload must be enriched by placing the contract_id value within the "contractId" tag in the payload.
                fxwPaymentData.getPaymentData().getCrossCurrencyPaymentData().setFxContractId(contractReference);
                populateAndUpdateRequiredData(fxwPaymentData.getPaymentData());
                // This logic is specifically for retrying FX splits as independent payment
                if ("SDMC".equalsIgnoreCase(statusEntity.getPaymentCategory())) {
                    fxwPaymentData.getPaymentData().setTxRefNum(String.format("%s%s%s", fxwPaymentData.getPaymentData().getTxRefNum(),
                            CommonConstant.SP,
                            fxwPaymentData.getPaymentData().getRequestSerialNo()));
                }
                // removing requestSerialNo before submitting to fx system.
                fxwPaymentData.getPaymentData().setRequestSerialNo(null);
                //The enriched payload must then be posted to the following kafka:
                String requestPayload = objectMapper.writeValueAsString(fxwPaymentData);
                log.debug("FXW posting to Kafka : FXW Request Payload :{}", requestPayload);
                this.postFXWPayment(requestPayload);
                log.info("Posted Payment to FXW Transfer Posting Topic for txn ref {}", txRefNum);
                // Update the contract id & status
                paymentStatusUtil.setE2ERefNo(statusEntity);
                // sync up the contract details to GW_TRANSACTION table for FX non split payment
                statusEntity.setDownstreamStatus(DownstreamStatusEnum.IN_PROCESS.toString());
                transactionDBMapper.updateTransactionStatus(statusEntity);
            }
            log.info("Payment messages has be updated for txn_ref:{}", txRefNum);
        } catch (Exception ex) {
            log.error("Unexpected error while consuming FX Message::", ex);
            paymentErrorUtil.handlerConsumerError(Long.parseLong(fxwPaymentData.getPaymentData().getTxRefNum()),
                    PaymentTypeEnum.FXW.toString(),
                    "Unexpected error while consuming FX Message", ex);
        }
    }

    public void processFXWSplitPayments(FXWPayments fxwPayments,
                                        List<PaymentTransactionStatusEntity> splitEntityList) throws PaymentServiceException {
        log.info("Entered process FXW split payments method");
        // Updating all split payment down stream status as Initiated
        PaymentProcessingData parentProcessingData = fxwPayments.getPaymentData().getFirst();
        PaymentTransactionStatusEntity parentStatusEntity = splitEntityList.getFirst();
        try {
            Long parentTransactionId = parentStatusEntity.getTransactionId();
            log.info("Processing FXW Split Payment for parent transaction_id:{}", parentTransactionId);
            // Fetch one of the child payment from split payments and process to fetch contractReference
            String contractReference = parentProcessingData.getCrossCurrencyPaymentData().getFxContractId();
            log.info("Fx split ContractReferenceId is {}", contractReference);
            // GWP5-362- If fxContractId is already available and quoteConfirmationId is null/empty, treat the payment as deal based payment
            // Thus skipping call to WSS
            if (!StringUtils.hasLength(contractReference)) {
                contractReference = processAndGetContractReference(parentProcessingData);
            } else {
                //Else update parentEntity's 'isDealPayment' in db
                parentStatusEntity.setIsDealPayment(DEAL_PAYMENT);
                transactionEntryDBMapper.updateTxnEntryIsDealPayment(parentStatusEntity.getTransactionId());
            }
            // Get Split eligible flag
            boolean isSplitAllowed = getSplitEligibleFlag(parentStatusEntity.getClientId(), contractReference);
            if (!StringUtils.hasLength(contractReference) || !isSplitAllowed) {
                // Failed to retrieve the fx contract_id or isSplitAllowed is false,  mark as FX_CONTRACT_RETRY (to be picked up by the batch job)
                parentStatusEntity.setDownstreamStatus(DownstreamStatusEnum.FX_CONTRACT_RETRY.toString());
                log.info("{}, mark record for:{} for transactionId:{}", getLogMsg(contractReference), DownstreamStatusEnum.FX_CONTRACT_RETRY, parentTransactionId);
                paymentStatusUtil.updateEntireStatus(parentStatusEntity, true);
            } else {
                // The contract reference field must be updated to the "CONTRACT_ID" on table "GW_TRANSACTION_ENTRY"
                log.info("Updating FXW Splits contractReference:{} for transaction_id:{}", contractReference, parentTransactionId);
                parentStatusEntity.setContractId(contractReference);
                for (PaymentProcessingData paymentData : fxwPayments.getPaymentData()) {
                    log.info("Processing FX split Payment for:{}", paymentData.getTxRefNum());
                    // * The payment payload must be enriched by placing the contract_id value within the "contractId" tag in the payload.
                    paymentData.getCrossCurrencyPaymentData().setFxContractId(contractReference);
                    populateAndUpdateRequiredData(paymentData);
                    // Updating the transaction_id as "1234SP1" to match existing fx split payment processing to downstream system.
                    paymentData.setTxRefNum(String.format("%s%s%s", paymentData.getTxRefNum(), CommonConstant.SP, paymentData.getRequestSerialNo()));
                }
                this.postFXWPayment(fxwPayments);
                log.info("Posted Payment to FXW Transfer Posting Topic for split payment parent transaction_id:{}", parentTransactionId);
                // Sync contract details to GW_Transaction table for FX split payment
                transactionDBMapper.updateTransactionStatus(parentStatusEntity);
                // Update the first instance in transaction Entry with updated details
                // TODO Might not need to store CONTRACT_ID and DEAL_NUMBER in transaction_entry table for sequence 1
                // transactionEntryDBMapper.updateTransactionEntryStatus(parentStatusEntity);
                // Updating all the split payment downstream status to IN_PROCESS
                PaymentTransactionStatusEntity splitEntityUpdate = PaymentTransactionStatusEntity.builder()
                        .downstreamStatus(DownstreamStatusEnum.IN_PROCESS.toString())
                        .transactionId(parentTransactionId).build();
                transactionEntryDBMapper.updateTransactionEntryStatus(splitEntityUpdate);
            }
        } catch (Exception ex) {
            log.error("Unexpected error while consuming FX Message", ex);
            paymentErrorUtil.handlerConsumerError(
                    parentStatusEntity.getTransactionId(),
                    parentStatusEntity.getPaymentType(),
                    "Unexpected error while consuming FX Split payment Message", ex);
            throw new PaymentServiceException(ErrorCodeEnum.FX_RUNTIME_SERVICE_ERROR, ex);
        }
    }

    private Boolean getSplitEligibleFlag(String clientId, String contractId) {
        Boolean splitEligibleFlag = false;
        if (StringUtils.hasLength(contractId)) {
            ResponseEntity<ApiResponseContainer<FXRetrieveContractsResponse, FXRetrieveContractsErrorResponse>> responseEntity = fxRetrieveContractByContractId(clientId, contractId);
            if (responseEntity != null && responseEntity.getStatusCode().value() == HttpStatus.OK.value()) {
                ApiResponseContainer<FXRetrieveContractsResponse, FXRetrieveContractsErrorResponse> resBody = responseEntity.getBody();
                if (resBody != null && resBody.getData() != null) {
                    splitEligibleFlag = resBody.getData().getContracts().getFirst().getSplitEligibleFlag();
                    log.info("Received SplitEligibleFlag:{} for the contractId:{}", splitEligibleFlag, contractId);
                }
            }
        }
        return splitEligibleFlag;
    }

    private static String getLogMsg(String contractReference) {
        return !StringUtils.hasLength(contractReference) ? "Failed to retrieve the FX Contract Id" : "Received split eligibility flag as false for the contractId: " + contractReference;
    }

    public ResponseEntity<ApiResponseContainer<FXRetrieveContractsResponse, FXRetrieveContractsErrorResponse>> fxRetrieveContractByContractId(String customerId, String contractId) {
        String queryParams = CUSTOMER_ID + EQUAL_TO + customerId + "&contract_id=" + contractId;
        String logForId = "contractId " + contractId;
        return fxRetrieveContracts(queryParams, logForId);
    }

    public FXRetrieveContractsResponse getFXRetrieveContractsResponseByDealLinkId(String clientId, String contractId, String debitType, Long paymentId) {
        FXRetrieveContractsResponse fxRetrieveContractsResponse = null;
        var responseEntity = fxRetrieveContractsByDealLinkId(clientId, contractId, debitType);
        if (responseEntity != null && responseEntity.getStatusCode().value() == HttpStatus.OK.value()) {
            var resBody = responseEntity.getBody();
            if (resBody != null) {
                fxRetrieveContractsResponse = resBody.getData();
                fxRetrieveContractsResponse.getContracts().forEach(contractResponse ->
                        log.info("Received FXRetrieveContractsResponse for the DealLinkId {}, Transaction Id {} and debitType {} => cif = {} contractIdentifier = {}, contractStatus = {}, dealNumber = {}",
                                contractId, paymentId, debitType, contractResponse.getCif(), contractResponse.getContractIdentifier(),
                                contractResponse.getContractStatus(), contractResponse.getDealNumber()));
            }
        }
        return fxRetrieveContractsResponse;
    }

    public FXRetrieveContractsResponse getFXRetrieveContractsResponse(String clientId, String contractId, Long paymentId) {
        FXRetrieveContractsResponse fxRetrieveContractsResponse = null;
        var responseEntity = fxRetrieveContractByContractId(clientId, contractId);
        if (responseEntity != null && responseEntity.getStatusCode().value() == HttpStatus.OK.value()) {
            var resBody = responseEntity.getBody();
            if (resBody != null && resBody.getData() != null) {
                fxRetrieveContractsResponse = resBody.getData();
                fxRetrieveContractsResponse.getContracts().forEach(contractResponse ->
                        log.info("Received FXRetrieveContractsResponse for the contractId {} and paymentId {} => cif = {} " +
                                        "contractIdentifier = {}, contractStatus = {}, dealNumber = {}",
                                contractId, paymentId, contractResponse.getCif(), contractResponse.getContractIdentifier(),
                                contractResponse.getContractStatus(), contractResponse.getDealNumber()));

            }
        }
        return fxRetrieveContractsResponse;
    }

    public ResponseEntity<ApiResponseContainer<FXRetrieveContractsResponse, FXRetrieveContractsErrorResponse>>
    fxRetrieveContractsByDealLinkId(String customerId, String contractId, String debitType) {
        return fxRetrieveContracts(String.format("customer_id=%s&deal_link_id=%s&debit_type=%s", customerId, contractId, debitType),
                "dealLinkId " + contractId + " and debitType " + debitType);
    }

    private ResponseEntity<ApiResponseContainer<FXRetrieveContractsResponse, FXRetrieveContractsErrorResponse>> fxRetrieveContracts(String queryParams, String logForId) {
        FXRetrieveContractsResponse fxRetrieveContractsResponse = null;
        FXRetrieveContractsErrorResponse error = null;
        int statusCode = HttpStatus.OK.value();

        String apiUrl = apigeeProperties.getUrl().concat("/v1/fx/contracts" + "?" + queryParams);
        try {
            Map<String, String> headerMap = new HashMap<>();
            headerMap.put(HttpHeaders.AUTHORIZATION, PaymentConstant.BEARER + " " +
                    apigeeTokenService.getApigeeAuthToken(ApigeeAuthTokenEnum.FX_CLIENT));

            HttpResponseContainer<FXRetrieveContractsResponse> response = genericRestClient.get(apiUrl,
                    null,
                    FXRetrieveContractsResponse.class,
                    Duration.ofSeconds(60L),
                    headerMap,
                    false);

            if (HttpStatus.OK.value() == response.getStatusCode().value()) {
                fxRetrieveContractsResponse = response.getSuccessResponse();
                log.info("FX Contracts response from WSS is parsed successfully for {} and received contracts size is:{}", logForId, fxRetrieveContractsResponse.getContracts().size());
                fxRetrieveContractsResponse.getContracts().forEach(c -> c.setCif(PaymentUtil.cifStripLeftPadding(c.getCif())));
            } else {
                log.info("FX Retrieve Contracts Error Response for {} with status code {} is :: {}", logForId, response.getStatusCode(), response.getErrorResponse());
                log.info("FX Contracts error response from WSS is parsed successfully:{}", response.getErrorDescription());
            }
        } catch (Exception e) {
            log.error("Error while fetching contracts for {} Error :: {}", logForId, e.getLocalizedMessage());
            error = FXRetrieveContractsErrorResponse.builder().name(PaymentUtil.INTERNAL_SERVER_ERROR).id("-1")
                    .time(LocalDateTime.now().toString()).message("Internal technical issue").build();
            statusCode = HttpStatus.INTERNAL_SERVER_ERROR.value();
        }
        return ResponseEntity.status(statusCode).body(new ApiResponseContainer<>(fxRetrieveContractsResponse, error));
    }

    private String getContractReference(PaymentProcessingData paymentData, PaymentTransactionStatusEntity statusEntity) throws Exception {
        String fxContractId = CommonConstant.EMPTY;
        String quoteConfirmationId = paymentData.getCrossCurrencyPaymentData().getQuoteConfirmationId();

        if (!StringUtils.hasLength(quoteConfirmationId) && StringUtils.hasLength(paymentData.getFileId()) && Long.parseLong(paymentData.getFileId()) > 0L) {
            quoteConfirmationId = bookDealForImportPayment(paymentData, statusEntity);
        }
        if (StringUtils.hasLength(quoteConfirmationId)) {
            fxContractId = processAndGetContractReference(paymentData);
            if (!StringUtils.hasLength(fxContractId)) {
                log.info("Failed to retrieve the FX Contract Id, mark record for {} for txn Reference {} ",
                        DownstreamStatusEnum.FX_CONTRACT_RETRY, paymentData.getTxRefNum());
                statusEntity.setDownstreamStatus(DownstreamStatusEnum.FX_CONTRACT_RETRY.toString());
                transactionEntryDBMapper.updateTransactionEntryStatus(statusEntity);
            }
        }
        return fxContractId;
    }

    private String processAndGetContractReference(PaymentProcessingData paymentData) {
        String quoteConfirmationId = paymentData.getCrossCurrencyPaymentData().getQuoteConfirmationId();
        log.info("quoteConfirmationId is {}", quoteConfirmationId);
        // A JSON payload must be built to invoke the FX trading API.
        FXStatusRequest fxStatusRequest = FXStatusRequest.builder()
                .requestId(UUID.randomUUID().toString())
                .sourceSystem(paymentProperties.getFxSourceSystem())
                .transactionId(quoteConfirmationId).build();
        //Service must then invoke the following fx trading API with the above payload :
        //the "contractReference" field from the response payload must be parsed
        return getContractReference(fxStatusRequest);
    }

    private String getContractReference(FXStatusRequest fxStatusRequest) {
        String contractReference = CommonConstant.EMPTY;
        try {
            contractReference = fxRetryComponent.contractReference(fxStatusRequest);
        } catch (PaymentServiceException e) {
            log.error("Caught Exception while retrieving the contract status", e);
        }
        return contractReference;
    }

    private void populateAndUpdateRequiredData(PaymentProcessingData paymentData) throws JsonProcessingException {

        Optional.of(paymentData)
                .map(PaymentProcessingData::getCreditAccountData)
                .map(AccountData::getAccNum)
                .map(PaymentUtil::sanitizeString)
                .map(PaymentUtil::convertToUpperCase)
                .ifPresentOrElse(creditAccountNUm -> paymentData.getCreditAccountData().setAccNum(creditAccountNUm), () -> paymentData.getCreditAccountData().setAccNum(CommonConstant.EMPTY));


        // populate the payload with debtor data.
        String debtorCif = PaymentUtil.getCif(paymentData);
        log.info("Populating debtor information : TransactionRefNo:{} ", paymentData.getTxRefNum());
        Data debtorData = null;
        try {
            MDMClient mdmRes = mdmService.fetchCifAddressInformationFromMDM(debtorCif);
            if (mdmRes != null) {
                debtorData = PaymentMapperUtil.constructAccountDetails(mdmRes, paymentData.getDebtorData(), PaymentMapperUtil.getTxRefNum(paymentData));
            }
        } catch (PaymentServiceException e) {
            ClientDetailEntity clientDetailEntity = clientDetailsDBMapper.getClientDetails(debtorCif);
            debtorData = PaymentMapperUtil.constructDebtorData(paymentData, clientDetailEntity);
            log.atError().setMessage("Skipping the mdmService exception for cif {}").addArgument(debtorCif).setCause(e).log();
        } finally {
            paymentData.setDebtorData(debtorData);
        }

        String creditorBankCountryCode = PaymentMapperUtil.getCreditorBankCountryCode(paymentData);
        log.info("Call to Rule engine and populating paymentMode TransactionRefNo: {} ", paymentData.getTxRefNum());

        // Call payment rule engine api
        CountryRuleResponse countrySpecificFields = staticDataService.fetchCountrySpecificRules(null, CountryEnum.valueOf(creditorBankCountryCode));
        log.debug("Received response from payment rules API - {}", objectMapper.writeValueAsString(countrySpecificFields));

        if (!paymentData.getPaymentType().equals(PaymentTypeEnum.CCT.toString())) {
            // Service must then invoke Payment Rules Engine and populate the purposeOfPaymentPrefix and purposeOfPaymentPosition.
            PaymentMode paymentMode = new PaymentMode();
            getPaymentModeAndUpdateFXWPayment(paymentData, countrySpecificFields, paymentMode);
        }
        paymentInitValidationService.updateCreditorAccountIsIban(paymentData, countrySpecificFields);
        // Populating Debtor Details for FX Transfer payment types from MDM
        paymentInitValidationService.updateCreditorData(paymentData, debtorData, debtorCif);
        updateCreditorBankData(paymentData);
        PaymentMapperUtil.updateBankInfoToSwift(paymentData);
        updateFXStpDetails(paymentData, countrySpecificFields);
        updateFieldInstructionCode23E(paymentData);
        PaymentUtil.updateOboDetails(paymentData);
    }

    private String bookDealForImportPayment(PaymentProcessingData paymentData, PaymentTransactionStatusEntity statusEntity) throws Exception {
        FXExecuteResponse fxExecuteResponse = fxTradeExecuteCall(paymentData);
        if (fxExecuteResponse != null) {
            if (FX_API_BOOKING_STATUS_SUCCESS.equals(fxExecuteResponse.getStatus())) {
                //updating crossCurrencyData for using it next fx api call
                //resetting no of retry column as this is used by FX_CONTRACT_RETRY job also
                CrossCurrencyPaymentData crossCurrencyPaymentData = paymentData.getCrossCurrencyPaymentData();
                crossCurrencyPaymentData.setCurrencyPair(fxExecuteResponse.getCurrencyPair());
                crossCurrencyPaymentData.setTradeDate(fxExecuteResponse.getTradeDate());
                crossCurrencyPaymentData.setValueDate(fxExecuteResponse.getValueDate());
                crossCurrencyPaymentData.setFxRate(new BigDecimal(fxExecuteResponse.getRate()));
                crossCurrencyPaymentData.setQuoteConfirmationId(fxExecuteResponse.getTransactionId());
                statusEntity.setDownstreamStatus(DownstreamStatusEnum.INITIATED.toString());
                statusEntity.setNoOfRetries(0);
                transactionEntryDBMapper.updateTransactionEntryStatus(statusEntity);
            } else {
                handleFXExecuteFailure(fxExecuteResponse, statusEntity);
            }
        }
        return paymentData.getCrossCurrencyPaymentData().getQuoteConfirmationId();
    }

    private void getPaymentModeAndUpdateFXWPayment(PaymentProcessingData paymentData, CountryRuleResponse countrySpecificFields, PaymentMode paymentMode) {
        String creditorBankCountryCode = PaymentMapperUtil.getCreditorBankCountryCode(paymentData);
        String transactionCcy = paymentData.getTransactionCcy();
        String paymentType = paymentData.getPaymentType();

        if (StringUtils.hasLength(creditorBankCountryCode)
                && StringUtils.hasLength(paymentType)
                && StringUtils.hasLength(transactionCcy)) {

            //Get the paymentMode
            paymentMode = paymentRulesService.getCountryRule(countrySpecificFields, paymentType, transactionCcy, paymentMode);

            if (COUNTRY_CANADA.equalsIgnoreCase(creditorBankCountryCode) &&
                    PAYMENT_METHOD_FX_PAYMENTS.contains(paymentData.getPaymentType())
                    && StringUtils.hasLength(transactionCcy) && transactionCcy.equalsIgnoreCase(CURRENCY_CAD)) {
                paymentData.getCreditorBankData().getLocalRoutingInformation().setRoutingType(paymentMode.getLocalRoutingInformationType());
            }
            // the local routing information is null if the request is from batch
            if (paymentData.getCreditorBankData().getLocalRoutingInformation() == null) {
                paymentData.getCreditorBankData().setLocalRoutingInformation(new LocalRoutingInformation());
            }
            paymentData.getCreditorBankData().getLocalRoutingInformation().setPrefix(paymentMode.getLocalRoutingInformationPrefix());
            paymentData.setPurposeOfPaymentPrefix(paymentMode.getPurposeOfPaymentPrefix());
            paymentData.setPurposeOfPaymentPosition(paymentMode.getPurposeOfPaymentPosition());
            if ((paymentData.getPurposeOfPayment() != null) && (!paymentData.getPurposeOfPayment().isEmpty())) {
                paymentData.setPurposeOfPayment(Optional.ofNullable(paymentMode.getPurposeOfPaymentPrefixCode()).orElse("") + paymentData.getPurposeOfPayment());
            }
        }
    }

    private void updateCreditorBankData(PaymentProcessingData paymentData) {
        Predicate<BankData> lengthCheck = c -> StringUtils.hasLength(c.getRoutingCode()) && c.getRoutingCode().length() > 2;
        Predicate<BankData> creditorBankRoutingCodeCountryUS = c -> StringUtils.hasLength(c.getRoutingCode()) && c.getRoutingCode().length() > 5 && (COUNTRY_US).equalsIgnoreCase(c.getRoutingCode().substring(4, 6));

        String creditorBankCountryCode = Optional.ofNullable(paymentData)
                .map(PaymentProcessingData::getCreditorBankData)
                .map(BankData::getAddress)
                .map(Address::getCountry)
                .orElse(null);

        BankData creditorBankData = Optional.ofNullable(paymentData)
                .map(PaymentProcessingData::getCreditorBankData)
                .orElse(new BankData());

        LocalRoutingInformation localRoutingInformation = Optional.of(creditorBankData)
                .map(BankData::getLocalRoutingInformation)
                .orElse(null);

        // if creditor bank routing code country is US then skip enrichment on routing information
        if (COUNTRY_US.equalsIgnoreCase(creditorBankCountryCode) && !creditorBankRoutingCodeCountryUS.test(creditorBankData) && localRoutingInformation != null) {

            localRoutingInformation.setRoutingType("ABA");
            localRoutingInformation.setPrefix("//FW");
            localRoutingInformation.setRoutingCode(lengthCheck.test(creditorBankData) ? creditorBankData.getRoutingCode().substring(0, creditorBankData.getRoutingCode().length() - 2) : "");
            creditorBankData.setRoutingCode("");
            creditorBankData.setRoutingType("");
        }
    }

    private void updateFXStpDetails(PaymentProcessingData paymentData, CountryRuleResponse countrySpecificFields) throws JsonProcessingException {
        var paymentType = paymentData.getPaymentType();
        // FX Transfers always true
        if (PAYMENT_METHOD_FX_TRANSFERS.contains(paymentType)) {
            paymentData.setFxStpFlag(true);
            return;
        }
        // Non-FX Payments do nothing
        if (!PAYMENT_METHOD_FX_PAYMENTS.contains(paymentType)) {
            return;
        }
        Set<String> allStpSupportedCurrencies = countryCodeToCurrencyDbMapper.getAllStpSupportedCurrencies();
        // If currency is not part of allStpSupportedCurrencies, always assign stp flag as false and fxStpDetails message list is null
        if (!allStpSupportedCurrencies.contains(paymentData.getTransactionCcy())) {
            paymentData.setFxStpFlag(false);
            return;
        }
        // Validate STP details
        List<String> fxStpDetails = new ArrayList<>();
        validateLocalRoutingCodeToAddFxStpDetails(paymentData, fxStpDetails);
        validateTransactionCurrencySupportedByIBBankCountry(paymentData, fxStpDetails, allStpSupportedCurrencies);
        validateCreditorAccountNumberFormat(paymentData, fxStpDetails, countrySpecificFields);
        paymentData.setFxStpDetails(fxStpDetails.isEmpty() ? null : fxStpDetails);
    }

    private void validateLocalRoutingCodeToAddFxStpDetails(PaymentProcessingData paymentData, List<String> fxStpDetails) {
        String creditorBankCountryCode = paymentData.getCreditorBankData().getAddress().getCountry();
        String transactionCcy = paymentData.getTransactionCcy();
        boolean isValidCanadaCurrencyCheck = StringUtils.hasLength(creditorBankCountryCode) && COUNTRY_CANADA.equalsIgnoreCase(creditorBankCountryCode)
                && StringUtils.hasLength(transactionCcy) && transactionCcy.equalsIgnoreCase(CURRENCY_CAD);
        if (isValidCanadaCurrencyCheck) {
            paymentData.setFxStpFlag(false);
            fxStpDetails.add("Local Routing code cannot be validated");
            // TODO should we enable
            //validateFxStpForCanada(paymentData, fxStpDetails, paymentData.getCreditorBankData());
        }
    }

    /*private void validateFxStpForCanada(PaymentProcessingData fxwPayment, List<String> fxStpDetails, BankData creditorBankData) {
        try {
            String creditorLocalRoutingType = Optional.of(creditorBankData)
                    .map(BankData::getLocalRoutingInformation)
                    .map(LocalRoutingInformation::getRoutingType)
                    .orElse(null);

            String creditorLocalRoutingCode = Optional.of(creditorBankData)
                    .map(BankData::getLocalRoutingInformation)
                    .map(LocalRoutingInformation::getRoutingCode)
                    .orElse(null);
            List<BankBranchDetail> bankBranchDetailList = staticDataService.retrieveBankBranches(null,
                    null,
                    true,
                    null,
                    null,
                    null,
                    null,
                    creditorLocalRoutingCode,
                    creditorLocalRoutingType,
                    null,
                    null,
                    null).getBankBranches();
            if (!CollectionUtils.isEmpty(bankBranchDetailList)) {
                String swiftBicPairing = bankBranchDetailList.getFirst().getSwiftbicPairing();
                String creditorBankDataRoutingCode = Optional.of(creditorBankData)
                        .map(BankData::getRoutingCode)
                        .orElse(null);
                if (StringUtils.hasLength(swiftBicPairing) &&
                        swiftBicPairing.length() > 5 &&
                        StringUtils.hasLength(creditorBankDataRoutingCode) &&
                        creditorBankDataRoutingCode.length() > 5 &&
                        swiftBicPairing.substring(0, 6).equalsIgnoreCase(creditorBankDataRoutingCode.substring(0, 6))) {
                    fxwPayment.setFxStpFlag(true);
                    fxStpDetails.clear();
                }
            }
        } catch (Exception ex) {
            log.error("Error while fx stp local routing code validation, validation failed: {}", ex.getMessage());
        }
    }*/

    private void validateTransactionCurrencySupportedByIBBankCountry(PaymentProcessingData paymentData, List<String> fxStpDetails, Set<String> allStpSupportedCurrencies) {
        Boolean fxStpFlag = paymentData.getFxStpFlag();

        if (paymentData.getIntermediaryBankData() == null || paymentData.getIntermediaryBankData().getRoutingCode() == null) {
            // Defaulting stpFlag to true if transaction currency belongs to STP supported currencies
            if (allStpSupportedCurrencies.contains(paymentData.getTransactionCcy())) {
                paymentData.setFxStpFlag(fxStpFlag != null ? fxStpFlag : true);
            }
            return;
        }
        log.info("Validating if transaction currency is supported by Intermediary bank country currency for {}", paymentData.getTxRefNum());

        String intermediatoryBankRoutingCode = paymentData.getIntermediaryBankData().getRoutingCode();
        String countryCode = intermediatoryBankRoutingCode.substring(4, 6);

        Set<String> supportedCurrencies = countryCodeToCurrencyDbMapper.getCurrencyListByCountryCode(countryCode);
        if (supportedCurrencies.contains(paymentData.getTransactionCcy())) {
            log.info("Intermediary bank details validated successful");
            // if fxStpFlag was set during CA country check then set it else true
            paymentData.setFxStpFlag(fxStpFlag != null ? fxStpFlag : true);
        } else {
            log.info("Intermediary bank details cannot be validated for {}", paymentData.getTxRefNum());
            fxStpDetails.add("Intermediary bank details cannot be validated");
            paymentData.setFxStpFlag(false);
        }
    }

    private void validateCreditorAccountNumberFormat(PaymentProcessingData paymentData, List<String> fxStpDetails, CountryRuleResponse countrySpecificFields) throws JsonProcessingException {
        log.info("Entered to Validate creditor account number format");
        Boolean fxStpFlag = paymentData.getFxStpFlag();

        String creditorBankCountryCode = PaymentMapperUtil.getCreditorBankCountryCode(paymentData);
        String transactionCcy = paymentData.getTransactionCcy();
        String paymentType = paymentData.getPaymentType();
        String creditorAccNum = paymentData.getCreditAccountData().getAccNum();

        //Get beneficiaryAccount object from payment rules API response
        BeneficiaryAccount beneficiaryAccount = getBeneficiaryAccount(countrySpecificFields, transactionCcy, paymentType);

        log.info("Beneficiary account from payment rules response:{}", objectMapper.writeValueAsString(beneficiaryAccount));
        log.info("CreditorBankCountryCode: {}, PaymentType: {}, TransactionCcy: {}, CreditorAccNum: {} from paymentData",
                creditorBankCountryCode, paymentType, transactionCcy, PaymentUtil.getMaskedAccountNumber(creditorAccNum));
        if (Objects.nonNull(beneficiaryAccount) && StringUtils.hasLength(creditorAccNum)) {
            creditorAccNum = creditorAccNum.replaceAll("\\s", "");
            //TODO should we enable
            //validateCreditorAccNum(paymentData, fxStpDetails, fxStpFlag, creditorAccNum, beneficiaryAccount);
        }
    }

    /*private void validateCreditorAccNum(PaymentProcessingData fxwPayment,
                                        List<String> fxStpDetails,
                                        Boolean fxStpFlag,
                                        String creditorAccNum,
                                        BeneficiaryAccount beneficiaryAccount) {
        // Validate the creditor account number against the accountNumberRegex
        final boolean accNumRegexExists = org.apache.commons.lang3.StringUtils.isNotEmpty(beneficiaryAccount.getAccountNumberRegex());
        if (OPTIONAL.equals(beneficiaryAccount.getIbanRequired())) {
            if (accNumRegexExists) {
                // Skip the accountNumberRegex validation if account is a valid IBAN account
                boolean isValidIban = Objects.nonNull(beneficiaryAccount.getIban()) &&
                        StringUtils.startsWithIgnoreCase(creditorAccNum, beneficiaryAccount.getIban().getIbanISOCountryCode());
                if (!isValidIban) {
                    validateCreditorAccWithRegex(fxwPayment, fxStpDetails, fxStpFlag, creditorAccNum, beneficiaryAccount);
                }
            }
        } else if (NOT_APPLICABLE.equals(beneficiaryAccount.getIbanRequired())) {
            if (accNumRegexExists) {
                validateCreditorAccWithRegex(fxwPayment, fxStpDetails, fxStpFlag, creditorAccNum, beneficiaryAccount);
            }
        }
    }*/

    /*private void validateCreditorAccWithRegex(PaymentProcessingData fxwPayment,
                                              List<String> fxStpDetails,
                                              Boolean fxStpFlag,
                                              String creditorAccNum,
                                              BeneficiaryAccount beneficiaryAccount) {
        //Commented to avoid the security issue and will uncomment it once the security team approves it.
       *//* if (Pattern.matches(beneficiaryAccount.getAccountNumberRegex(), creditorAccNum)) {
            //If fxStpFlag is not null then same value will be set as per previous validations or else will set to true.
            fxwPayment.getPaymentData().setFxStpFlag(fxStpFlag != null ? fxStpFlag : true);
            log.info("Recipient account number has been validated");
        } else {
            fxwPayment.getPaymentData().setFxStpFlag(false);
            fxStpDetails.add("Recipient account number cannot be validated");
            log.info("Recipient account number cannot be validated");
        }*//*
    }*/

    private BeneficiaryAccount getBeneficiaryAccount(CountryRuleResponse countrySpecificFields, String transactionCcy, String paymentType) {
        BeneficiaryAccount beneficiaryAccount = null;

        RuleData data = countrySpecificFields.getData() != null ?
                countrySpecificFields.getData() : new RuleData();

        String isGachAllowed = countrySpecificFields.getData() != null ?
                countrySpecificFields.getData().getGACHAllowed() : GACH_ALLOWED_NO;

        //If payment type is FXG or MXG then get beneficiaryAccount object from gachInfo array by matching currency value with transactionCcy
        if (PAYMENT_METHOD_FX_PAYMENTS.contains(paymentType) && GACH_ALLOWED_YES.equalsIgnoreCase(isGachAllowed)) {
            Optional<GACHInfo> gachInfo = data.getGACHInfo().stream().filter(e -> e.getCurrency().equalsIgnoreCase(transactionCcy)).findFirst();
            if (gachInfo.isPresent()) {
                beneficiaryAccount = gachInfo.get().getBeneficiaryAccount();
            }
        } else {
            beneficiaryAccount = data.getBeneficiaryAccount();
        }
        return beneficiaryAccount;
    }

    public void postFXWPayment(Object fxwPaymentProcessingData) {
        log.info("Post FX Payment to FXW Posting Topic");
        template.send(kafkaTopicProperties.getFxwPosting(), fxwPaymentProcessingData);
    }

    private void updateFieldInstructionCode23E(PaymentProcessingData paymentData) {
        if (paymentData != null && paymentData.getInstructions() == null)
            paymentData.setInstructions(new Instructions());

        if (paymentData != null &&
                PaymentConstant.DENMARK_CURRENCY.equals(paymentData.getTransactionCcy())
                && PAYMENT_METHOD_FX_PAYMENTS.contains(paymentData.getPaymentType())) {
            paymentData.getInstructions().setRemittanceInformation(DKK_INSTRUCTION_CODE23E);
            log.info("Updating instructioncode23E to CORT for FX payments with DKK currency ");
        }
    }

    private void handleFXExecuteFailure(FXExecuteResponse fxExecuteResponse, PaymentTransactionStatusEntity statusEntity) throws Exception {
        int retryCount = (statusEntity.getNoOfRetries() != null ? statusEntity.getNoOfRetries() : 0) + 1;
        FXErrorInfoMappingEntity fxErrorInfoMappingEntity = metadataCache.getFxErrorInfoEntity(fxExecuteResponse.getErrorCode());
        if (fxErrorInfoMappingEntity.getIsRetriable().equalsIgnoreCase("Y")) {
            if (retryCount == FX_EXECUTE_RETRY_LIMIT) {
                if ((HttpStatus.INTERNAL_SERVER_ERROR.value() + "").equals(fxExecuteResponse.getErrorCode())) {
                    updatePaymentStatus(statusEntity.getTransactionId(), DB_PAYMENT_TECHNICAL_FAILURE, FX_EXECUTE_API_FAILED + fxExecuteResponse.getErrorCode());
                    sendFXTradeBookingFailedEmail(statusEntity.getTransactionId(), fxExecuteResponse.getErrorDescription(), FX_EXECUTE_API_FAILED + fxExecuteResponse.getErrorCode());
                } else {
                    updatePaymentStatusAsFailed(statusEntity.getTransactionId(), objectMapper.writeValueAsString(fxExecuteResponse));
                }
            } else {
                log.info("Failed to retrieve the quote confirmation Id, mark record for {} for txn Reference {} ", DownstreamStatusEnum.FX_EXECUTE_RETRY, statusEntity.getTransactionId());
                statusEntity.setDownstreamStatus(DownstreamStatusEnum.FX_EXECUTE_RETRY.toString());
                statusEntity.setNoOfRetries(retryCount);
                paymentStatusUtil.updateEntireStatus(statusEntity, false);
            }
        } else {
            if ((HttpStatus.REQUEST_TIMEOUT.value() + "").equals(fxExecuteResponse.getErrorCode()) || (HttpStatus.GATEWAY_TIMEOUT.value() + "").equals(fxExecuteResponse.getErrorCode())) {
                updatePaymentStatus(statusEntity.getTransactionId(), DB_PAYMENT_TECHNICAL_FAILURE, FX_EXECUTE_API_FAILED + fxExecuteResponse.getErrorCode());
                sendFXTradeBookingTimeoutEmail(statusEntity.getTransactionId(), fxExecuteResponse.getErrorDescription(), FX_EXECUTE_API_FAILED + fxExecuteResponse.getErrorCode());
            } else {
                updatePaymentStatusAsFailed(statusEntity.getTransactionId(), objectMapper.writeValueAsString(fxExecuteResponse));
            }
        }
    }

    public void updatePaymentStatusAsFailed(Long paymentId, String errorResMsg) {
        log.info("Update payment status as Failed for paymentId {}", paymentId);
        updateTxnErrorMsg(paymentId, errorResMsg);
    }

    private void sendFXTradeBookingTimeoutEmail(Long paymentId, String request, String response) {
        String subject = "SVB Go - FX Payment Import - Trade booking time-out " + paymentId;
        String message = buildFXTradeBookingTimeoutEmailContent(paymentId, request, response);
        log.info("Sending FX trade book timeout email with Subject:{} and Content:{}", subject, message);
        emailService.sendEmail(subject, message);
        log.info("fx trade booking timeout email alert has been sent to App Support team for the paymentId: {}", paymentId);
    }

    private String buildFXTradeBookingTimeoutEmailContent(Long paymentId, String request, String response) {
        return "Hello Team,\n\n" +
                "Following SVB Go FX payment import - Trade booking request timed out.\n\n" +
                "SVB Go Payment ID: " + paymentId + "\n\n" +
                "FX Quote Request: " + request + "\n\n" +
                "Error: " + response + "\n\n\n\n" +
                "Next steps: \n\n" +
                "Please contact FX support team to confirm whether the FX trade booking was successful for the above 'Request ID'. \n\n" +
                "If the trade request was successful in FX system, update the SVB Go transaction with the trade confirmation ID and reprocess the transaction. \n\n" +
                "If the trade request failed, retrigger the FX trade request for the imported transaction from SVB Go.\n\n" +
                "For assistance, contact Go Payment Tech or Product team";
    }


    private void updatePaymentStatus(Long transactionId, String status, String soaTxnStatus) {
        log.info("Updating payment transaction status as:{} and response message as :{} for the transactionId:{}",
                status, soaTxnStatus, transactionId);
        transactionEntryDBMapper.updateTxnEntryDSStatus(transactionId, status);
    }

    private void updateTxnErrorMsg(Long transactionId, String errMsg) {
        log.info("Updating payment transaction status as: FAIL and response error message as :{} for the transactionId: {}",
                errMsg, transactionId);
        transactionEntryDBMapper.updateTxnEntryStatusAndErrorMsg(transactionId, TransactionStatusEnum.FAIL.name(), errMsg);
    }

    private void sendFXTradeBookingFailedEmail(Long paymentId, String request, String response) {
        String subject = "SVB Go - FX Payment Import - Trade booking failed " + paymentId;
        String message = buildFXTradeBookingFailedEmailContent(paymentId, request, response);
        log.info("Sending FX trade book failed email with Subject:{} and Content:{}", subject, message);
        emailService.sendEmail(subject, message);
        log.info("fx trade booking failed email alert has been sent to App Support team for the paymentId: {}", paymentId);
    }

    private String buildFXTradeBookingFailedEmailContent(Long paymentId, String request, String response) {
        return "Hello Team,\n\n" +
                "Following SVB Go FX payment import - Trade booking request failed.\n\n" +
                "SVB Go Payment ID: " + paymentId + "\n\n" +
                "FX Quote Request: " + request + "\n\n" +
                "Error: " + response + "\n\n\n\n" +
                "Next steps: \n\n" +
                "Please contact FX support team on the Trade booking service failure for the above 'Request ID'. \n\n" +
                "Once the service is back up, retrigger the imported FX transaction(s) from SVB Go.\n\n" +
                "For assistance, contact Go Payment Tech or Product team.";
    }

    public FXExecuteResponse fxTradeExecuteCall(PaymentProcessingData paymentData) throws PaymentServiceException {
        FXExecuteRequest fxExecuteRequest = buildFxExecuteApiRequest(paymentData);
        try {
            FXExecuteResponse fxExecuteResponse = null;

            log.info("FX Trade Execute Request for client Id = {} => buyAmount = {}, buyCurrency = {}," +
                            "requestId = {}, sellAmount = {}, sellCurrency = {} , CIF = {},  valueDate = {}",
                    fxExecuteRequest.getInternetId(), fxExecuteRequest.getBuyAmount(),
                    fxExecuteRequest.getBuyCurrency(), fxExecuteRequest.getRequestId(),
                    fxExecuteRequest.getSellAmount(), fxExecuteRequest.getSellCurrency(), fxExecuteRequest.getCustomerNumber(), fxExecuteRequest.getValueDate());

            Map<String, String> headers = new HashMap<>();
            headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            headers.put(HttpHeaders.AUTHORIZATION, paymentProperties.getFxAuthToken());
            HttpResponseContainer<FXExecuteResponse> response = genericRestClient.post(paymentProperties.getFxTradePurchaseUrl() + "/execute",
                    fxExecuteRequest,
                    FXExecuteResponse.class,
                    Duration.ofSeconds(95L),
                    headers,
                    false);

            log.info("FX Trade Execute Request Response Code is {} :: and clientId {} ", response.getStatusCode(), fxExecuteRequest.getInternetId());
            if (HttpStatus.OK.value() == response.getStatusCode().value()) {
                fxExecuteResponse = response.getSuccessResponse();
                log.info(fxExecuteResponse.getErrorCode() == null ?
                        "Received FX Trade Execute Response for client Id = " + fxExecuteRequest.getInternetId() + " =>  requestId = " + fxExecuteResponse.getRequestId() + ", transactionId = " + fxExecuteResponse.getTransactionId() + ",  sellAmount = "
                                + fxExecuteResponse.getSellAmount() + "  and buyAmount = " + fxExecuteResponse.getBuyAmount() :
                        "Received FX Trade Execute Error Response for client Id = " + fxExecuteRequest.getInternetId() + " =>  errorCode = "
                                + fxExecuteResponse.getErrorCode() + ", errorDescription = " + fxExecuteResponse.getErrorDescription());
                fxExecuteResponse.setTradeDate(PaymentUtil.convertFxDate(fxExecuteResponse.getTradeDate()));
                fxExecuteResponse.setValueDate(PaymentUtil.convertFxDate(fxExecuteResponse.getValueDate()));
            } else if (HttpStatus.INTERNAL_SERVER_ERROR.value() == response.getStatusCode().value()
                    || HttpStatus.GATEWAY_TIMEOUT.value() == response.getStatusCode().value()
                    || HttpStatus.REQUEST_TIMEOUT.value() == response.getStatusCode().value()) {
                fxExecuteResponse = new FXExecuteResponse();
                fxExecuteResponse.setErrorCode(response.getStatusCode().value() + "");
                fxExecuteResponse.setStatus("1");
                fxExecuteResponse.setErrorDescription(response.getErrorDescription());
            }
            return fxExecuteResponse;
        } catch (Exception e) {
            log.error("failed inside fxTradeExecuteCall while calling fx execute api with error msg : {}", e.getMessage());
            throw new PaymentServiceException(ErrorCodeEnum.FX_RUNTIME_SERVICE_ERROR, e);
        }
    }

    private FXExecuteRequest buildFxExecuteApiRequest(PaymentProcessingData paymentData) {
        FXExecuteRequest fxExecuteRequest = FXExecuteRequest.builder()
                .requestId(UUID.randomUUID().toString())
                .sourceSystem(paymentProperties.getFxExecuteSourceSystem())
                .productType(paymentProperties.getFxProductType())
                .tenor(paymentProperties.getFxProductType())
                .buyCurrency(paymentData.getCreditAccountData().getAccCcy())
                .sellCurrency(paymentData.getDebitAccountData().getAccCcy())
                .customerNumber(paymentData.getAddPayDetails().getCif())
                .fundingAccount(paymentData.getDebitAccountData().getAccNum())
                .internetId(paymentData.getAddPayDetails().getCorpID())
                .userId(paymentData.getAddPayDetails().getLoginID()).build();

        if (StringUtils.hasLength(paymentData.getCreditAccountData().getCcyAmount())) {
            fxExecuteRequest.setBuyAmount(Double.parseDouble(paymentData.getCreditAccountData().getCcyAmount()));
        } else {
            fxExecuteRequest.setSellAmount(Double.parseDouble(paymentData.getDebitAccountData().getCcyAmount()));
        }
        return fxExecuteRequest;
    }


    /**
     * Validate request data for cross-currency details
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    @CollectException
    public void validate(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        for (PaymentInitiationEntryData entryData : requestData.getRequest().getEntries()) {
            if (entryData.getDebitAccountData().getCcyAmt() == null
                    || entryData.getDebitAccountData().getCcyAmt() == 0) {
                CommonUtil.raiseException(requestData.getGatewayContext(), 200930, ErrorCodeEnum.CROSS_CURRENCY_ERROR,
                        "Debit account amount must be greater than zero", null, false);
            }
            if (!StringUtils.hasLength(entryData.getCrossCurrencyPaymentData().getCurrencyPair())) {
                CommonUtil.raiseException(requestData.getGatewayContext(), 1068, ErrorCodeEnum.CROSS_CURRENCY_ERROR,
                        "Currency pair is mandatory", null, false);
            }

            com.svb.gateway.payments.common.model.payment.CrossCurrencyPaymentData crossCurrencyData = entryData.getCrossCurrencyPaymentData();
            if (crossCurrencyData.isDealPayment()) {
                checkMandatoryValuesForDealBasedFX(context, crossCurrencyData);
            } else {
                checkMandatoryValuesForNonDealBasedFX(context, crossCurrencyData);
            }

            double fxRate = crossCurrencyData.getFxRate();
            BigDecimal transactionAmount = new BigDecimal(Double.toString(entryData.getTransactionAmt() * fxRate)).setScale(2, RoundingMode.HALF_UP);
            BigDecimal debitAmount = new BigDecimal(Double.toString(entryData.getDebitAccountData().getCcyAmt())).setScale(2, RoundingMode.HALF_UP);

            if (transactionAmount.compareTo(debitAmount) != 0) {
                log.info("FX validation::transaction-debit amount(after applying rate) are not matching. debit amount {}, transaction amount {}",
                        debitAmount,
                        transactionAmount);
            }
        }
    }

    private void checkMandatoryValuesForNonDealBasedFX(PaymentContext context, com.svb.gateway.payments.common.model.payment.CrossCurrencyPaymentData crossCurrencyData) throws PaymentServiceException {
        if (Mode.CREATE.equals(context.getMode())
                && !context.isApprovalFlag()
                && (crossCurrencyData.getQuoteId() == null || crossCurrencyData.getQuoteId().isEmpty())
                && (crossCurrencyData.getQuoteConfirmationId() == null || crossCurrencyData.getQuoteConfirmationId().isEmpty())) {
            CommonUtil.raiseException(context, 1027, ErrorCodeEnum.CROSS_CURRENCY_ERROR, "Quote id OR Quote confirmation id is required", null, false);
        }
        if (crossCurrencyData.getBaseAmountIndicator() == null
                || !"CD".contains(crossCurrencyData.getBaseAmountIndicator())) {
            CommonUtil.raiseException(context, 1028, ErrorCodeEnum.CROSS_CURRENCY_ERROR, "Base amount indicator must be C or D", null, false);
        }
    }

    private void checkMandatoryValuesForDealBasedFX(GatewayContext context, com.svb.gateway.payments.common.model.payment.CrossCurrencyPaymentData crossCurrencyData) throws PaymentServiceException {
        if (crossCurrencyData.getTradeDate() == null || crossCurrencyData.getTradeDate().isEmpty()) {
            CommonUtil.raiseException(context, 1021, ErrorCodeEnum.CROSS_CURRENCY_ERROR, "Trade date cannot be empty", null, false);
        }
        if (crossCurrencyData.getValueDate() == null || crossCurrencyData.getValueDate().isEmpty()) {
            CommonUtil.raiseException(context, 1022, ErrorCodeEnum.CROSS_CURRENCY_ERROR, "Value date cannot be empty", null, false);
        }
        if (crossCurrencyData.getFxRate() == null || crossCurrencyData.getFxRate() == 0) {
            CommonUtil.raiseException(context, 1023, ErrorCodeEnum.CROSS_CURRENCY_ERROR, "Fx rate cannot be empty or 0", null, false);
        }
        if (crossCurrencyData.getTradeType() == null || crossCurrencyData.getTradeType().isEmpty()) {
            CommonUtil.raiseException(context, 1024, ErrorCodeEnum.CROSS_CURRENCY_ERROR, "Trade type cannot be empty", null, false);
        }
        if (crossCurrencyData.getTradeChannel() == null || crossCurrencyData.getTradeChannel().isEmpty()) {
            CommonUtil.raiseException(context, 1025, ErrorCodeEnum.CROSS_CURRENCY_ERROR, "Trade channel cannot be empty", null, false);
        }
        if (crossCurrencyData.getFxContractId() == null || crossCurrencyData.getFxContractId().isEmpty()) {
            CommonUtil.raiseException(context, 1026, ErrorCodeEnum.CROSS_CURRENCY_ERROR, "FX contract id cannot be empty", null, false);
        }
    }

    /**
     * Book quote and populate confirmation
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    public void bookQuote(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        FXTradeBookRequest request;
        // no action required (approval flow)
        if (checkForBooking(requestData)) {
            return;
        }
        try {
            // quote id will be the same for all entries
            PaymentInitiationEntryData entryData = requestData.getRequest().getEntries().getFirst();
            // no action required
            if (checkForBooking(entryData.getCrossCurrencyPaymentData())) {
                return;
            }
            // create request
            request = fxMapper.getFXTradeBookRequest(entryData.getCrossCurrencyPaymentData());
            request.setSourceSystem(paymentProperties.getFxSourceSystem());
            // book once, update for all entries
            FXTradeBookResponse response = fxRetryComponent.bookQuote(request, (PaymentContext) requestData.getGatewayContext());
            for (PaymentInitiationEntryData entry : requestData.getRequest().getEntries()) {
                fxMapper.getCrossCurrencyData(entry.getCrossCurrencyPaymentData(), response);
            }
        } catch (PaymentServiceException e) {
            log.error("FX book::error {}, {}", e.getMessage(), requestData.getGatewayContext().log());
            throw new PaymentServiceException(1029, ErrorCodeEnum.FX_BOOK_CONTRACT_ERROR, "FX book failed");
        }
    }

    /**
     * Check for calling book quote API
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return boolean
     */
    private boolean checkForBooking(RequestData<PaymentInitiationData> requestData) {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        return requestData.getRequest().isHold()
                || context.isApprovalFlag();
    }

    /**
     * Check for calling book quote API
     *
     * @param crossCurrencyData CrossCurrencyPaymentData
     * @return boolean
     */
    private boolean checkForBooking(com.svb.gateway.payments.common.model.payment.CrossCurrencyPaymentData crossCurrencyData) {
        return crossCurrencyData.isDealPayment() || StringUtils.hasLength(crossCurrencyData.getQuoteConfirmationId());
    }

    public void consumeFXPaymentPostingResponse(FXPaymentPostingResponse fxPaymentPostingResponse) {
        log.info("Entering consumeFXPaymentPostingResponse method");
        String[] txnIdAndSequenceNo = fxPaymentPostingResponse.getAttachFSIResponse().getWireTransactionId().replace(PaymentConstant.PAYMENTS_GW_PREFIX, "")
                .split(PaymentUtil.SPLIT_REF_SEPARATOR);
        Long txnId = Long.parseLong(txnIdAndSequenceNo[0]);
        Integer sequenceNo = txnIdAndSequenceNo.length > 1 ? Integer.parseInt(txnIdAndSequenceNo[1]) : 1;
        PaymentTransactionStatusEntity paymentTransactionStatusEntity = transactionDBMapper.getPaymentTransactionByIdAndSequence(txnId, sequenceNo);
        if (paymentTransactionStatusEntity != null) {
            log.info("Fetched FX payment from DB for txn id:{}", paymentTransactionStatusEntity.getTransactionId());
            AttachFSIResponse attachFSIResponse = fxPaymentPostingResponse.getAttachFSIResponse();
            switch (fxPaymentPostingResponse.getAttachFSIResponse().getStatus().toLowerCase()) {
                case PaymentConstant.FX_PAYMENT_POSTING_REJECTED ->
                        reviewRejection(fxPaymentPostingResponse, paymentTransactionStatusEntity);
                case PaymentConstant.FX_PAYMENT_POSTING_PENDING ->
                        fxPaymentPostingPendingHandling(fxPaymentPostingResponse, paymentTransactionStatusEntity);
                case PaymentConstant.FX_PAYMENT_POSTING_FAILURE ->
                        paymentTransactionStatusEntity.setDownstreamStatus(DownstreamStatusEnum.OFFLINE_RETRY.toString());
                default ->
                        paymentTransactionStatusEntity.setDownstreamStatus(DownstreamStatusEnum.IN_PROCESS.toString());
            }
            paymentTransactionStatusEntity.setDealNumber(Optional.of(attachFSIResponse).map(AttachFSIResponse::getParentDealNumber).orElse(CommonConstant.EMPTY));
            paymentTransactionStatusEntity.setDeliveryDate(dateUtil.getStartOfDayDateTime());
            if (PaymentUtil.isFXSplitTransactionId(fxPaymentPostingResponse.getAttachFSIResponse().getWireTransactionId())) {
                paymentTransactionStatusEntity.setContractId(Optional.of(attachFSIResponse).map(AttachFSIResponse::getParentContractId).orElse(""));
            }
            paymentStatusUtil.updateEntireStatus(paymentTransactionStatusEntity, true);
        } else {
            log.error("Request failed as transaction not found in DB for txn id:{}", fxPaymentPostingResponse.getAttachFSIResponse().getWireTransactionId());
        }
        log.info("Exiting consumeFXPaymentPostingResponse method");
    }

    void reviewRejection(FXPaymentPostingResponse fxPaymentPostingResponse,
                         PaymentTransactionStatusEntity transactionStatusEntity) {
        if (isContractNotFoundErrorCode(fxPaymentPostingResponse)) {
            fxPaymentPostingPendingHandling(fxPaymentPostingResponse, transactionStatusEntity);
        } else {
            transactionStatusEntity.setStatus(TransactionStatusEnum.FAIL.name());
            transactionStatusEntity.setDownstreamStatus(DownstreamStatusEnum.FAILED.toString());
            transactionStatusEntity.setErrorCode(Optional.of(fxPaymentPostingResponse.getAttachFSIResponse())
                    .map(AttachFSIResponse::getFaultDetails).map(FaultDetails::getErrorCode).orElse(EMPTY));
            transactionStatusEntity.setErrorDetails(PAYMENT_STATUS_DESCRIPTION_FAILED);
        }
    }

    private void fxPaymentPostingPendingHandling(FXPaymentPostingResponse fxPaymentPostingResponse, PaymentTransactionStatusEntity transactionStatusEntity) {
        String wireTransactionId = PaymentUtil.trimWireTransactionId(fxPaymentPostingResponse.getAttachFSIResponse().getWireTransactionId());
        String dealNumber = fxPaymentPostingResponse.getAttachFSIResponse().getParentDealNumber();
        int retryCount = transactionStatusEntity.getNoOfRetries();
        if (retryCount == fxRetryLimit) {
            transactionStatusEntity.setDownstreamStatus(DownstreamStatusEnum.OFFLINE_RETRY.toString());
            String fxOfflineRetrySubject = "FX Payment : " + wireTransactionId + " - Failed for Deal Number :  " + dealNumber;
            String fxOfflineRetryBody = "Gateway payment Id : " + wireTransactionId + " failed to attach to deal number : " + dealNumber + ". Retrieve payment message from DB for payment instruction details.";
            emailService.sendEmail(fxOfflineRetrySubject, fxOfflineRetryBody);
        } else {
            transactionStatusEntity.setDownstreamStatus(DownstreamStatusEnum.POSTING_RETRY.toString());
        }
    }

    boolean isContractNotFoundErrorCode(FXPaymentPostingResponse fxPaymentPostingResponse) {
        return Optional.ofNullable(fxPaymentPostingResponse.getAttachFSIResponse())
                .map(AttachFSIResponse::getFaultDetails)
                .map(faultDetails -> PaymentConstant.CONTRACT_NOT_FOUND_ERROR_CODE.equals(faultDetails.getErrorCode())).orElse(false);
    }

    public void consumeFXSplitPaymentPostingResponse(FXSplitPaymentPostingResponse fxSplitPaymentPostingResponse) throws Exception {
        log.info("Entering consumeFXSplitPaymentPostingResponse method. contract id:{}", fxSplitPaymentPostingResponse.getParentContractID());
        updateSplitDebitType(fxSplitPaymentPostingResponse);
        if (!CollectionUtils.isEmpty(fxSplitPaymentPostingResponse.getSplits())) {
            List<Split> splits = fxSplitPaymentPostingResponse.getSplits();
            String transactionId = PaymentUtil.getSplitTransactionId(splits.getFirst().getWireTransactionID());
            List<PaymentTransactionStatusEntity> paymentTransactionStatusEntityList = transactionDBMapper.getPaymentTransactions(Long.valueOf(transactionId));
            for (PaymentTransactionStatusEntity splitEntity : paymentTransactionStatusEntityList) {
                String splitWireTransactionId = PaymentUtil.FX_PAYMENTS_GW_PREFIX + transactionId + PaymentUtil.SPLIT_REF_SEPARATOR + splitEntity.getSequenceNo();
                Split split = splits.stream().filter(sp -> splitWireTransactionId.equals(sp.getWireTransactionID())).findFirst().orElse(null);
                if (split != null) {
                    splitEntity.setContractId(split.getChildContractID());
                    splitEntity.setDealNumber(split.getChildDealNumber());
                    // Updating buyAmount from WSS as the Debit Amount
                    splitEntity.setDebitAmount(split.getBuyAmount());
                    paymentStatusUtil.setE2ERefNo(splitEntity);
                    log.info("Updating split payment details to DB for wireTransactionId:{}, contract id:{}", splitWireTransactionId, fxSplitPaymentPostingResponse.getParentContractID());
                    transactionEntryDBMapper.updateTransactionEntryStatus(splitEntity);
                } else {
                    log.error("FX split payment transaction not found in Split response for transaction_id:{}", splitWireTransactionId);
                }
            }
            PaymentTransactionStatusEntity parentTransactionStatusEntity = PaymentTransactionStatusEntity.builder()
                    .transactionId(Long.valueOf(transactionId))
                    .contractId(fxSplitPaymentPostingResponse.getParentContractID())
                    .dealNumber(fxSplitPaymentPostingResponse.getParentDealNumber())
                    .build();
            transactionDBMapper.updateTransactionStatus(parentTransactionStatusEntity);
        } else if (fxSplitPaymentPostingResponse.getFaultDetails() != null
                && PaymentConstant.AMT_MISMATCH_VALIDATION_FAILURE.equalsIgnoreCase(
                fxSplitPaymentPostingResponse.getFaultDetails().getErrorDescription())) {
            PaymentTransactionStatusEntity paymentTransactionStatusEntity = transactionDBMapper.getPaymentTransactionWithContractId(
                    fxSplitPaymentPostingResponse.getParentContractID());
            if (paymentTransactionStatusEntity != null) {
                paymentTransactionStatusEntity.setStatus(TransactionStatusEnum.FAIL.name());
                paymentTransactionStatusEntity.setDownstreamStatus(DownstreamStatusEnum.FAILED.toString());
                paymentTransactionStatusEntity.setErrorCode(fxSplitPaymentPostingResponse.getFaultDetails().getErrorCode());
                paymentTransactionStatusEntity.setErrorDetails(fxSplitPaymentPostingResponse.getFaultDetails().getErrorDetails());
                paymentTransactionStatusEntity.setRemarks(fxSplitPaymentPostingResponse.getFaultDetails().getErrorDetails());
                paymentTransactionStatusEntity.setContractId(fxSplitPaymentPostingResponse.getParentContractID());
                paymentTransactionStatusEntity.setDealNumber(fxSplitPaymentPostingResponse.getParentDealNumber());
                emailService.sendEmail(
                        PaymentConstant.AMT_MISMATCH_VALIDATION_FAILURE
                                + " for contract id : "
                                + fxSplitPaymentPostingResponse.getParentContractID(), "Received error response : "
                                + objectMapper.writeValueAsString(fxSplitPaymentPostingResponse));

                log.info("Updating fx split payment error details to DB for contract id:{}", paymentTransactionStatusEntity.getContractId());
                paymentStatusUtil.updateSplitFxTransactionByContractId(paymentTransactionStatusEntity);
            } else {
                log.error("FX split payment transaction not found in DB for contract id:{}", fxSplitPaymentPostingResponse.getParentContractID());
            }
        }
        log.info("Exiting consumeFXSplitPaymentPostingResponse method");
    }

    private void updateSplitDebitType(FXSplitPaymentPostingResponse fxSplitPaymentPostingResponse) {
        if (fxSplitPaymentPostingResponse != null) { //TODO Remove Condition
            String parentContractID = fxSplitPaymentPostingResponse.getParentContractID();
            String splitDebitType = fxSplitPaymentPostingResponse.getDebitType();
            log.info("Update split payment debit type for the parent contractId:{} as {}", parentContractID, splitDebitType);
            Long transactionId = Optional.ofNullable(fxSplitPaymentPostingResponse.getSplits())
                    .map(list -> !CollectionUtils.isEmpty(list) ? list.getFirst() : null)
                    .map(Split::getWireTransactionID)
                    .map(PaymentUtil::getSplitTransactionId)
                    .map(Long::valueOf)
                    .orElse(null);

            PaymentTransactionStatusEntity.PaymentTransactionStatusEntityBuilder paymentTransactionStatusEntityBuilder =
                    PaymentTransactionStatusEntity.builder()
                            .contractId(parentContractID)
                            .splitDebitType(splitDebitType);
            try {
                if (transactionId != null) {
                    paymentTransactionStatusEntityBuilder.transactionId(transactionId);
                    transactionDBMapper.updateTransactionStatus(paymentTransactionStatusEntityBuilder.build());
                } else {
                    transactionDBMapper.updateTransactionByContractId(paymentTransactionStatusEntityBuilder.build());
                }
            } catch (Exception e) {
                log.error("An error has been occurred while updating the split payment debit type for the parent contractId: {} - {} ", parentContractID, e.getMessage());
            }
        }
    }

    public FxEndToEndStatusRes getE2EStatus(String dealNumber) {
        String status = "";
        String requestBody = "{\"sourceReferenceId\":\"" + dealNumber + "\"}";
        log.info("Sending request to FX payment status is :: {}", requestBody);
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put(HttpHeaders.AUTHORIZATION, "Bearer " + apigeeProperties.getFxEndToEndStatusAuthToken());
        try {
            HttpResponseContainer<FxEndToEndStatusRes> response = genericRestClient.post(
                    apigeeProperties.getFxEndToEndStatusUrl(),
                    requestBody,
                    FxEndToEndStatusRes.class,
                    Duration.ofSeconds(60L),
                    headerMap, false);
            log.info("Response code from FX payment confirmation status request is :: {}", response.getStatusCode());
            if (HttpStatus.OK == response.getStatusCode()) {
                status = FX_API_STATUS_SUCCESS.equals(response.getSuccessResponse().getStatus()) ? response.getSuccessResponse().getPaymentStatus() : response.getSuccessResponse().getMessage();
            }
            log.info("Message received for:{} is:{}", dealNumber, status);
            return response.getSuccessResponse();
        } catch (Exception e) {
            log.error("Error occurred when retrieving FX payment confirmation status. Message: {}", e.getMessage());
        }
        return null;
    }
}
