package com.svb.gateway.payments.payment.service;

import com.svb.gateway.payments.common.enums.ErrorCodeEnum;
import com.svb.gateway.payments.common.enums.TransactionStatusEnum;
import com.svb.gateway.payments.common.enums.payment.TransactionStatus;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.model.payment.TransferPaymentProcessingData;
import com.svb.gateway.payments.common.model.payment.processing.Instructions;
import com.svb.gateway.payments.common.model.payment.processing.PaymentProcessingData;
import com.svb.gateway.payments.common.properties.PaymentProperties;
import com.svb.gateway.payments.common.service.GenericRestClient;
import com.svb.gateway.payments.common.util.HttpResponseContainer;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.common.util.PaymentUtil;
import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.model.cbs.CbsXMLModel;
import com.svb.gateway.payments.payment.model.cbs.PostingResponse;
import com.svb.gateway.payments.payment.util.PaymentProcessingErrorUtil;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import gg.jte.TemplateEngine;
import gg.jte.TemplateOutput;
import gg.jte.output.StringOutput;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static com.svb.gateway.payments.common.util.PaymentConstant.*;

@Slf4j
@Service
public class TransferService {
    private final PaymentProperties paymentProperties;
    private final TemplateEngine templateEngine;
    private final GenericRestClient genericRestClient;
    private final PaymentProcessingErrorUtil paymentErrorUtil;
    private final PaymentStatusUtil paymentStatusUtil;

    @Autowired
    public TransferService(PaymentProperties paymentProperties,
                           TemplateEngine templateEngine,
                           GenericRestClient genericRestClient,
                           PaymentProcessingErrorUtil paymentErrorUtil,
                           PaymentStatusUtil paymentStatusUtil) {
        this.paymentProperties = paymentProperties;
        this.templateEngine = templateEngine;
        this.genericRestClient = genericRestClient;
        this.paymentErrorUtil = paymentErrorUtil;
        this.paymentStatusUtil = paymentStatusUtil;
    }

    public boolean postToCBS(PaymentTransactionStatusEntity transferEntity, TransferPaymentProcessingData transferPaymentData, boolean stopNSFRetry) throws PaymentServiceException {
        try {
            PaymentProcessingData paymentData = transferPaymentData.getPaymentData();
            String requestXML = createXmlRequestForCbsTransfer(paymentData);

            log.debug("Request to CBS for {} and HTTP request is {}  ", paymentData.getTxRefNum(), requestXML);

            Map<String, String> headers = new HashMap<>();
            headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_XML_VALUE);

            HttpResponseContainer<PostingResponse> response = genericRestClient.post(paymentProperties.getCbsUrl(),
                    requestXML,
                    PostingResponse.class,
                    Duration.ofSeconds(60L),
                    headers, true);

            log.info("CBS post is complete for TxnId:{} and HTTP response code is:{} ", paymentData.getTxRefNum(), response.getStatusCode());
            log.info("NSF - stopNSFRetry is : {}", stopNSFRetry);

            String dbStatus;

            Map<String, String> processingContext = transferPaymentData.getPaymentHeader().getContext();
            if (response.getStatusCode().value() == HttpStatus.OK.value()) {
                log.debug("CBS successful response body is : {} ", response.getSuccessResponse());
                PostingResponse postingResponse = response.getSuccessResponse();
                return handleCBSResponse(postingResponse, transferEntity, processingContext);
            } else { // not getting a 200 status from CBS
                log.info("CBS error response body is : {} ", response.getErrorResponse());
                int retryCount = (transferEntity.getNoOfRetries() != null ? transferEntity.getNoOfRetries() : 0) + 1;
                if (PaymentUtil.retryableStatus(response.getStatusCode().value()) && retryCount < PaymentConstant.transferRetryLimit) {
                    dbStatus = TransactionStatus.PRTY.toString();
                } else {
                    dbStatus = TransactionStatus.FAIL.toString();
                }
                paymentErrorUtil.handlerConsumerError(
                        transferEntity.getTransactionId(),
                        transferEntity.getPaymentType(),
                        dbStatus);
            }
        } catch (Exception e) {
            log.atError().setMessage("Unhandled exception in cbsPosting : {}").addArgument(e.getMessage()).setCause(e).log();
            paymentErrorUtil.handlerConsumerError(
                    transferEntity.getTransactionId(),
                    transferEntity.getPaymentType(),
                    "Exception occurred while posting the transfer to CBS : ", e);
            throw new PaymentServiceException(ErrorCodeEnum.PAYMENT_PROCESSING_CBS_POSTING_FAILURE, e);
        }
        return true;
    }

    private String createXmlRequestForCbsTransfer(PaymentProcessingData paymentData) {
        String memo = Optional.ofNullable(paymentData.getInstructions()).map(Instructions::getMemo).orElse("");
        String desc = String.format("TRANSFER FROM %s  TO  %s",
                PaymentUtil.getMaskedAccountNumber(paymentData.getDebitAccountData().getAccNum()),
                PaymentUtil.getMaskedAccountNumber(paymentData.getCreditAccountData().getAccNum()));

        CbsXMLModel cbsxmlModel = CbsXMLModel.builder()
                .userName(paymentProperties.getCbsUsername())
                .password(paymentProperties.getCbsPassword())
                .environmentName(paymentProperties.getCbsEnvironmentName())
                .debitAccNum(paymentData.getDebitAccountData().getAccNum())
                .debitAccType(paymentData.getDebitAccountData().getAccType())
                .creditAccNum(paymentData.getCreditAccountData().getAccNum())
                .creditAccType(paymentData.getCreditAccountData().getAccType())
                .trnCode(paymentProperties.getCbsTrnCode())
                .memo(memo)
                .desc(desc)
                .transactionAmt(paymentData.getTransactionAmt())
                .build();

        TemplateOutput output = new StringOutput();
        templateEngine.render("transfer-template.jte", cbsxmlModel, output);
        return output.toString();
    }

    private boolean handleCBSResponse(PostingResponse cbsResponse,
            PaymentTransactionStatusEntity statusEntity, Map<String, String> processingContext) {
        boolean isErrorResponse = true;
        PostingResponse.MonSvcRs.TrnAppXferAddRs.Status status = cbsResponse.getMonSvcRs().getTrnAppXferAddRs().getStatus();
        int statusCode = status.getStatusCode();
        String errorCode = status.getError().getHostErrorCode() == null ? "" : status.getError().getHostErrorCode().trim();
        log.info("Enter handleCBSResponse for payment transaction no : {} : csbResponse status: {} and errorCode is {} ",
                statusEntity.getTransactionId(), statusCode, errorCode);

        if (statusCode == CBS_POSTING_STATUS_SUCCESS) {
            processingContext.put(PAYMENT_PROCESSING_STATUS, TransactionStatusEnum.PROC.name());
            statusEntity.setStatus(TransactionStatusEnum.PROC.name());
            paymentStatusUtil.updateEntireStatus(statusEntity, true);
            isErrorResponse = false;
        } else if (statusCode == CBS_POSTING_STATUS_POSSIBLE_RETRY && statusEntity.getNoOfRetries() < transferRetryLimit) {
            processingContext.put(PAYMENT_PROCESSING_STATUS, TransactionStatusEnum.INPR.name());
            statusEntity.setStatus(TransactionStatusEnum.INPR.name());
            statusEntity.setErrorDetails(status.getError().getErrorDescription());
            paymentStatusUtil.updateEntireStatus(statusEntity, false);
        } else { // Failed
            processingContext.put(PAYMENT_PROCESSING_STATUS, TransactionStatusEnum.FAIL.name());
            statusEntity.setStatus(TransactionStatusEnum.FAIL.name());
            statusEntity.setErrorDetails(status.getError().getErrorDescription());
            paymentStatusUtil.updateEntireStatus(statusEntity, true);
        }
        log.info("Exit handleCBSResponse: successfully update");
        return isErrorResponse;
    }
}
