package com.svb.gateway.payments.payment.service;

import com.svb.gateway.payments.common.entity.payment.BasePaymentEntity;
import com.svb.gateway.payments.common.service.payment.IPaymentTransactionExtService;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import org.springframework.stereotype.Service;

@Service
public class PaymentTransactionExtServiceImpl implements IPaymentTransactionExtService {

    private final TransactionDBMapper transactionDBMapper;

    public PaymentTransactionExtServiceImpl(TransactionDBMapper transactionDBMapper) {
        this.transactionDBMapper = transactionDBMapper;
    }

    @Override
    public BasePaymentEntity getPaymentTransactions(String txnId) {
        return transactionDBMapper.fetchPaymentTransaction(txnId);
    }
}
