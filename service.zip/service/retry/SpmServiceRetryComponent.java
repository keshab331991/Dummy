package com.svb.gateway.payments.payment.service.retry;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.payments.common.client.ApigeeAuthTokenEnum;
import com.svb.gateway.payments.common.enums.DownstreamStatusEnum;
import com.svb.gateway.payments.common.enums.TransactionStatusEnum;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.model.payment.PaymentTransStatusUpdateRequest;
import com.svb.gateway.payments.common.model.payment.payinit.PaymentRequest;
import com.svb.gateway.payments.common.model.payment.payinit.PaymentResponse;
import com.svb.gateway.payments.common.properties.ApigeeProperties;
import com.svb.gateway.payments.common.service.ApigeeTokenService;
import com.svb.gateway.payments.common.service.GenericRestClient;
import com.svb.gateway.payments.common.service.mail.EmailService;
import com.svb.gateway.payments.common.util.HttpResponseContainer;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.model.spm.*;
import com.svb.gateway.payments.payment.model.spm.System;
import com.svb.gateway.payments.payment.util.PaymentProcessingErrorUtil;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.retry.RetryContext;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.retry.support.RetrySynchronizationManager;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.svb.gateway.payments.common.util.PaymentConstant.*;

@Slf4j
@Service
public class SpmServiceRetryComponent {
    private final ApigeeTokenService apigeeTokenService;
    private final ObjectMapper objectMapper;
    private final TransactionDBMapper transactionDBMapper;
    private final GenericRestClient genericRestClient;
    private final EmailService emailService;
    private final ApigeeProperties apigeeProperties;
    private final PaymentProcessingErrorUtil paymentProcessingErrorUtil;
    private final PaymentStatusUtil paymentStatusUtil;

    @Autowired
    public SpmServiceRetryComponent(
            ApigeeTokenService apigeeTokenService,
            ObjectMapper objectMapper,
            TransactionDBMapper transactionDBMapper,
            GenericRestClient genericRestClient,
            EmailService emailService,
            ApigeeProperties apigeeProperties,
            PaymentProcessingErrorUtil paymentProcessingErrorUtil,
            PaymentStatusUtil paymentStatusUtil
    ) {
        this.apigeeTokenService = apigeeTokenService;
        this.objectMapper = objectMapper;
        this.transactionDBMapper = transactionDBMapper;
        this.genericRestClient = genericRestClient;
        this.emailService = emailService;
        this.apigeeProperties = apigeeProperties;
        this.paymentProcessingErrorUtil = paymentProcessingErrorUtil;
        this.paymentStatusUtil = paymentStatusUtil;
    }

    @Retryable(exceptionExpression = "@customHttpTimeoutRetryChecker.shouldRetry(#root)", recover = "recoverForInitiateSpm", backoff = @Backoff(delay = 1000))
    public HttpResponseContainer<PaymentResponse> initiateSpmPayment(PaymentRequest paymentRequest, Map<String, String> headers, String olbPaymentId, Map<String, String> context) throws PaymentServiceException {

        int retryCount = Optional.ofNullable(RetrySynchronizationManager.getContext()).map(RetryContext::getRetryCount).orElse(0);
        paymentRequest.setPaymentInformationId(getPaymentInfoId(olbPaymentId, retryCount));
        log.info("Initiate spm payment retry Count:{} for olbPaymentId: {}", retryCount, olbPaymentId);
        return genericRestClient.post(apigeeProperties.getUrl() + apigeeProperties.getSpmRelativePath(),
                paymentRequest,
                PaymentResponse.class,
                Duration.ofSeconds(60L),
                headers,
                false);

    }

    @Recover
    public void recoverForInitiateSpm(PaymentServiceException pse, PaymentRequest paymentRequest, Long olbPaymentId, Map<String, String> context) {
        log.error("SPM Service failed with a retryable exception more than 3 times with error response", pse);
        triggerPaymentSearch(paymentRequest, olbPaymentId, context);
        log.info("SPM Service returning from Search API.");
    }

    private String getPaymentInfoId(String txnRefNum, int noOfRetries) {
        StringBuilder paymentInformationId = new StringBuilder("GO").append(LocalDate.now().format(DateTimeFormatter.ofPattern("uuDDD"))).append(noOfRetries);
        if (txnRefNum.length() > 8) {
            paymentInformationId.append(txnRefNum.substring(txnRefNum.length() - 8));
        } else {
            paymentInformationId.append(String.format("%08d", Integer.parseInt(txnRefNum)));
        }
        return paymentInformationId.toString();
    }

    // Trigger Search Payment API if Retry limit exceeds
    public void triggerPaymentSearch(PaymentRequest paymentRequest, Long olbPaymentId, Map<String, String> context) {
        try {
            String accessToken = apigeeTokenService.getApigeeAuthToken(ApigeeAuthTokenEnum.SPM_CLIENT);
            String apigeeUrl = apigeeProperties.getUrl();
            log.info("Triggering PaymentSearch API for {}", paymentRequest.getPaymentInformationId());
            PaymentSearchRequest paymentSearchRequest = new PaymentSearchRequest();
            PaymentSearchRequest.Metadata metadata = new PaymentSearchRequest.Metadata();
            metadata.setRequesterReferenceId(UUID.randomUUID().toString());
            metadata.setRequesterName(SPM_SVBGO);
            paymentSearchRequest.setMetadata(metadata);

            List<PaymentSearchRequest.Condition> conditionsList = new ArrayList<>();
            PaymentSearchRequest.Condition conditions = new PaymentSearchRequest.Condition();
            List<String> values = new ArrayList<>();
            values.add(paymentRequest.getPaymentInformationId());
            log.info("Search Payment Request for paymentInfo Id:{}", paymentRequest.getPaymentInformationId());
            conditions.setValues(values);
            conditions.setRootProperty(SPM_PAYMENT);
            conditions.setProperty(SPM_PAYMENT_INSTRUCTION_ID);
            conditions.setOperator(SPM_EQUALS);
            conditionsList.add(conditions);
            paymentSearchRequest.setConditions(conditionsList);
            paymentSearchRequest.setIncludePaymentEvents(true);

            //Please remove this logger before go live
            log.debug("Search Payment Request:{}", paymentSearchRequest);

            Map<String, String> headers = new HashMap<>();
            headers.put(HttpHeaders.AUTHORIZATION, BEARER.concat(" " + accessToken));

            SPMPaymentStatusResponse spmPaymentStatusResponse = new SPMPaymentStatusResponse();
            HttpResponseContainer<PaymentSearchResponse> httpResponseContainer = genericRestClient.post(apigeeUrl + apigeeProperties.getSpmPaymentSearchPath(),
                    paymentSearchRequest,
                    PaymentSearchResponse.class,
                    Duration.ofSeconds(60L),
                    headers,
                    false);

            if (httpResponseContainer.getStatusCode() == HttpStatus.OK) {
                processSPMPaymentStatusResponse(paymentRequest, olbPaymentId, spmPaymentStatusResponse, httpResponseContainer.getSuccessResponse(), context);
            } else { //If the Search API fails with non 200 error.
                String message = httpResponseContainer.getStatusCode() + httpResponseContainer.getErrorResponse().replaceAll(SPM_MESSAGE_REGEX, "");
                log.info("Error Response Received from SPM Search: for olb_payment_id {} and message: {}", olbPaymentId, message);
                handlerConsumerTimeOutError(olbPaymentId, paymentRequest.getPaymentType() != null ?
                                paymentRequest.getPaymentType().toString() : "",
                        paymentRequest.getPaymentInformationId(), "Payment Search API failed after retry attempts.");
            }
        } catch (Exception e) {
            log.error("Payment Search Service HttpClient Exception for Resource", e);
        }
    }

    private void processSPMPaymentStatusResponse(PaymentRequest paymentRequest, Long olbPaymentId, SPMPaymentStatusResponse spmPaymentStatusResponse,
                                                 PaymentSearchResponse paymentSearchResponse, Map<String, String> context) {
        if (!paymentSearchResponse.getTransaction().isEmpty()) { //Processed in SPM
            setStatusRespValues(spmPaymentStatusResponse, paymentSearchResponse);
            if (SPM_PAYMENT_ACSC_STATUS.equals(paymentSearchResponse.getTransaction().getFirst().getPaymentStatusCode())) {
                context.put(PaymentConstant.PAYMENT_PROCESSING_STATUS, TransactionStatusEnum.SENT.name());
                updateSPMPaymentStatusInfoToDB(spmPaymentStatusResponse, TransactionStatusEnum.SENT.name(), olbPaymentId, true);
            } else if (SPM_PAYMENT_PDNG_STATUS.equals(paymentSearchResponse.getTransaction().getFirst().getPaymentStatusCode())) {
                context.put(PaymentConstant.PAYMENT_PROCESSING_STATUS, TransactionStatusEnum.INPR.name());
                updateSPMPaymentStatusInfoToDB(spmPaymentStatusResponse, TransactionStatusEnum.INPR.name(), olbPaymentId, true);
            } else if (SPM_PAYMENT_RJCT_STATUS.equals(paymentSearchResponse.getTransaction().getFirst().getPaymentStatusCode())) {
                context.put(PaymentConstant.PAYMENT_PROCESSING_STATUS, TransactionStatusEnum.REJC.name());
                handleSPMRejectStatus(paymentRequest, olbPaymentId, spmPaymentStatusResponse, paymentSearchResponse);
            }
        } else { //This Is for 200 - transaction doest not exist.
            log.info("No Transaction details Received from SPM Search for olb_payment_id:{}. Time-out Email alert has been triggered.", olbPaymentId);
            handlerConsumerTimeOutError(olbPaymentId, paymentRequest.getPaymentType().toString(),
                    paymentRequest.getPaymentInformationId(), "Payment Search API: This Transaction does not exist." + olbPaymentId);
        }
    }

    private void handleSPMRejectStatus(PaymentRequest paymentRequest,
                                       Long olbPaymentId,
                                       SPMPaymentStatusResponse spmPaymentStatusResponse,
                                       PaymentSearchResponse paymentSearchResponse) {
        //if transform fail/ validation fail then trigger email alert
        if (SPM_EVENT_TRANSFORMATION_FAILED.equals(paymentSearchResponse.getTransaction().getFirst().getPaymentEventState()) ||
                SPM_EVENT_VALIDATION_FAILED.equals(paymentSearchResponse.getTransaction().getFirst().getPaymentEventState())) {
            handlerConsumerError(olbPaymentId, paymentRequest.getPaymentType() != null ?
                            paymentRequest.getPaymentType().toString() : "",
                    spmPaymentStatusResponse.getPaymentInformationId(),
                    "This transaction is Rejected due to " + spmPaymentStatusResponse.getEventState());
            log.info("Handling SPM validation error email alert is sent to App Support for payment Ref Id:{}", spmPaymentStatusResponse.getPaymentReferenceId());
        } else {
            updateSPMPaymentStatusInfoToDB(spmPaymentStatusResponse, TransactionStatusEnum.FAIL.name(), olbPaymentId, true);
        }
    }

    private static void setStatusRespValues(SPMPaymentStatusResponse spmPaymentStatusResponse, PaymentSearchResponse paymentSearchResponse) {
        spmPaymentStatusResponse.setPaymentReferenceId(paymentSearchResponse.getTransaction().getFirst().getSpmReferenceId());
        spmPaymentStatusResponse.setPaymentInformationId(paymentSearchResponse.getTransaction().getFirst().getPaymentInstructionId());
        ReferenceId referenceId = new ReferenceId();
        Network network = new Network();
        FedWire fedWire = new FedWire();
        Swift swift = new Swift();
        network.setFedWire(fedWire);
        network.setSwift(swift);
        referenceId.setNetworks(network);
        spmPaymentStatusResponse.setReferenceIds(referenceId);
        if (null != paymentSearchResponse.getTransaction().getFirst().getImad()) {
            spmPaymentStatusResponse.getReferenceIds().getNetworks().getFedWire().setImad(paymentSearchResponse.getTransaction().getFirst().getImad());
        }
        if (null != paymentSearchResponse.getTransaction().getFirst().getOmad()) {
            spmPaymentStatusResponse.getReferenceIds().getNetworks().getFedWire().setOmad(paymentSearchResponse.getTransaction().getFirst().getOmad());
        }
        if (null != paymentSearchResponse.getTransaction().getFirst().getUetr()) {
            spmPaymentStatusResponse.getReferenceIds().getNetworks().getSwift().setUetr(paymentSearchResponse.getTransaction().getFirst().getUetr());
        }
    }

    /* Consume and process the SPM payments status response from Kafka. */
    public void consumeSPMPaymentStatus(SPMPaymentStatusResponse spmPaymentStatusResponse) {

        log.info("Entering consumeSPMPaymentStatus service");
        if (spmPaymentStatusResponse.getPaymentReferenceId() != null) {
            // Updating failed SPM payment to GW_TRANSACTION_ENTRY and email service
            String eventState = spmPaymentStatusResponse.getEventState();
            if((SPM_EVENT_TRANSFORMATION_FAILED.equals(eventState) ||
                    SPM_EVENT_VALIDATION_FAILED.equals(eventState)||
                    SPM_EVENT_REJECTED.equals(eventState) ||
                    GATEWAY_REJECTED.equals(eventState)) &&
                    SPM_PAYMENT_RJCT_STATUS.equals(spmPaymentStatusResponse.getPaymentStatus())){
                String spmTransformationFailedSubject = "SVB Go - SPM Payment Processing Failed" + spmPaymentStatusResponse.getPaymentReferenceId();
                String spmTransformationFailedBody = buildSpmTransformationFailedBody(spmPaymentStatusResponse);
                updateSPMPaymentStatusInfoToDB(spmPaymentStatusResponse,
                        TransactionStatusEnum.REJC.name() + "," + DB_PAYMENT_TECHNICAL_FAILURE
                        , null, false);
                emailService.sendEmail(spmTransformationFailedSubject, spmTransformationFailedBody);
                log.info("Handling SPM rejected error email alert is sent to App Support for payment Ref Id:{}", spmPaymentStatusResponse.getPaymentReferenceId());
            } else {
                // Updating to GW_TRANSACTION_ENTRY table
                String statuses = setSPMStatuses(spmPaymentStatusResponse);
                updateSPMPaymentStatusInfoToDB(spmPaymentStatusResponse, statuses, null, false);
            }
        }
    }

    public String setSPMStatuses(SPMPaymentStatusResponse spmPaymentStatusResponse) {
        log.info("Setting status value to be sent to DB");

        String statuses = "";
        if (SPM_PAYMENT_PNDG_STATUS.equals(spmPaymentStatusResponse.getPaymentStatus())) {
            statuses = TransactionStatusEnum.INPR.name() + "," + DownstreamStatusEnum.IN_PROCESS;
        } else if (SPM_PAYMENT_ACSC_STATUS.equals(spmPaymentStatusResponse.getPaymentStatus()) ||
                GFX_PNRM_STATUS.equals(spmPaymentStatusResponse.getEventState())) {
            statuses = TransactionStatusEnum.SENT.name() + "," + SPM_PAYMENT_ENTITY_PROCESSED_STATUS;
        } else if (SPM_PAYMENT_RJCT_STATUS.equals(spmPaymentStatusResponse.getPaymentStatus()) ||
                GFX_CANC_STATUS.equals(spmPaymentStatusResponse.getPaymentStatus())) {
            statuses = TransactionStatusEnum.CBNK.name() + "," + SPM_PAYMENT_ENTITY_FAILED_STATUS;
            if (SPM_EVENT_STATUS_NOT_ACKNOWLEDGED.equals(spmPaymentStatusResponse.getEventState())) {
                statuses = TransactionStatusEnum.INPR.name() + "," + DownstreamStatusEnum.IN_PROCESS;
            }
        }
        return statuses;
    }

    public boolean isFinalStatus(SPMPaymentStatusResponse spmPaymentStatusResponse) {
        log.info("Check if the payment is in final status for ref id :{}", spmPaymentStatusResponse.getPaymentReferenceId());
        PaymentTransactionStatusEntity paymentTransactionStatusEntity
                = transactionDBMapper.getSPMPayment(spmPaymentStatusResponse.getPaymentReferenceId());

        if (paymentTransactionStatusEntity == null) {
            log.info("Payment not found in DB for ref id:{}", spmPaymentStatusResponse.getPaymentReferenceId());
            return true;
        }

        log.info("Status of the payment from DB:{}",
                Optional.ofNullable(paymentTransactionStatusEntity.getStatus()).orElse(""));

        return TransactionStatusEnum.FAIL.name().equals(paymentTransactionStatusEntity.getStatus()) ||
                TransactionStatusEnum.SENT.name().equals(paymentTransactionStatusEntity.getStatus()) ||
                TransactionStatusEnum.REJC.name().equals(paymentTransactionStatusEntity.getStatus());
    }

    public String buildSpmTransformationFailedBody(SPMPaymentStatusResponse spmPaymentStatusResponse) {
        PaymentTransactionStatusEntity paymentTransactionStatusEntity = transactionDBMapper.getSPMPayment(spmPaymentStatusResponse.getPaymentReferenceId());
        return SPM_EMAIL_CONTENT1
                + SPM_EMAIL_CONTENT2 + paymentTransactionStatusEntity.getTransactionId()
                + SPM_EMAIL_CONTENT3 + spmPaymentStatusResponse.getPaymentInformationId()
                + "\n SPM Payment reference: " + spmPaymentStatusResponse.getPaymentReferenceId()
                + SPM_EMAIL_CONTENT4 + spmPaymentStatusResponse.getReasons()
                + "\n\n Next steps:\n Please contact SPM Support team \"Group IT Wires Support <SDLITWiresSupport@svb.com>\" and SVB Go Payment Tech or Product team to see if the payment can be re-triggered.";
    }

    private boolean updateSPMPaymentStatus(SPMPaymentStatusResponse spmPaymentStatusResponse, String olbPaymentId, String paymentType, boolean isSearchApiFlow) throws Exception {
        boolean updateSuccess = false;
        try {
            log.info("Update SPMPaymentStatusInfo for ref id:{}", spmPaymentStatusResponse.getPaymentReferenceId());

            PaymentTransStatusUpdateRequest paymentStatusUpdateRequest = new PaymentTransStatusUpdateRequest();
            List<PaymentTransStatusUpdateRequest.PaymentUpdateDetail> paymentUpdateDetail = new ArrayList<>();
            PaymentTransStatusUpdateRequest.PaymentUpdateDetail updateDetail = new PaymentTransStatusUpdateRequest.PaymentUpdateDetail();
            PaymentTransactionStatusEntity paymentProcessingStatusEntity = transactionDBMapper.getSPMPayment(spmPaymentStatusResponse.getPaymentReferenceId());
            if (isSearchApiFlow) { //if the db insertion flow is coming from Search API method.
                paymentProcessingStatusEntity = transactionDBMapper.getPaymentTransactions(Long.valueOf(olbPaymentId)).getFirst();
                paymentProcessingStatusEntity.setTransactionId(Long.valueOf(olbPaymentId));
                paymentProcessingStatusEntity.setPaymentRefId(spmPaymentStatusResponse.getPaymentReferenceId());
                paymentProcessingStatusEntity.setPaymentInfoId(spmPaymentStatusResponse.getPaymentInformationId());
                paymentProcessingStatusEntity.setPaymentType(paymentType);
            }
            updateDetail.setTxRefNum(paymentProcessingStatusEntity.getTransactionId().toString());

            // If posting status is "PROCESSED", update payment status as - 0 Success
            if (SPM_PAYMENT_ACSC_STATUS.equals(spmPaymentStatusResponse.getPaymentStatus())) {
                log.info("Updating status as PROCESSED for:{}", spmPaymentStatusResponse.getPaymentReferenceId());
                updateDetail.setStatus(PAYMENT_STATUS_SUCCESS);
                updateDetail.setDescription(PaymentConstant.PAYMENT_STATUS_DESCRIPTION_PROCESSED);
            }
            // If posting status is "CANCELLED", update payment status as - 2 Payment Failed
            else if (SPM_PAYMENT_RJCT_STATUS.equals(spmPaymentStatusResponse.getPaymentStatus())) {
                //Insert into error db, payment message not required
                log.info("Updating status as CANCELLED for:{}", spmPaymentStatusResponse.getPaymentReferenceId());
                updateDetail.setStatus(PaymentConstant.PAYMENT_STATUS_FAILURE);
                updateDetail.setDescription(PaymentConstant.PAYMENT_STATUS_DESCRIPTION_FAILED);
                PaymentTransStatusUpdateRequest.PaymentUpdateDetail.Error error = new PaymentTransStatusUpdateRequest.PaymentUpdateDetail.Error();
                error.setCode(GFX_FAILURE_CODE);
                error.setDescription("");
                ArrayList<PaymentTransStatusUpdateRequest.PaymentUpdateDetail.Error> errors = new ArrayList<>();
                errors.add(error);
                updateDetail.setErrors(errors);
            }
            if (Optional.of(spmPaymentStatusResponse).map(SPMPaymentStatusResponse::getReferenceIds).map(ReferenceId::getNetworks)
                    .map(Network::getFedWire).map(FedWire::getImad).isPresent()) {
                updateDetail.setImad(spmPaymentStatusResponse.getReferenceIds().getNetworks().getFedWire().getImad());
            }
            if (Optional.of(spmPaymentStatusResponse).map(SPMPaymentStatusResponse::getReferenceIds).map(ReferenceId::getNetworks)
                    .map(Network::getFedWire).map(FedWire::getOmad).isPresent()) {
                updateDetail.setOmad(spmPaymentStatusResponse.getReferenceIds().getNetworks().getFedWire().getOmad());
            }
            if (Optional.of(spmPaymentStatusResponse).map(SPMPaymentStatusResponse::getReferenceIds).map(ReferenceId::getNetworks)
                    .map(Network::getSwift).map(Swift::getUetr).isPresent()) {
                updateDetail.setSwiftRefNum(spmPaymentStatusResponse.getReferenceIds().getNetworks().getSwift().getUetr());
            }

            if (Optional.of(spmPaymentStatusResponse).map(SPMPaymentStatusResponse::getReferenceIds).map(ReferenceId::getSystems)
                    .map(System::getUsWire).map(UsWire::getReferenceId).isPresent()) {
                updateDetail.setGfxRefNum(spmPaymentStatusResponse.getReferenceIds().getSystems().getUsWire().getReferenceId());
            }

            if (Optional.of(spmPaymentStatusResponse).map(SPMPaymentStatusResponse::getReferenceIds).map(ReferenceId::getSystems)
                    .map(System::getMcaWire).map(UsWire::getReferenceId).isPresent()) {
                updateDetail.setFcReferenceId(spmPaymentStatusResponse.getReferenceIds().getSystems().getMcaWire().getReferenceId());
            }

            paymentUpdateDetail.add(updateDetail);
            paymentStatusUpdateRequest.setPaymentUpdateDetails(paymentUpdateDetail);
            String spmPaymentStatusUpdateRequestString = objectMapper.writeValueAsString(paymentStatusUpdateRequest);
            log.info("Updating SPM Payment Status with:{}", spmPaymentStatusUpdateRequestString); //REMOVE printing all logs

        } catch (Exception e) {
            log.error("Error updating SPM payment status to:{}", String.valueOf(e));
            throw e;
        }
        return updateSuccess;
    }

    private void updateSPMPaymentStatusInfoToDB(SPMPaymentStatusResponse spmPaymentStatus, String statuses, Long olbPaymentId, boolean isSearchApiFlow) {

        log.info("Fetching SPM payment for ref Id:{}", spmPaymentStatus.getPaymentReferenceId());
        PaymentTransactionStatusEntity paymentTransactionStatusEntity =
                transactionDBMapper.getSPMPayment(spmPaymentStatus.getPaymentReferenceId());

        if (paymentTransactionStatusEntity != null) {
            if (isSearchApiFlow) { //if the db insertion flow is coming from Search API method.
                paymentTransactionStatusEntity = transactionDBMapper.getSPMPayment(spmPaymentStatus.getPaymentReferenceId());
                paymentTransactionStatusEntity.setTransactionId(olbPaymentId);
                paymentTransactionStatusEntity.setPaymentRefId(spmPaymentStatus.getPaymentReferenceId());
                paymentTransactionStatusEntity.setPaymentInfoId(spmPaymentStatus.getPaymentInformationId());
            }
            log.info("Persisting SPM Payment status entity for ref id:{}", paymentTransactionStatusEntity.getPaymentRefId());
            String[] status = statuses.split(",");
            paymentTransactionStatusEntity.setStatus(status[0]);
            if (status.length > 1) {
                paymentTransactionStatusEntity.setDownstreamStatus(statuses.split(",")[1]);
            }
            // Setting SPM payment attributes to the payment txn entity for update
            spmPaymentStatusMappingHelper(spmPaymentStatus, paymentTransactionStatusEntity);

            if (TransactionStatusEnum.CBNK.name().equalsIgnoreCase(status[0].trim())) {
                paymentTransactionStatusEntity.setStatus(TransactionStatusEnum.FAIL.name());
                paymentTransactionStatusEntity.setRemarks(PaymentConstant.PAYMENT_CANCELLED_BY_BANK_REASON);
            }

            //Updating the spm payment status response received from SPM into the GW_TRANSACTION_ENTRY table
            paymentStatusUtil.setE2ERefNo(paymentTransactionStatusEntity);
            paymentStatusUtil.updateEntireStatus(paymentTransactionStatusEntity, true);
            log.info("SPM Payment process Status Entity has been updated for ref id:{}", spmPaymentStatus.getPaymentReferenceId());
        }
    }

    private void spmPaymentStatusMappingHelper(SPMPaymentStatusResponse spmPaymentStatus, PaymentTransactionStatusEntity paymentTransactionStatusEntity) {
        if (Optional.of(spmPaymentStatus).map(SPMPaymentStatusResponse::getReferenceIds).map(ReferenceId::getNetworks)
                .map(Network::getFedWire).map(FedWire::getImad).isPresent()) {
            paymentTransactionStatusEntity.setImad(spmPaymentStatus.getReferenceIds().getNetworks().getFedWire().getImad());
        }
        if (Optional.of(spmPaymentStatus).map(SPMPaymentStatusResponse::getReferenceIds).map(ReferenceId::getNetworks)
                .map(Network::getFedWire).map(FedWire::getOmad).isPresent()) {
            paymentTransactionStatusEntity.setOmad(spmPaymentStatus.getReferenceIds().getNetworks().getFedWire().getOmad());
        }
        if (Optional.of(spmPaymentStatus).map(SPMPaymentStatusResponse::getReferenceIds).map(ReferenceId::getNetworks)
                .map(Network::getSwift).map(Swift::getUetr).isPresent()) {
            paymentTransactionStatusEntity.setSwiftRefNum(spmPaymentStatus.getReferenceIds().getNetworks().getSwift().getUetr());
            paymentTransactionStatusEntity.setUetr(spmPaymentStatus.getReferenceIds().getNetworks().getSwift().getUetr());
        }
        if (Optional.of(spmPaymentStatus).map(SPMPaymentStatusResponse::getReferenceIds).map(ReferenceId::getSystems)
                .map(System::getUsWire).map(UsWire::getReferenceId).isPresent()) {
            paymentTransactionStatusEntity.setGfxRefNum(spmPaymentStatus.getReferenceIds().getSystems().getUsWire().getReferenceId());
        }
        if (Optional.of(spmPaymentStatus).map(SPMPaymentStatusResponse::getReferenceIds).map(ReferenceId::getSystems)
                .map(System::getFxWire).map(FxWire::getDealId).isPresent()) {
            paymentTransactionStatusEntity.setGfxRefNum(spmPaymentStatus.getReferenceIds().getSystems().getFxWire().getDealId());
        }
        if (Optional.of(spmPaymentStatus).map(SPMPaymentStatusResponse::getReferenceIds).map(ReferenceId::getSystems)
                .map(System::getMcaWire).map(UsWire::getReferenceId).isPresent()) {
            paymentTransactionStatusEntity.setE2eRefNo(spmPaymentStatus.getReferenceIds().getSystems().getMcaWire().getReferenceId());
        }
    }

    private void handlerConsumerError(Long olbPaymentId, String paymentType, String paymentInfoId, String errorMsg) {
        String spmServiceFailedSubject = "SVB Go - SPM Payment Processing Failed - " + paymentInfoId;
        String spmTransformationFailedBody = buildSpmServiceFailedBody(olbPaymentId, paymentInfoId, errorMsg);
        paymentProcessingErrorUtil.handlerProcessingError(olbPaymentId, paymentType, errorMsg, spmServiceFailedSubject, spmTransformationFailedBody, false);
    }

    private void handlerConsumerTimeOutError(Long olbPaymentId, String paymentType, String paymentInfoId, String errorMsg) {
        String spmServiceFailedSubject = SPM_TIMEOUT_EMAIL_SUBJECT + paymentInfoId;
        String spmTransformationFailedBody = buildTimeoutEmailBody(olbPaymentId, paymentInfoId, errorMsg);
        paymentProcessingErrorUtil.handlerProcessingError(olbPaymentId, paymentType, errorMsg, spmServiceFailedSubject, spmTransformationFailedBody, false);
    }

    public String buildTimeoutEmailBody(Long olbPaymentId, String paymentInfoId, String errorMsg) {
        return SPM_EMAIL_CONTENT1
                + SPM_EMAIL_CONTENT2 + olbPaymentId
                + SPM_EMAIL_CONTENT3 + paymentInfoId
                + "\n SPM Payment reference: N/A"
                + SPM_EMAIL_CONTENT4 + errorMsg
                + "\n\n Next steps:\n Please contact SPM Support team \"Group IT Wires Support <SDLITWiresSupport@svb.com>\" to check if the above payment (Payment information ID) reached SPM."
                + "\n If payment is available in SPM, no further action required. Else contact SVB Go Payment Tech or Product team to see if the payment can be re-triggered.";
    }

    public String buildSpmServiceFailedBody(Long olbPaymentId, String paymentInfoId, String errorMsg) {
        return SPM_EMAIL_CONTENT1
                + SPM_EMAIL_CONTENT2 + olbPaymentId
                + SPM_EMAIL_CONTENT3 + paymentInfoId
                + "\n SPM Payment reference: N/A"
                + SPM_EMAIL_CONTENT4 + errorMsg
                + "\n\n Next steps:\n Please contact SPM Support team \"Group IT Wires Support <SDLITWiresSupport@svb.com>\" and SVB Go Payment Tech or Product team to see if the payment can be re-triggered.";
    }
}

