package com.svb.gateway.payments.payment.service.retry;

import com.svb.gateway.payments.common.enums.ErrorCodeEnum;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.properties.PaymentProperties;
import com.svb.gateway.payments.common.service.GenericRestClient;
import com.svb.gateway.payments.common.util.HttpResponseContainer;
import com.svb.gateway.payments.payment.model.fxservices.FXStatusRequest;
import com.svb.gateway.payments.payment.model.fxservices.FXStatusResponse;
import com.svb.gateway.payments.payment.model.fxservices.FXTradeBookRequest;
import com.svb.gateway.payments.payment.model.fxservices.FXTradeBookResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.retry.RetryContext;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Recover;
import org.springframework.retry.annotation.Retryable;
import org.springframework.retry.support.RetrySynchronizationManager;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.net.http.HttpTimeoutException;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Component
@Slf4j
public class FxRetryComponent {

    private final PaymentProperties paymentProperties;
    private final GenericRestClient genericRestClient;

    public FxRetryComponent(PaymentProperties paymentProperties,
                            GenericRestClient genericRestClient) {
        this.paymentProperties = paymentProperties;
        this.genericRestClient = genericRestClient;
    }

    /**
     * Call to FX service to book quote
     *
     * @param request FXTradeBookRequest
     * @param context PaymentContext
     * @return FXTradeBookResponse
     * @throws HttpTimeoutException    h
     * @throws PaymentServiceException p
     */
    @Retryable(exceptionExpression = "@customHttpTimeoutRetryChecker.shouldRetry(#root)",
            backoff = @Backoff(delay = 1000, multiplier = 2),
            maxAttempts = 2,
            recover = "retryBookQuoteTimeout")
    public FXTradeBookResponse bookQuote(FXTradeBookRequest request, PaymentContext context) throws PaymentServiceException {
        Integer retryCount = Optional.ofNullable(RetrySynchronizationManager.getContext())
                .map(RetryContext::getRetryCount)
                .orElse(0);

        Map<String, String> headers = new HashMap<>();
        headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        headers.put(HttpHeaders.AUTHORIZATION, paymentProperties.getFxAuthToken());

        String url = paymentProperties.getFxTradePurchaseUrl() + "/book";
        log.info("FX book:: url {}, request {}, {}", url, request.log(), context.log());
        HttpResponseContainer<FXTradeBookResponse> response = genericRestClient.post(url, request,
                FXTradeBookResponse.class, Duration.ofSeconds(30L), headers, false
        );

        if (response.getStatusCode().is2xxSuccessful()) {
            if (response.getSuccessResponse().getErrorCode() == null) {
                return response.getSuccessResponse();
            } else {
                log.error("FX book::failure {}, attempt {}, response {}, {}", response.getSuccessResponse().getErrorCode(), retryCount,
                        response.getSuccessResponse(), context.log());
                throw new PaymentServiceException(ErrorCodeEnum.FX_BOOK_CONTRACT_ERROR, String.format("FX book failed with %s", response.getSuccessResponse().getErrorCode()));
            }
        } else {
            log.error("FX book::failure {}, attempt {}, error {}, {}", response.getStatusCode(), retryCount,
                    response.getErrorResponse(), context.log());
            throw new PaymentServiceException(ErrorCodeEnum.FX_BOOK_CONTRACT_ERROR, String.format("FX book failed with status %s", response.getStatusCode()));
        }
    }

    @Retryable(exceptionExpression = "@customPaymentServiceExceptionRetryChecker.shouldRetry(#root)",
            recover = "recoverFromContractRefTimeout",
            backoff = @Backoff(delay = 5000))
    public String contractReference(FXStatusRequest fxStatusRequest) throws PaymentServiceException {
        FXStatusResponse fxStatusResponse = null;

        Map<String, String> headers = new HashMap<>();
        headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        headers.put(HttpHeaders.AUTHORIZATION, paymentProperties.getFxAuthToken());
        HttpResponseContainer<FXStatusResponse> response = genericRestClient.post(paymentProperties.getFxTradePurchaseUrl() + "/status",
                fxStatusRequest,
                FXStatusResponse.class,
                Duration.ofSeconds(60L),
                headers,
                false);

        if (HttpStatus.OK.value() == response.getStatusCode().value()
                || HttpStatus.BAD_REQUEST.value() == response.getStatusCode().value()) {
            fxStatusResponse = response.getSuccessResponse();
            log.info(fxStatusResponse.getErrorCode() == null ?
                    "Received FX Status Response => Contract Reference No = " + fxStatusResponse.getContractReference() :
                    "Received FX Status Error Response => errorCode = " + fxStatusResponse.getErrorCode() + " and errorDescription = "
                            + fxStatusResponse.getErrorDescription());
        }

        if (fxStatusResponse == null || !StringUtils.hasLength(fxStatusResponse.getContractReference())) {
            throw new PaymentServiceException(ErrorCodeEnum.FX_SERVICE_CONTRACT_REF_NOT_FOUND,
                    ErrorCodeEnum.FX_SERVICE_CONTRACT_REF_NOT_FOUND.getDescription());
        }

        return fxStatusResponse.getContractReference();
    }

    @Recover
    public String recoverFromContractRefTimeout(PaymentServiceException ex, FXStatusRequest fxStatusRequest) throws PaymentServiceException {
        throw new PaymentServiceException(ErrorCodeEnum.FX_RUNTIME_SERVICE_ERROR, ex);
    }

    @Recover
    public FXTradeBookResponse retryBookQuoteTimeout(PaymentServiceException e) throws PaymentServiceException {
        log.error("Timeout while booking trade {} after 2 attempts", e.getMessage(), e);
        throw new PaymentServiceException(ErrorCodeEnum.HOST_CALL_FAILURE, "WSS call timeout after 2 attempts", e);
    }
}
