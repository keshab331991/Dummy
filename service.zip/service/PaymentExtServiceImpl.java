package com.svb.gateway.payments.payment.service;

import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.PayeePayment;
import com.svb.gateway.payments.common.model.payment.PaymentDetail;
import com.svb.gateway.payments.common.model.payment.PaymentSearchCriteria;
import com.svb.gateway.payments.common.service.payment.IPaymentExtService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaymentExtServiceImpl implements IPaymentExtService {

    private final PaymentService paymentsService;

    public PaymentExtServiceImpl(PaymentService paymentsService) {
        this.paymentsService = paymentsService;
    }

    @Override
    public List<PaymentDetail> getLastTransactions(PaymentSearchCriteria criteria) {
        PaymentContext paymentContext = new PaymentContext();
        paymentContext.setClientId(criteria.getClientId());

        RequestData<PaymentSearchCriteria> requestData = new RequestData<>(criteria, paymentContext);
        return paymentsService.fetchPaymentsTransactions(requestData);
    }

    @Override
    public List<PayeePayment> getPayments(PaymentSearchCriteria criteria) {
        PaymentContext paymentContext = new PaymentContext();
        paymentContext.setClientId(criteria.getClientId());

        RequestData<PaymentSearchCriteria> requestData = new RequestData<>(criteria, paymentContext);
        return paymentsService.fetchPayments(requestData);
    }
}
