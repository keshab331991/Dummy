package com.svb.gateway.payments.payment.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.svb.gateway.payments.common.alert.GatewayAlert;
import com.svb.gateway.payments.common.alert.util.AlertEnum;
import com.svb.gateway.payments.common.client.ApigeeAuthTokenEnum;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.model.payment.PaymentMode;
import com.svb.gateway.payments.common.model.payment.WirePaymentProcessingData;
import com.svb.gateway.payments.common.model.payment.payinit.PaymentRequest;
import com.svb.gateway.payments.common.model.payment.payinit.PaymentResponse;
import com.svb.gateway.payments.common.service.ApigeeTokenService;
import com.svb.gateway.payments.common.service.mail.EmailService;
import com.svb.gateway.payments.common.util.HttpResponseContainer;
import com.svb.gateway.payments.payment.entity.PaymentTransactionErrorEntity;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.mapper.model.PayInitRequestMapper;
import com.svb.gateway.payments.payment.service.retry.SpmServiceRetryComponent;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static com.svb.gateway.payments.common.util.PaymentConstant.*;

@Service
@Slf4j
public class SpmService {
    private final ApigeeTokenService apigeeTokenService;
    private final PayInitRequestMapper payInitRequestMapper;
    private final TransactionEntryDBMapper transactionEntryDBMapper;
    private final SpmServiceRetryComponent spmService;
    private final EmailService emailService;
    private final ObjectMapper objectMapper;

    public SpmService(ApigeeTokenService apigeeTokenService,
                      PayInitRequestMapper payInitRequestMapper,
                      TransactionEntryDBMapper transactionEntryDBMapper,
                      SpmServiceRetryComponent spmService,
                      EmailService emailService,
                      ObjectMapper objectMapper) {
        this.apigeeTokenService = apigeeTokenService;
        this.payInitRequestMapper = payInitRequestMapper;
        this.transactionEntryDBMapper  = transactionEntryDBMapper;
        this.spmService = spmService;
        this.emailService = emailService;
        this.objectMapper = objectMapper;
    }

    @GatewayAlert(alertEnum = AlertEnum.SVB_PYPRNR)
    public PaymentResponse sendWirePaymentToSpm(WirePaymentProcessingData wirePayment, PaymentMode paymentMode) throws PaymentServiceException {
        PaymentRequest paymentRequest = payInitRequestMapper.convertWirePaymentToPayInitRequest(wirePayment, paymentMode);
        // Here log the request SPM Request if debug is enabled
        if(log.isDebugEnabled()) {
            try {
                String paymentRequestMessage = objectMapper.writeValueAsString(paymentRequest);
                log.debug("SPM Payment Transaction Id:{}, Request Payload :{}", wirePayment.getPaymentData().getTxRefNum(),
                        paymentRequestMessage);
            }catch (JsonProcessingException e) {
                throw new RuntimeException(e);
            }
        }
        String accessToken = apigeeTokenService.getApigeeAuthToken(ApigeeAuthTokenEnum.SPM_CLIENT);
        String olbPaymentId = wirePayment.getPaymentData().getTxRefNum();

        Map<String, String> headers = new HashMap<>();
        headers.put("x-idempotency-key", UUID.randomUUID().toString());
        headers.put("x-svb-correlation-id", UUID.randomUUID().toString());
        headers.put(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        headers.put(HttpHeaders.AUTHORIZATION, BEARER.concat(" " + accessToken));

        PaymentResponse paymentResponse = new PaymentResponse();

        try {
            HttpResponseContainer<PaymentResponse> httpResponseContainer = spmService.initiateSpmPayment(paymentRequest, headers, olbPaymentId, wirePayment.getPaymentHeader().getContext());
            if (null != httpResponseContainer) {
                if (httpResponseContainer.getStatusCode().is2xxSuccessful()) {
                    log.info("{} payment submitted with payment_ref_id:{}, payment_info_id:{}, state:{} and transaction_id:{}",
                            wirePayment.getPaymentData().getPaymentType(),
                            httpResponseContainer.getSuccessResponse().getPaymentReferenceId(),
                            httpResponseContainer.getSuccessResponse().getPaymentInformationId(),
                            httpResponseContainer.getSuccessResponse().getState(),
                            olbPaymentId);
                    return httpResponseContainer.getSuccessResponse();
                } else if (httpResponseContainer.getStatusCode() == HttpStatus.BAD_REQUEST) {
                    String message = httpResponseContainer.getStatusCode() + httpResponseContainer.getErrorResponse().replaceAll(SPM_MESSAGE_REGEX, "");
                    log.info("Error BAD REQUEST Response Received from SPM: Transaction Id:{}, Error Message {}",
                            wirePayment.getPaymentData().getTxRefNum(), message);
                    String paymentRefId = new JSONObject(httpResponseContainer.getErrorResponse()).getString("payment_reference_id");
                    Optional.ofNullable(paymentRefId).ifPresent(paymentResponse::setPaymentReferenceId);
                    handlerConsumerError(olbPaymentId,
                            wirePayment.getPaymentData().getPaymentType(),
                            paymentRequest.getPaymentInformationId(),
                            paymentRefId,
                            message);
                } else {
                    String message = httpResponseContainer.getStatusCode() + httpResponseContainer.getErrorResponse().replaceAll(SPM_MESSAGE_REGEX, "");
                    log.info("Error Response Received from SPM: Transaction Id:{}, Error Message {}",
                            wirePayment.getPaymentData().getTxRefNum(), message);
                    log.info("An email alert has been sent to App Support team for the payment Info Id:{}", paymentRequest.getPaymentInformationId());
                    handlerConsumerError(olbPaymentId,
                            wirePayment.getPaymentData().getPaymentType(),
                            paymentRequest.getPaymentInformationId(),
                            "NA",
                            message);
                }
            } else {
                log.info("Error Response Received from Payment Search API for TxRefNum:{}", olbPaymentId);
            }
        } catch (PaymentServiceException pse) {
            log.error("SPM Service failed with PaymentServiceException", pse);
        }
        return paymentResponse;
    }

    private void handlerConsumerError(String olbPaymentId,
                                      String paymentType,
                                      String paymentInfoId,
                                      String paymentReferenceId,
                                      String errorMsg) {
        PaymentTransactionErrorEntity errorEntity = new PaymentTransactionErrorEntity();
        errorEntity.setPaymentTransId(olbPaymentId);
        errorEntity.setPaymentType(paymentType);
        errorEntity.setErrorMsg(errorMsg.length() > 2000 ? errorMsg.substring(0, 2000) : errorMsg);

        transactionEntryDBMapper.updateError(errorEntity);
        String spmServiceFailedSubject = "SVB Go - SPM Payment Processing Failed - " + paymentInfoId;
        String spmTransformationFailedBody = buildSpmServiceFailedBody(olbPaymentId, paymentInfoId, paymentReferenceId, errorMsg);
        emailService.sendEmail(spmServiceFailedSubject, spmTransformationFailedBody);
    }

    public String buildSpmServiceFailedBody(String olbPaymentId,
                                            String paymentInfoId,
                                            String paymentRefId,
                                            String errorMsg) {
        return SPM_EMAIL_CONTENT1
                + SPM_EMAIL_CONTENT2 + olbPaymentId
                + SPM_EMAIL_CONTENT3 + paymentInfoId
                + "\n SPM Payment reference: " + (StringUtils.hasLength(paymentRefId) ? paymentRefId : "NA")
                + SPM_EMAIL_CONTENT4 + errorMsg
                + "\n\n Next steps:\n Please contact SPM Support team \"Group IT Wires Support <SDLITWiresSupport@svb.com>\" and SVB Go Payment Tech or Product team to see if the payment can be re-triggered.";
    }
}
