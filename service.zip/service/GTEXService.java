package com.svb.gateway.payments.payment.service;

import com.svb.gateway.payments.common.properties.GtexProperties;
import com.svb.gateway.payments.common.service.GenericRestClient;
import com.svb.gateway.payments.common.util.HttpResponseContainer;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.payment.model.gtex.GTEXPaymentStatusResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class GTEXService {
    private final GtexProperties gtexProperties;
    private final GenericRestClient genericRestClient;

    public GTEXService(GtexProperties gtexProperties, GenericRestClient genericRestClient) {
        this.gtexProperties = gtexProperties;
        this.genericRestClient = genericRestClient;
    }

    public String getE2EStatus(String dealNumber) {
        String requestBody = "{" +
                "  \"SourceRefID\" :\"" + dealNumber + "\",\n" +
                "  \"Type\" : \"\"\n" +
                "}";

        Map<String, String> headerMap = new HashMap<>();

        log.info("requestBody = {}", requestBody);
        String auth = gtexProperties.getUserName() + ":" + gtexProperties.getPassword();
        byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(StandardCharsets.ISO_8859_1));
        String authHeader = "Basic " + new String(encodedAuth);

        headerMap.put(HttpHeaders.AUTHORIZATION, authHeader);
        headerMap.put(PaymentConstant.REQ_PRINCIPAL_HEADER, gtexProperties.getReqPrincipal());
        headerMap.put(PaymentConstant.METHOD_HEADER, gtexProperties.getMethod());
        headerMap.put(PaymentConstant.SERVICE_ID_HEADER, gtexProperties.getServiceID());

        log.info("Sending request to GTEX payment status is :: {}", requestBody);


        try {
            HttpResponseContainer<GTEXPaymentStatusResponse> response = genericRestClient.post(gtexProperties.getUrl(),
                    requestBody,
                    GTEXPaymentStatusResponse.class,
                    Duration.ofSeconds(10L),
                    headerMap,
                    false);
            if(response.getStatusCode()  == HttpStatus.OK) {
                return response.getSuccessResponse().Message;
            }else {
                log.info("Error occurred when retrieving GTEX payment status. Message: {}", response.getErrorResponse());
            }
        } catch (Exception e) {
            log.error("Error occurred when retrieving GTEX payment status. Message: {}", e.getMessage());
        }
        return null;
    }
}
