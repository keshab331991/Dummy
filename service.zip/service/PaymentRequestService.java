package com.svb.gateway.payments.payment.service;

import com.svb.gateway.payments.common.model.payment.approvals.ApprovalsSubmitResponse;
import com.svb.gateway.payments.common.model.payment.processing.PaymentProcessingData;
import com.svb.gateway.payments.payment.mapper.db.PaymentRequestDBMapper;
import com.svb.gateway.payments.common.constants.CommonConstant;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.List;

@Service
@Slf4j
public class PaymentRequestService {
    private final PaymentRequestDBMapper paymentRequestDBMapper;

    public PaymentRequestService(PaymentRequestDBMapper paymentRequestDBMapper) {
        this.paymentRequestDBMapper = paymentRequestDBMapper;
    }

    public Long updateApprovalWorkFlow(String paymentReqId,
                                       ApprovalsSubmitResponse.ApprovalDetails approvalDetails) {
        return paymentRequestDBMapper.updateApprovalCallBack(paymentReqId,
                approvalDetails.getWorkflowId(),
                approvalDetails.getCurrentState());
    }

    public String getDuplicatePayment(String clientId, String userId,
                                      List<PaymentProcessingData> paymentList) {
        String paymentId = CommonConstant.EMPTY;

        if (!CollectionUtils.isEmpty(paymentList)) {
            PaymentProcessingData paymentData = paymentList.getFirst();
            log.info("Trying to fetch the duplicate payment details : Client Id :{}, " +
                            "User Id :{}, Payment date:{}, Transaction Currency:{}," +
                            "Transaction Amount:{}, Payee Type:{}",
                    clientId, userId, paymentData.getProcessingDate(),
                    paymentData.getTransactionCcy(),
                    paymentData.getTransactionAmt(),
                    paymentData.getPayeeType() != null ? paymentData.getPayeeType().name() : null);

            paymentId = paymentRequestDBMapper.getDuplicatePayment(clientId, userId,
                    paymentData.getProcessingDate(),
                    paymentData.getTransactionCcy(),
                    paymentData.getTransactionAmt(),
                    paymentData.getPayeeType() != null ? paymentData.getPayeeType().name() : null,
                    "");
            log.info("The duplicate call response. Payment Id:{}", paymentId);
        }
        return paymentId;
    }
}

