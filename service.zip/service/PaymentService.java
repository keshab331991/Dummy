package com.svb.gateway.payments.payment.service;

import com.svb.gateway.payments.common.alert.GatewayAlert;
import com.svb.gateway.payments.common.alert.util.AlertEnum;
import com.svb.gateway.payments.common.audit.GatewayAudit;
import com.svb.gateway.payments.common.audit.util.enums.AuditEventEnum;
import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.ApprovalStateEnum;
import com.svb.gateway.payments.common.enums.payment.PaymentStatus;
import com.svb.gateway.payments.common.enums.payment.PaymentType;
import com.svb.gateway.payments.common.exception.CollectException;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.model.MetaData;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.approvals.ApprovalData;
import com.svb.gateway.payments.common.model.payment.*;
import com.svb.gateway.payments.common.model.payment.cancellation.PaymentCancellationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.service.ApprovalsService;
import com.svb.gateway.payments.common.service.PayeeIntegrationService;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.payment.service.manager.PaymentManager;
import com.svb.gateway.payments.payment.service.manager.PaymentManagerFactory;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.camel.Header;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Slf4j
@Service
public class PaymentService {

    private final PaymentManagerFactory paymentManagerFactory;
    private final PayeeIntegrationService payeesService;
    private final ApprovalsService approvalsService;
    private final PaymentStatusUtil paymentStatusUtil;
    private final DateUtil dateUtil;

    public PaymentService(PaymentManagerFactory paymentManagerFactory,
                          PayeeIntegrationService payeesService,
                          ApprovalsService approvalsService,
                          DateUtil dateUtil,
                          PaymentStatusUtil paymentStatusUtil) {
        this.paymentManagerFactory = paymentManagerFactory;
        this.payeesService = payeesService;
        this.approvalsService = approvalsService;
        this.dateUtil = dateUtil;
        this.paymentStatusUtil = paymentStatusUtil;
    }

    /**
     * Retrieve payment details
     *
     * @param requestData RequestData
     * @return PaymentDetailResponse
     */
    @GatewayAudit(eventEnum = AuditEventEnum.TRANSACTION_DETAILS)
    public PaymentDetailResponse retrievePaymentDetails(RequestData<?> requestData) {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();

        Map<String, Object> properties = requestData.getProperties();
        long paymentId = (long) properties.get(CommonConstant.PAYMENT_ID);
        long transactionId = 0;
        if (properties.get(CommonConstant.TRANSACTION_ID) != null) {
            transactionId = (long) properties.get(CommonConstant.TRANSACTION_ID);
        }
        PaymentManager paymentManager = paymentManagerFactory.getPaymentManager(null);
        PaymentDetailResponse response = paymentManager.retrieve(context, paymentId, transactionId);
        log.info("payment retrieved::{}", context.log());
        return response;
    }

    /**
     * Populate debit account details
     * Populate credit account for transfer payment types
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return RequestData<PaymentInitiationData>
     * @throws PaymentServiceException ex
     */
    @CollectException
    public RequestData<PaymentInitiationData> fetchAccountDetails(RequestData<PaymentInitiationData> requestData)
            throws PaymentServiceException {
        PaymentManager paymentManager = paymentManagerFactory.getPaymentManager(requestData.getRequest().getPaymentType());
        // populate account
        paymentManager.populateAccountDetails(requestData);
        log.info("accounts fetched::{}", requestData.getGatewayContext().log());
        return requestData;
    }

    /**
     * Populate bank details for debit account
     * Populate bank details for credit account for transfer payment types
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return RequestData<PaymentInitiationData>
     */
    @CollectException
    public RequestData<PaymentInitiationData> getBankDetails(RequestData<PaymentInitiationData> requestData) {
        PaymentManager paymentManager = paymentManagerFactory.getPaymentManager(requestData.getRequest().getPaymentType());
        // populate debit bank
        paymentManager.populateBankDetails(requestData);
        log.info("bank details fetched::{}", requestData.getGatewayContext().log());
        return requestData;
    }

    /**
     * Fetch payee details for the payee id and payment method
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return RequestData<PaymentInitiationData>
     * @throws PaymentServiceException ex
     */
    @CollectException
    public RequestData<PaymentInitiationData> populatePayeeDetails(RequestData<PaymentInitiationData> requestData)
            throws PaymentServiceException {
        boolean isTransfer = CommonConstant.TRANSFER_TYPES.contains(requestData.getRequest().getPaymentType().toString());
        // no action required
        if (isTransfer) {
            return requestData;
        }
        payeesService.populatePayeeDetails((PaymentContext) requestData.getGatewayContext(), requestData.getRequest());
        log.info("payee details fetched::{}", requestData.getGatewayContext().log());
        return requestData;
    }

    /**
     * Validate payment request data
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return RequestData<PaymentInitiationData>
     */
    @CollectException
    public RequestData<PaymentInitiationData> validatePayment(RequestData<PaymentInitiationData> requestData, @Header("operation") String operation)
            throws PaymentServiceException {
        PaymentManager paymentManager;
        PaymentInitiationData initiationData = requestData.getRequest();
        if (CommonConstant.OPERATION_CREATE.equals(operation)) {
            initiationData.setOperation(CommonConstant.OPERATION_CREATE);
            initiationData.setPaymentId(0);
        } else {
            initiationData.setOperation(CommonConstant.OPERATION_UPDATE);
        }
        paymentManager = paymentManagerFactory.getPaymentManager(initiationData.getPaymentType());
        paymentManager.validatePayment(requestData, operation);
        log.info("payment validated successfully::{}", requestData.getGatewayContext().log());
        return requestData;
    }

    @CollectException
    public RequestData<PaymentCancellationData> validateCancelPayment(RequestData<PaymentCancellationData> requestData) throws PaymentServiceException {
        PaymentCancellationData cancellationData = requestData.getRequest();
        PaymentManager paymentManager = paymentManagerFactory.getPaymentManager(cancellationData.getPaymentType());
        paymentManager.validatePayment(cancellationData, (PaymentContext) requestData.getGatewayContext());
        log.info("Validate cancel payment successfully::{}", requestData.getGatewayContext().log());
        return requestData;
    }

    @CollectException
    public RequestData<UpdatePaymentStatusRequest> validateStatusUpdate(RequestData<UpdatePaymentStatusRequest> requestData) throws PaymentServiceException {
        UpdatePaymentStatusRequest updateRequest = requestData.getRequest();
        PaymentManager paymentManager = paymentManagerFactory.getPaymentManager(updateRequest.getPaymentType());
        paymentManager.validatePayment(updateRequest, (PaymentContext) requestData.getGatewayContext());
        log.info("Validate status update successfully::{}", requestData.getGatewayContext().log());
        return requestData;
    }

    /**
     * Create payment
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return RequestData<PaymentInitiationData>
     */
    @GatewayAlert(alertEnum = AlertEnum.SVB_PYSCER)
    @GatewayAudit(eventEnum = AuditEventEnum.INITIATE_PAYMENT)
    @Transactional(rollbackFor = Exception.class)
    public RequestData<PaymentInitiationData> initiatePayment(RequestData<PaymentInitiationData> requestData)
            throws PaymentServiceException {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        MetaData metaData = new MetaData();
        metaData.setCreatedBy(context.getUserId());
        metaData.setUpdatedBy(context.getUserId());
        requestData.getRequest().setMetaInfo(metaData);
        PaymentManager manager = paymentManagerFactory.getPaymentManager(requestData.getRequest().getPaymentType());
        // create payment
        manager.createPayment(requestData);
        log.info("payment created successfully::{}", context.log());
        return requestData;
    }

    /**
     * Post payment to host
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return RequestData<PaymentInitiationData>
     */
    public RequestData<PaymentInitiationData> postPayment(RequestData<PaymentInitiationData> requestData) {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        try {
            PaymentManager paymentManager = paymentManagerFactory.getPaymentManager(requestData.getRequest().getPaymentType());
            // post payment
            paymentManager.postPayment(requestData);
            log.info("payment posted successfully::{}", context.log());
        } catch (Exception e) {
            log.error("payment posting failed::{}, {}", e.getMessage(), context.log(), e);
        }
        return requestData;
    }

    /**
     * Check for approval flow and accordingly
     * Create approval workflow and update payment status, workflowId
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    public RequestData<PaymentInitiationData> checkApprovalWorkflow(RequestData<PaymentInitiationData> requestData)
            throws PaymentServiceException {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        boolean approvalRequired = approvalsService.checkWorkflow(context, requestData.getRequest());
        context.setApprovalFlag(approvalRequired);
        log.info("approval check completed::{}", context.log());
        return requestData;
    }

    /**
     * Create an approval workflow and update payment status, workflowId
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    @GatewayAlert(alertEnum = AlertEnum.SVB_PYPDA)
    @GatewayAudit(eventEnum = AuditEventEnum.INITIATE_PAYMENT_APPROVAL)
    public RequestData<PaymentInitiationData> initiateApprovalWorkflow(RequestData<PaymentInitiationData> requestData)
            throws PaymentServiceException {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        PaymentManager manager = paymentManagerFactory.getPaymentManager(requestData.getRequest().getPaymentType());
        // create approval
        approvalsService.initiateWorkflow(context, requestData.getRequest());
        // update status
        manager.approvalCallbackOn(requestData);
        log.info("approval initiated::{}", context.log());
        return requestData;
    }

    /**
     * Edit payment
     * -    for recurring - single instance edit, a new payment gets created
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return RequestData<PaymentInitiationData>
     * @throws PaymentServiceException e
     */
    @GatewayAlert(alertEnum = AlertEnum.SVB_PYMOD)
    @GatewayAudit(eventEnum = AuditEventEnum.MODIFY_PAYMENT)
    public RequestData<PaymentInitiationData> initiatePaymentModification(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        PaymentManager manager = paymentManagerFactory.getPaymentManager(requestData.getRequest().getPaymentType());
        MetaData metaData = new MetaData();
        metaData.setCreatedBy(context.getUserId());
        metaData.setUpdatedBy(context.getUserId());
        requestData.getRequest().setMetaInfo(metaData);
        // update payment
        manager.editPayment(requestData);
        log.info("payment modified::{}", context.log());
        return requestData;
    }

    /**
     * Cancel payment
     *
     * @param requestData RequestData<PaymentCancellationData>
     * @return RequestData<PaymentCancellationData>
     * @throws PaymentServiceException e
     */
    @GatewayAlert(alertEnum = AlertEnum.SVB_PYCAN)
    @GatewayAudit(eventEnum = AuditEventEnum.CANCEL_PAYMENT)
    public RequestData<PaymentCancellationData> initiatePaymentCancellation(RequestData<PaymentCancellationData> requestData)
            throws PaymentServiceException {
        /*Transactional is specified at manager level as this flow could
         * involve bill-pay host call*/
        PaymentManager manager = paymentManagerFactory.getPaymentManager(requestData.getRequest().getPaymentType());
        // cancel payment
        manager.cancelPayment(requestData);
        log.info("payment cancelled::{}", requestData.getGatewayContext().log());
        return requestData;
    }

    /**
     * Canceled payments for specific accounts (when service entitlement is removed)
     *
     * @param context             PaymentContext
     * @param paymentTypeAccounts HashMap<String, List<String>>
     */
    public void initiatePaymentCancellation(PaymentContext context, HashMap<String, List<String>> paymentTypeAccounts) {
        PaymentManager manager = paymentManagerFactory.getPaymentManager(null);
        // cancel payment
        manager.cancelPayments(context, paymentTypeAccounts);
        log.info("payments cancelled::service removed{}", context.log());
    }

    public void initiatePaymentCancellation(PaymentContext context, String account) {
        PaymentManager manager = paymentManagerFactory.getPaymentManager(null);
        // cancel payment
        manager.cancelPayments(context, account);
        log.info("payments cancelled::account closed{}", context.log());
    }

    public RequestData<UpdatePaymentStatusRequest> initiatePaymentStatusUpdate(RequestData<UpdatePaymentStatusRequest> requestData) {
        PaymentManager manager = paymentManagerFactory.getPaymentManager(requestData.getRequest().getPaymentType());
        // update status
        manager.updateTransactionStatus(requestData.getRequest().getPaymentData(), (PaymentContext) requestData.getGatewayContext());
        log.info("payment status updated::{}", requestData.getGatewayContext().log());
        return requestData;
    }

    /**
     * Revert limits
     *
     * @param requestData RequestData
     * @param operation   String
     * @return RequestData
     * @throws PaymentServiceException e
     */
    public RequestData<?> revertLimits(RequestData<?> requestData, String operation)
            throws PaymentServiceException {
        PaymentManager paymentManager;
        log.info("reverting limits for operation::{}", operation);
        if (CommonConstant.OPERATION_CANCEL.equals(operation)) {
            PaymentCancellationData cancellationData = (PaymentCancellationData) requestData.getRequest();
            paymentManager = paymentManagerFactory.getPaymentManager(cancellationData.getPaymentType());
            paymentManager.revertLimits(cancellationData, (PaymentContext) requestData.getGatewayContext());
        } else {
            PaymentInitiationData initiationData = (PaymentInitiationData) requestData.getRequest();
            paymentManager = paymentManagerFactory.getPaymentManager(initiationData.getPaymentType());
            paymentManager.revertLimits(initiationData, (PaymentContext) requestData.getGatewayContext());
        }
        log.info("limit reverted::{}", requestData.getGatewayContext().log());
        return requestData;
    }

    /**
     * Check payment request for duplicity
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return DuplicateCheckResponse
     * @throws PaymentServiceException e
     */
    public DuplicateCheckResponse duplicatePaymentCheck(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        PaymentManager paymentManager = paymentManagerFactory.getPaymentManager(null);
        DuplicateCheckResponse response = paymentManager.duplicateCheck(requestData);
        log.info("payment checked::{}", requestData.getGatewayContext().log());
        return response;
    }

    /**
     * Retrieves a list of payments based on the provided search criteria.
     *
     * @param requestData the request data containing the payment search criteria
     * @return a list of PaymentDetail objects matching the search criteria
     */
    public List<PaymentDetail> fetchPaymentsTransactions(RequestData<PaymentSearchCriteria> requestData) {
        PaymentManager paymentManager = paymentManagerFactory.getPaymentManager(null);
        List<PaymentDetail> list = paymentManager.fetchPaymentsTransactions(requestData.getRequest());
        log.info("payment-transaction fetched::{}", requestData.getGatewayContext().log());
        return list;
    }

    public List<PayeePayment> fetchPayments(RequestData<PaymentSearchCriteria> requestData) {
        PaymentManager paymentManager = paymentManagerFactory.getPaymentManager(null);
        List<PayeePayment> list = paymentManager.fetchPayments(requestData.getRequest());
        log.info("payee payment fetched::{}", requestData.getGatewayContext().log());
        return list;
    }

    /**
     * Process payment approval and rejection, create transaction if criteria satisfied
     *
     * @param context      PaymentContext
     * @param approvalData ApprovalData
     * @throws PaymentServiceException e
     */
    @GatewayAudit(eventEnum = AuditEventEnum.APPROVE_PAYMENT)
    @GatewayAlert(alertEnum = AlertEnum.SVB_PYREJ)
    public void processApprovalWorkflow(PaymentContext context, ApprovalData approvalData) throws PaymentServiceException {
        PaymentType paymentType = PaymentType.fromValue(approvalData.getPaymentType());
        PaymentManager paymentManager = paymentManagerFactory.getPaymentManager(paymentType);

        // get payment
        PaymentInitiationData payment = paymentManager.populatePayment(Long.parseLong(approvalData.getEntityId()), context.getClientId());
        if ((int) payment.getWorkflowId() != approvalData.getWorkflowId()) {
            log.error("payment approval error:: invalid payment data {}", context.log());
            return;
        }
        // validate payment
        RequestData<PaymentInitiationData> requestData = new RequestData<>(payment, context);
        ApprovalStateEnum stateEnum = ApprovalStateEnum.fromValue(approvalData.getCurrentState());
        log.info(" Processing processApprovalWorkflow : State : {}", stateEnum != null ? stateEnum.name() : CommonConstant.EMPTY);
        if (stateEnum == null) {
            log.error("payment approval error:: approval status is invalid {} {}", approvalData.getCurrentState(), context.log());
            return;
        }
        switch (stateEnum) {
            case REJECTED:
                paymentManager.validatePayment(requestData, PaymentStatus.REJC);
                requestData.getRequest().setPaymentStatus(PaymentStatus.REJC);
                paymentManager.rejectPayment(requestData);
                log.info("payment rejected::{}", context.log());
                approvalData.setAdditionalData(requestData.getRequest().getAdditionalData());
                break;
            case CANCELLED:
                PaymentStatus status = payment.getRecurringData().isRecurring() ? PaymentStatus.SCAN : PaymentStatus.CURP;
                paymentManager.validatePayment(requestData, status);
                payment.setPaymentStatus(status);
                paymentManager.cancelPayment(context, requestData.getRequest());
                log.info("payment cancelled(from approval)::{}", context.log());
                approvalData.setAdditionalData(requestData.getRequest().getAdditionalData());
                break;
            case NEED_APPROVAL:
                requestData.getRequest().setHold(true);
                paymentManager.validatePayment(requestData, PaymentStatus.PNAP);
                requestData.getRequest().setPaymentStatus(PaymentStatus.PNAP);
                paymentManager.approvePayment(requestData);
                log.info("payment approved::approval status PNAP {}", context.log());
                approvalData.setAdditionalData(requestData.getRequest().getAdditionalData());
                break;
            case NEED_FINAL_APPROVAL:
                requestData.getRequest().setHold(true);
                paymentManager.validatePayment(requestData, PaymentStatus.PNFA);
                requestData.getRequest().setPaymentStatus(PaymentStatus.PNFA);
                paymentManager.approvePayment(requestData);
                log.info("payment approved::approval status PNFA {}", context.log());
                approvalData.setAdditionalData(requestData.getRequest().getAdditionalData());
                break;
            case ALL_APPROVALS_COMPLETED:
                paymentManager.validatePayment(requestData, PaymentStatus.ACMP);
                requestData.getRequest().setPaymentStatus(PaymentStatus.ACMP);
                // update request
                updateRequest(approvalData, requestData);
                paymentManager.populateAccountDetails(requestData);
                paymentManager.populateBankDetails(requestData);
                paymentManager.validatePayment(requestData, CommonConstant.OPERATION_APPROVE);
                paymentManager.approvePayment(requestData);
                paymentManager.postPayment(requestData);
                approvalData.setAdditionalData(requestData.getRequest().getAdditionalData());
                log.info("payment approved::approval status {} {}", requestData.getRequest().getPaymentStatus(), context.log());
                break;
        }
        // publish updates to ES
        paymentStatusUtil.publishUpdateToPS(Optional.ofNullable(requestData.getRequest()).map(PaymentInitiationData::getPaymentId).orElse(0L),  null);
    }

    private void updateRequest(ApprovalData approvalData, RequestData<PaymentInitiationData> requestData) {
        requestData.getRequest().setRequestDate(dateUtil.getTimestamp(approvalData.getPaymentData().getFirst().getPaymentDate()));
        for (int i = 0; i < approvalData.getPaymentData().size(); i++) {
            if (approvalData.getPaymentData().get(i).getCrossCurrencyPaymentData() != null) {
                requestData.getRequest().getEntries().get(i).setCrossCurrencyPaymentData(approvalData.getPaymentData().get(i).getCrossCurrencyPaymentData());
            }
        }
    }
}

