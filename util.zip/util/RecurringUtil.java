package com.svb.gateway.payments.payment.util;

import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.ErrorCodeEnum;
import com.svb.gateway.payments.common.enums.payment.Frequency;
import com.svb.gateway.payments.common.exception.CollectException;
import com.svb.gateway.payments.common.exception.PaymentBadRequestException;
import com.svb.gateway.payments.common.exception.PaymentServiceException;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.payment.RecurringData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.util.CommonUtil;
import com.svb.gateway.payments.payment.validator.DateValidator;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;

import static com.svb.gateway.payments.common.util.PaymentConstant.US_TIME_ZONE;

@Service
public class RecurringUtil {

    private final DateValidator dateValidator;

    public RecurringUtil(DateValidator dateValidator) {
        this.dateValidator = dateValidator;
    }

    /**
     * Validate recurring details for different frequency types
     *
     * @param requestData RequestData<PaymentInitiationData>
     */
    @CollectException
    public void validateData(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        PaymentInitiationData paymentData = requestData.getRequest();

        // no check required
        if (paymentData.getRecurringData() == null
                || !paymentData.getRecurringData().isRecurring()) {
            paymentData.setRecurringData(new RecurringData());
            paymentData.getRecurringData().setRecurring(false);
            return;
        }

        RecurringData data = paymentData.getRecurringData();

        populateInstances(context, paymentData);
        if (paymentData.getNextPaymentDate() == null) {
            paymentData.setNextPaymentDate(getNextPaymentDate(paymentData.getPaymentDate(),
                    paymentData.getRecurringData().getPaymentFrequency(),
                    (paymentData.isHold() || context.isApprovalFlag())));
        }

        switch (data.getFrequencyType()) {
            case N_OCCURRENCES:
                if (data.getTotalInstances() < 2 || paymentData.getEndDate() != null) {
                    CommonUtil.raiseException(context, 1013, ErrorCodeEnum.INVALID_RECURRING_DETAILS,
                            "Total no of instances should be more than 2 and end date is not required.", null, false);
                }
                break;
            case END_DATE:
                if (paymentData.getEndDate() == null) {
                    CommonUtil.raiseException(context, 1014, ErrorCodeEnum.INVALID_RECURRING_DETAILS,
                            "End date is required.", null, false);
                }
                if (validateEndDate(requestData)) {
                    // calculate total no of instances
                    data.setTotalInstances(populateInstances(paymentData.getPaymentDate(),
                            paymentData.getEndDate(),
                            paymentData.getRecurringData().getPaymentFrequency()));
                } else {
                    data.setTotalInstances(0);
                }
                break;
            case ON_CANCELLATION:
                if (data.getTotalInstances() > 0 || paymentData.getEndDate() != null) {
                    CommonUtil.raiseException(context, 1017, ErrorCodeEnum.INVALID_RECURRING_DETAILS,
                            "End date is not required and total no of instances not required.", null, false);
                }
        }
    }

    /**
     * Populate current and total and processed instances
     *
     * @param context PaymentContext
     * @param data    PaymentInitiationData
     */
    private void populateInstances(PaymentContext context, PaymentInitiationData data) {
        if (data.getRecurringData().getTotalInstances() == null) {
            data.getRecurringData().setTotalInstances(0);
        }
        if (data.getRecurringData().getProcessedInstances() == null) {
            data.getRecurringData().setProcessedInstances(0);
        }
        if (!data.isHold() && !context.isApprovalFlag()) {
            int processedInstances = data.getRecurringData().getProcessedInstances() == null ?
                    0 : data.getRecurringData().getProcessedInstances();

            /* first condition is for very first instance,
             * second condition is to check if it's not incremented already
             * as part of populateRecurringDetails in the edit flow*/
            if (processedInstances == 0 || !data.getRecurringData().isSingleInstance()) {
                processedInstances = processedInstances + 1;
            }

            data.getRecurringData().setProcessedInstances(processedInstances);
            data.getRecurringData().setSeriesNumber(processedInstances);
        }
    }

    /**
     * Populate payment date depending on frequency
     *
     * @param paymentDate Timestamp
     * @param frequency   Frequency
     * @param noIncrement boolean
     * @return Timestamp
     */
    private Timestamp getNextPaymentDate(Timestamp paymentDate, Frequency frequency, boolean noIncrement) {
        // no action
        if (noIncrement) {
            return paymentDate;
        }

        LocalDateTime nextPaymentDateTime = paymentDate.toLocalDateTime();
        // calculate date
        nextPaymentDateTime = getNextDateTime(frequency, nextPaymentDateTime);
        // check for holiday
        nextPaymentDateTime = dateValidator.holidayCheck(US_TIME_ZONE, nextPaymentDateTime);
        // populate date
        return Timestamp.valueOf(LocalDateTime.parse(nextPaymentDateTime.toString()));
    }

    /**
     * Get total number of instances from end date
     *
     * @param paymentDate Timestamp
     * @param endDate     Timestamp
     * @param frequency   Frequency
     * @return int
     */
    private int populateInstances(Timestamp paymentDate, Timestamp endDate, Frequency frequency) {
        LocalDateTime nextPaymentDateTime = paymentDate.toLocalDateTime();
        int instances = 0;

        while (!nextPaymentDateTime.isAfter(endDate.toLocalDateTime())) {
            nextPaymentDateTime = getNextDateTime(frequency, nextPaymentDateTime);
            instances++;
        }
        return instances;
    }

    private LocalDateTime getNextDateTime(Frequency frequency, LocalDateTime nextPaymentDateTime) {
        nextPaymentDateTime = switch (frequency) {
            case _1 -> nextPaymentDateTime.plusDays(1);
            case _2 -> nextPaymentDateTime.plusWeeks(1);
            case _3 -> nextPaymentDateTime.plusWeeks(2);
            case _4 -> nextPaymentDateTime.plusMonths(1);
            case _9 -> nextPaymentDateTime.plusMonths(2);
            case _5 -> nextPaymentDateTime.plusMonths(3);
        };
        return nextPaymentDateTime;
    }

    /**
     * Check end date against request date
     *
     * @param requestData RequestData<PaymentInitiationData>
     * @return boolean
     */
    private boolean validateEndDate(RequestData<PaymentInitiationData> requestData) throws PaymentServiceException {
        boolean isValid = true;
        if (requestData.getRequest().getEndDate().before(requestData.getRequest().getRequestDate())) {
            CommonUtil.raiseException(requestData.getGatewayContext(), 1015, ErrorCodeEnum.INVALID_RECURRING_DETAILS,
                    "End date can not be less than request date.", null, false);
            isValid = false;
        } else if (requestData.getRequest().getEndDate().before(requestData.getRequest().getNextPaymentDate())) {
            CommonUtil.raiseException(requestData.getGatewayContext(), 1016, ErrorCodeEnum.INVALID_RECURRING_DETAILS,
                    "End date can not be less next payment date for first instance.", null, false);
            isValid = false;
        }
        return isValid;
    }

    /**
     * Populate recurring details
     * -    total instances
     * -    processed instances
     * -    next payment date
     * from an existing recurring details object
     *
     * @param requestData        RequestData<PaymentInitiationData>
     * @param nextPaymentDate    Timestamp
     * @param processedInstances int
     */
    public void populateRecurringDetails(RequestData<PaymentInitiationData> requestData,
                                         Timestamp nextPaymentDate,
                                         int processedInstances) {

        /* for a single instance update, processed instances will always be increased by 1 */
        if (requestData.getRequest().getRecurringData().isSingleInstance()) {
            processedInstances = processedInstances + 1;

            // next payment date, for instance
            nextPaymentDate = getNextPaymentDate(nextPaymentDate,
                    requestData.getRequest().getRecurringData().getPaymentFrequency(), false);

            requestData.getRequest().setNextPaymentDate(nextPaymentDate);
        } else if (requestData.getRequest().getRecurringData().getTotalInstances() != null
                && requestData.getRequest().getRecurringData().getTotalInstances() <= processedInstances) {
            throw new PaymentBadRequestException(ErrorCodeEnum.INVALID_RECURRING_DETAILS,
                    "Total number of instances must be greater than request date.");
        }
        requestData.getRequest().getRecurringData().setSeriesNumber(processedInstances);
        requestData.getRequest().getRecurringData().setProcessedInstances(processedInstances);
    }
}
