package com.svb.gateway.payments.payment.util;

import com.svb.gateway.payments.payment.entity.FXErrorInfoMappingEntity;
import com.svb.gateway.payments.payment.mapper.db.FXErrorInfoDBMapper;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class MetadataCache {

    private final FXErrorInfoDBMapper fxErrorInfoDbMapper;
    private final Map<String, FXErrorInfoMappingEntity> fxErrorInfoEntityList = new HashMap<>();

    public MetadataCache(FXErrorInfoDBMapper fxErrorInfoDbMapper) {
        this.fxErrorInfoDbMapper = fxErrorInfoDbMapper;
    }

    public FXErrorInfoMappingEntity getFxErrorInfoEntity(String errorCode) {
        FXErrorInfoMappingEntity fxErrorInfoMappingEntity = fxErrorInfoEntityList.get(errorCode);
        if (fxErrorInfoMappingEntity == null) {
            fxErrorInfoMappingEntity = fxErrorInfoDbMapper.findFXErrorEntityForErrorCode(errorCode);
            if (fxErrorInfoMappingEntity != null) {
                fxErrorInfoEntityList.put(errorCode, fxErrorInfoMappingEntity);
            }
            else{
                fxErrorInfoMappingEntity = new FXErrorInfoMappingEntity(errorCode, "Unrecognized Error Code", "An FX Specialist is required for this payment, please contact FX Client Support for assistance.", "N");
            }
        }
        return fxErrorInfoMappingEntity;
    }
}
