package com.svb.gateway.payments.payment.util;

import com.svb.gateway.payments.common.enums.TransactionStatusEnum;
import com.svb.gateway.payments.common.enums.payment.PaymentStatus;
import com.svb.gateway.payments.payment.elasticsearch.service.PaymentCenterService;
import com.svb.gateway.payments.payment.entity.PaymentEntity;
import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.entity.TransactionEntity;
import com.svb.gateway.payments.payment.mapper.db.PaymentDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Stream;

@Component
@Slf4j
public class PaymentStatusUtil {
    private final TransactionDBMapper transactionDBMapper;
    private final TransactionEntryDBMapper transactionEntryDBMapper;
    private final PaymentCenterService paymentCenterService;
    private final PaymentDBMapper paymentDBMapper;

    public PaymentStatusUtil(TransactionDBMapper transactionDBMapper,
                             TransactionEntryDBMapper transactionEntryDBMapper,
                             PaymentCenterService paymentCenterService,
                             PaymentDBMapper paymentDBMapper) {
        this.transactionDBMapper = transactionDBMapper;
        this.transactionEntryDBMapper = transactionEntryDBMapper;
        this.paymentCenterService = paymentCenterService;
        this.paymentDBMapper = paymentDBMapper;
    }

    public void updateEntireStatus(PaymentTransactionStatusEntity updateEntity, boolean publishToPS) {
        // update transaction entry
        transactionEntryDBMapper.updateTransactionEntryStatus(updateEntity);
        // update transaction
        transactionDBMapper.updateTransactionStatus(updateEntity);
        // update payment with or without payment center push
        updatePaymentForTransactionUpdate(updateEntity, publishToPS);
    }

    public void updateTransactionStatus(PaymentTransactionStatusEntity updateEntity, boolean publishToPS) {
        // update transaction
        transactionDBMapper.updateTransactionStatus(updateEntity);
        // update payment with or without payment center push
        updatePaymentForTransactionUpdate(updateEntity, publishToPS);
    }

    public void updateTransactionEntryStatus(PaymentTransactionStatusEntity updateEntity, boolean publishToPS) {
        // update transaction entry
        transactionEntryDBMapper.updateTransactionEntryStatus(updateEntity);
        // update payment with or without payment center push
        updatePaymentForTransactionUpdate(updateEntity, publishToPS);
    }

    public void updatePayment(PaymentEntity paymentEntity, boolean publishToPS) {
        paymentDBMapper.updatePayment(paymentEntity);
        if (publishToPS) {
            publishUpdateToPS(paymentEntity.getPaymentId(), null);
        }
    }

    public void publishUpdateToPS(Long paymentId, Long delayInMilliseconds) {
        if (paymentId != null && paymentId > 0) {
            paymentCenterService.updatePayment(paymentId, delayInMilliseconds);
        } else {
            log.info("Payment Id is null or 0 so skip publishUpdateToPS");
        }
    }

    public void updateSplitFxTransactionByContractId(PaymentTransactionStatusEntity updateEntity) {
        transactionDBMapper.updateTransactionByContractId(updateEntity);
        if (isFinalStatus(updateEntity.getStatus())) {
            paymentDBMapper.updatePaymentTimeByContractId(updateEntity.getContractId());
            // TODO have to push to ES but we do not have transaction or payment id available here might have to do a DB select
        }
    }

    public void updateMultiplePaymentsWithCommonStatusAndRemark(List<PaymentEntity> paymentEntities,
                PaymentStatus paymentStatus,
                String remarks,
        boolean publishToPS) {
        if (paymentStatus != null) {
            List<Long> paymentIds = paymentEntities.stream().map(PaymentEntity::getPaymentId).toList();
            if (!paymentIds.isEmpty()) {
                paymentDBMapper.updatePaymentStatusAndRemarksByIds(paymentIds, paymentStatus.toString(), remarks);
                if (publishToPS) {
                    paymentCenterService.updatePaymentsList(paymentIds, null);
                }
            } else {
                log.error("PaymentIds are empty so skipping status update");
            }
        } else {
            log.error("Unable to update payments with PaymentStatus:null");
        }
    }

    public void updatePaymentForTransaction(TransactionEntity transactionEntity, boolean isRecurring) {
        paymentDBMapper.updatePaymentForTransaction(transactionEntity.getTransactionId());
        paymentCenterService.updatePayment(isRecurring ? transactionEntity.getTransactionId() : transactionEntity.getPaymentId(), null);
    }

    public void updateFxTxnEntryStatusAndRefInfos(PaymentTransactionStatusEntity updateEntity) {
        if (isFinalStatus(updateEntity.getStatus())) {
            paymentDBMapper.updatePaymentTimeByContractId(updateEntity.getContractId());
        }
        setE2ERefNo(updateEntity);
        transactionEntryDBMapper.updateTransactionEntryStatus(updateEntity);
    }

    private void updatePaymentForTransactionUpdate(PaymentTransactionStatusEntity updateEntity, boolean publishToPS) {
        if (updateEntity.getPaymentId() != null) {
            long paymentId = "SDMC".equalsIgnoreCase(updateEntity.getPaymentCategory()) ?
                    Long.parseLong(updateEntity.getPaymentId() + "000000" + updateEntity.getSequenceNo()) :
                    updateEntity.getPaymentId();
            PaymentEntity paymentEntity = new PaymentEntity();
            paymentEntity.setPaymentId(paymentId);
            this.updatePayment(paymentEntity, publishToPS);
        } else if (updateEntity.getTransactionId() != null) {
// TODO This logic wont work as the entry in ES is based off payment_id find alternative
//            long transactionId = "SDMC".equalsIgnoreCase(updateEntity.getPaymentCategory()) ?
//                    Long.parseLong(updateEntity.getTransactionId() + "000000" + updateEntity.getSequenceNo()) :
//                    updateEntity.getTransactionId();
            TransactionEntity transactionEntity = new TransactionEntity();
            transactionEntity.setTransactionId(updateEntity.getTransactionId());
            if (publishToPS) {
                this.updatePaymentForTransaction(transactionEntity, "Y".equals(updateEntity.getRecurring()));
            }
        } else {
            log.error("Skipping GW_PAYMENT update as both payment_id and transaction_id are empty");
        }
    }

    private boolean isFinalStatus(final String status) {
        return TransactionStatusEnum.SENT.name().equalsIgnoreCase(status)
                || TransactionStatusEnum.PROC.name().equalsIgnoreCase(status)
                || TransactionStatusEnum.FAIL.name().equalsIgnoreCase(status);
    }

    public void setE2ERefNo(PaymentTransactionStatusEntity txnStatusEntity) {
        if (Stream.of("FED", "USI", "FET", "XSD").anyMatch(t -> t.equalsIgnoreCase(txnStatusEntity.getPaymentType()))) {
            txnStatusEntity.setE2eRefNo(txnStatusEntity.getGfxRefNum());
        } else if (Stream.of("SAM", "XST").anyMatch(t -> t.equalsIgnoreCase(txnStatusEntity.getPaymentType()))) {
            txnStatusEntity.setE2eRefNo(txnStatusEntity.getSwiftRefNum());
        } else if (Stream.of("MSI", "MSG", "XMR").anyMatch(t -> t.equalsIgnoreCase(txnStatusEntity.getPaymentType()))) {
            txnStatusEntity.setE2eRefNo(txnStatusEntity.getFcReferenceId());
        } else if (Stream.of("FXW", "FXG", "MXW", "MXG", "XMC", "XMM").anyMatch(t -> t.equalsIgnoreCase(txnStatusEntity.getPaymentType()))) {
            txnStatusEntity.setE2eRefNo(txnStatusEntity.getContractId());
        }
    }
}
