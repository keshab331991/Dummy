package com.svb.gateway.payments.payment.util;

import com.svb.gateway.payments.common.enums.payment.TransactionStatus;
import com.svb.gateway.payments.common.service.mail.EmailService;
import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.entity.TransactionEntity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.PrintWriter;
import java.io.StringWriter;

@Component
public class PaymentProcessingErrorUtil {
    private final PaymentStatusUtil paymentStatusUtil;
    @Value("${payment.disablePaymentProcessingDBErrLog}")
    private boolean disablePaymentProcessingDBErrLog;
    private final EmailService emailService;

    public PaymentProcessingErrorUtil(EmailService emailService,
                                      PaymentStatusUtil paymentStatusUtil) {
        this.emailService = emailService;
        this.paymentStatusUtil = paymentStatusUtil;
    }

    public void handlerConsumerError(Long paymentId, String paymentType, String errorMsg) {
        handlerConsumerError(paymentId, paymentType, errorMsg, null);
    }

    public void handlerConsumerError(Long paymentId, String paymentType, String errorMsg, Throwable e) {
        String msgTitle = "Failure Notification - PaymentID: " + paymentId;
        StringBuilder msgBody = new StringBuilder();
        msgBody.append(createErrorMessage(paymentId, errorMsg));
        if (!disablePaymentProcessingDBErrLog && e != null) {
            msgBody.append("Error LOG : ");
            msgBody.append(getStackTraceAsString(e));
            handlerProcessingError(paymentId, paymentType, errorMsg,
                    msgTitle, msgBody.toString(), false);
        }
    }

    String createErrorMessage(Long paymentId, String errorMsg) {
        return "Unexpected error while processing the following payment record:" +
                System.lineSeparator() +
                "PaymentID: " + paymentId +
                System.lineSeparator() +
                "Error Message:  " + errorMsg;
    }

    public void handlerProcessingError(Long transactionId, String paymentType, String errorMsg,
                                       String msgSubject, String msgBody, boolean recurring) {
        handlerProcessingError(transactionId, paymentType, errorMsg, msgSubject, msgBody, 0, recurring);
    }

    public void handlerProcessingError(Long transactionId,
                                       String paymentType,
                                       String errorMsg,
                                       String msgSubject,
                                       String msgBody,
                                       int noOfRetry,
                                       boolean recurring) {
        PaymentTransactionStatusEntity errorEntity = new PaymentTransactionStatusEntity();
        errorEntity.setTransactionId(transactionId);
        errorEntity.setPaymentType(paymentType);
        errorEntity.setStatus(TransactionStatus.FAIL.toString());
        errorEntity.setNoOfRetries(noOfRetry);
        errorEntity.setRecurring(recurring ? "Y" : "N");
        int maxLength = 2000;
        if (disablePaymentProcessingDBErrLog) {
            errorEntity.setErrorDetails(errorMsg != null && errorMsg.length() > maxLength ? errorMsg.substring(0, maxLength) : errorMsg);
        } else {
            errorEntity.setErrorDetails(msgBody != null && msgBody.length() > maxLength ? msgBody.substring(0, maxLength) : msgBody);
        }
        TransactionEntity transactionEntity = new TransactionEntity();
        transactionEntity.setTransactionId(transactionId);
        paymentStatusUtil.updateTransactionStatus(errorEntity, true);
        emailService.sendEmail(msgSubject, msgBody);
    }

    public static String getStackTraceAsString(Throwable throwable) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        throwable.printStackTrace(pw);
        return sw.toString();
    }
}
