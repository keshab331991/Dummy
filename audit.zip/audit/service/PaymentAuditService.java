package com.svb.gateway.payments.payment.audit.service;

import com.svb.gateway.common.audit.model.AuditEvent;
import com.svb.gateway.common.audit.model.EventAttribute;
import com.svb.gateway.payments.common.audit.constant.PaymentAuditConstant;
import com.svb.gateway.payments.common.audit.service.AbstractAuditService;
import com.svb.gateway.payments.common.audit.util.AuditUtil;
import com.svb.gateway.payments.common.audit.util.enums.AuditEventEnum;
import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.dto.RequestData;
import com.svb.gateway.payments.common.enums.ApprovalStateEnum;
import com.svb.gateway.payments.common.enums.payment.*;
import com.svb.gateway.payments.common.model.GatewayContext;
import com.svb.gateway.payments.common.model.MetaData;
import com.svb.gateway.payments.common.model.MethodSignature;
import com.svb.gateway.payments.common.model.PaymentContext;
import com.svb.gateway.payments.common.model.approvals.ApprovalData;
import com.svb.gateway.payments.common.model.approvals.ApprovalInfo;
import com.svb.gateway.payments.common.model.identity.IdentityResponseIdentityData;
import com.svb.gateway.payments.common.model.payment.*;
import com.svb.gateway.payments.common.model.payment.cancellation.PaymentCancellationData;
import com.svb.gateway.payments.common.model.payment.initiation.PaymentInitiationData;
import com.svb.gateway.payments.common.model.staticdata.CountryDetail;
import com.svb.gateway.payments.common.service.IdentityService;
import com.svb.gateway.payments.common.service.StaticDetailsService;
import com.svb.gateway.payments.common.service.template.ITemplateExtService;
import com.svb.gateway.payments.common.util.DateUtil;
import com.svb.gateway.payments.common.util.PaymentConstant;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.modulith.NamedInterface;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import java.sql.Timestamp;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

import static com.svb.gateway.payments.common.constants.CommonConstant.NA;
import static com.svb.gateway.payments.common.constants.CommonConstant.NEW;

@Component
@Slf4j
@NamedInterface
public class PaymentAuditService extends AbstractAuditService {
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMMM dd, yyyy");
    private final DateUtil dateUtil;
    private final IdentityService identityService;
    private final StaticDetailsService staticDataService;
    private final ITemplateExtService templateExtService;

    public PaymentAuditService(DateUtil dateUtil, IdentityService identityService,
                               StaticDetailsService staticDataService,
                               ITemplateExtService templateExtService) {
        this.dateUtil = dateUtil;
        this.identityService = identityService;
        this.staticDataService = staticDataService;
        this.templateExtService = templateExtService;
    }

    public AuditEvent initiatePaymentAudit(@NotNull MethodSignature methodSignature, @NotNull AuditEvent auditEvent) {
        // get params
        RequestData<PaymentInitiationData> requestData = (RequestData<PaymentInitiationData>) methodSignature.getArgs()[0];
        PaymentInitiationData paymentData = requestData.getRequest();
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();

        if (CommonConstant.OPERATION_CREATE.equals(paymentData.getOperation()) && !context.isApprovalFlag()) {
            if (CommonConstant.TRANSFER_TYPES.contains(paymentData.getPaymentType().toString())) {
                AuditEventEnum transferEvent = AuditEventEnum.INITIATE_TRANSFER;
                auditEvent.setEventId(transferEvent.getEventId());
                auditEvent.setEventType(transferEvent.getEventType());
                setAttributesForTransfer(paymentData, auditEvent);
            } else {
                AuditEventEnum paymentEvent = AuditEventEnum.INITIATE_PAYMENT;
                auditEvent.setEventId(paymentEvent.getEventId());
                auditEvent.setEventType(paymentEvent.getEventType());
                setAttributesForPayment(context, paymentData, auditEvent);
            }
        }else {
            // if approval flag is enabled means the we need to audit the approval logs and skip this logs
            if(context.isApprovalFlag()) {
                return null;
            }
        }
        return auditEvent;
    }

    public AuditEvent initiateApprovalPaymentAudit(@NotNull MethodSignature methodSignature, @NotNull AuditEvent auditEvent) {
        // get params
        RequestData<PaymentInitiationData> requestData = (RequestData<PaymentInitiationData>) methodSignature.getArgs()[0];
        PaymentInitiationData paymentData = requestData.getRequest();
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();

        if ((CommonConstant.OPERATION_CREATE.equals(paymentData.getOperation())
                || CommonConstant.OPERATION_UPDATE.equals(paymentData.getOperation())) && context.isApprovalFlag()) {
            if (CommonConstant.TRANSFER_TYPES.contains(paymentData.getPaymentType().toString())) {
                AuditEventEnum transferEvent = AuditEventEnum.INITIATE_TRANSFER_APPROVAL;
                auditEvent.setEventId(transferEvent.getEventId());
                auditEvent.setEventType(transferEvent.getEventType());
                setAttributesForTransfer(paymentData, auditEvent);
            } else {
                AuditEventEnum paymentEvent = AuditEventEnum.INITIATE_PAYMENT_APPROVAL;
                auditEvent.setEventId(paymentEvent.getEventId());
                auditEvent.setEventType(paymentEvent.getEventType());
                setAttributesForPayment(context, paymentData, auditEvent);
            }
        }else  {
            // Skip: if approval flag is disabled means the audit is created as part of the payment initiate flow
            if(!context.isApprovalFlag()) {
                return null;
            }
        }
        return auditEvent;
    }

    public AuditEvent modifyPaymentAudit(@NotNull MethodSignature methodSignature, @NotNull AuditEvent auditEvent) {
        // get params
        RequestData<PaymentInitiationData> requestData = (RequestData<PaymentInitiationData>) methodSignature.getArgs()[0];
        PaymentInitiationData paymentData = requestData.getRequest();
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();
        if (context.isApprovalFlag()) {
            // Skip: if approval flag is YES means the modify audit should be skipped
            return null;
        }
        if (CommonConstant.TRANSFER_TYPES.contains(paymentData.getPaymentType().toString())) {
            auditEvent.setEventId(AuditEventEnum.MODIFY_TRANSFER.getEventId());
            auditEvent.setEventType(AuditEventEnum.MODIFY_TRANSFER.getEventType());
            setAttributesForTransfer(paymentData, auditEvent);
        } else {
            auditEvent.setEventId(AuditEventEnum.MODIFY_PAYMENT.getEventId());
            auditEvent.setEventType(AuditEventEnum.MODIFY_PAYMENT.getEventType());
            setAttributesForPayment(context, paymentData, auditEvent);
        }

        return auditEvent;
    }

    /**
     * Generate audit event for payment and transfer modification
     *
     * @param methodSignature MethodSignature
     * @return AuditEvent
     */
    public AuditEvent cancelPaymentAudit(MethodSignature methodSignature, AuditEvent auditEvent) {
        // get params
        RequestData<PaymentCancellationData> requestData = (RequestData<PaymentCancellationData>) methodSignature.getArgs()[0];
        PaymentCancellationData paymentData = requestData.getRequest();
        PaymentContext context = (PaymentContext) requestData.getGatewayContext();

        if (CommonConstant.TRANSFER_TYPES.contains(paymentData.getPaymentType().toString())) {
            auditEvent.setEventId(AuditEventEnum.CANCEL_TRANSFER.getEventId());
            auditEvent.setEventType(AuditEventEnum.CANCEL_TRANSFER.getEventType());
            setAttributesForCancelTransfer(paymentData, auditEvent);
        } else {
            auditEvent.setEventId(AuditEventEnum.CANCEL_PAYMENT.getEventId());
            auditEvent.setEventType(AuditEventEnum.CANCEL_PAYMENT.getEventType());
            setAttributesForCancelPayment(paymentData, auditEvent, context);
        }
        return auditEvent;
    }

    public AuditEvent transactionDetailsAudit(MethodSignature methodSignature, AuditEvent auditEvent) {
        // get params
        RequestData requestData = (RequestData) methodSignature.getArgs()[0];
        Map<String, Object> properties = requestData.getProperties();
        long transactionId = 0;
        if (properties.get(CommonConstant.TRANSACTION_ID) != null) {
            transactionId = (long) properties.get(CommonConstant.TRANSACTION_ID);
        }
        // the call for get payment details not for get transaction details
        // no action required
        if (transactionId == 0) {
            return null;
        }
        // no action required if no record found for the transaction id
        PaymentDetailResponse paymentDetailResponse = (PaymentDetailResponse) methodSignature.getResponseObj();
        if (paymentDetailResponse.isEmpty()) {
            return null;
        }
        PaymentDetail paymentDetail = paymentDetailResponse.getFirst();
        setAttributesForTransaction(requestData.getGatewayContext(), paymentDetail, auditEvent);
        return auditEvent;
    }

    /**
     * Generate audit event for payment and transfer modification
     *
     * @param methodSignature MethodSignature
     * @return AuditEvent
     */
    public AuditEvent approvePaymentAudit(MethodSignature methodSignature, AuditEvent auditEvent) {
        // get params
        ApprovalData approvalData = (ApprovalData) methodSignature.getArgs()[1];

        ApprovalStateEnum stateEnum = ApprovalStateEnum.fromValue(approvalData.getCurrentState());
        if(PaymentConstant.XFR_PAYMENTS.contains(approvalData.getPaymentType())) {
            if (stateEnum == ApprovalStateEnum.ALL_APPROVALS_COMPLETED || stateEnum == ApprovalStateEnum.NEED_FINAL_APPROVAL) {
                auditEvent.setEventId(AuditEventEnum.APPROVE_TRANSFER.getEventId());
                auditEvent.setEventType(AuditEventEnum.APPROVE_TRANSFER.getEventType());
                auditEvent.setEventName(AuditEventEnum.APPROVE_TRANSFER.getEventId());
                setTransferApprovalAndRejectAttrs(approvalData, auditEvent);
            } else if (stateEnum == ApprovalStateEnum.REJECTED) {
                auditEvent.setEventId(AuditEventEnum.REJECT_TRANSFER.getEventId());
                auditEvent.setEventType(AuditEventEnum.REJECT_TRANSFER.getEventType());
                auditEvent.setEventName(AuditEventEnum.REJECT_TRANSFER.getEventId());
                setTransferApprovalAndRejectAttrs(approvalData, auditEvent);
            }else if(stateEnum == ApprovalStateEnum.CANCELLED) {
                auditEvent.setEventId(AuditEventEnum.CANCEL_PENDING_TRANSFER.getEventId());
                auditEvent.setEventType(AuditEventEnum.CANCEL_PENDING_TRANSFER.getEventType());
                auditEvent.setEventName(AuditEventEnum.CANCEL_PENDING_TRANSFER.getEventId());
                setTransferApprovalAndRejectAttrs(approvalData, auditEvent);
            }
        }else {
            if (stateEnum == ApprovalStateEnum.ALL_APPROVALS_COMPLETED || stateEnum == ApprovalStateEnum.NEED_FINAL_APPROVAL) {
                auditEvent.setEventId(AuditEventEnum.APPROVE_PAYMENT.getEventId());
                auditEvent.setEventType(AuditEventEnum.APPROVE_PAYMENT.getEventType());
                auditEvent.setEventName(AuditEventEnum.APPROVE_PAYMENT.getEventId());
                setPaymentApprovalAndRejectAttrs(approvalData, auditEvent);
            } else if (stateEnum == ApprovalStateEnum.REJECTED) {
                auditEvent.setEventId(AuditEventEnum.REJECT_PAYMENT.getEventId());
                auditEvent.setEventType(AuditEventEnum.REJECT_PAYMENT.getEventType());
                auditEvent.setEventName(AuditEventEnum.REJECT_PAYMENT.getEventId());
                setPaymentApprovalAndRejectAttrs(approvalData, auditEvent);
            }else if(stateEnum == ApprovalStateEnum.CANCELLED) {
                auditEvent.setEventId(AuditEventEnum.CANCEL_PENDING_PAYMENT.getEventId());
                auditEvent.setEventType(AuditEventEnum.CANCEL_PENDING_PAYMENT.getEventType());
                auditEvent.setEventName(AuditEventEnum.CANCEL_PENDING_PAYMENT.getEventId());
                setPaymentApprovalAndRejectAttrs(approvalData, auditEvent);
            }
        }
        return auditEvent;
    }

    private void setPaymentApprovalAndRejectAttrs(ApprovalData approvalData, AuditEvent auditEvent) {
        List<EventAttribute> attrList = new ArrayList<>();
        HashMap<String, String> additionalData = approvalData.getAdditionalData();

        boolean isRecurringPayment = "Y".equals(additionalData.get("recurringData.recurring"));
        attrList.add(new EventAttribute(PaymentAuditConstant.ACCOUNT, getVal(additionalData.get("debitAccountData.accNum")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.PAYMENT_METHOD, getPaymentMethod(additionalData.get("paymentType")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.PAYMENT_INITIATOR, getName(additionalData.get("createdBy")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_NAME, getVal(additionalData.get("creditorData.name")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_ACCOUNT, getVal(additionalData.get("creditAccountData.accNum")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_ADDRESS, AuditUtil.getAddress(additionalData), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.CUSTOMER_ACCOUNT_NUMBER, getVal(additionalData.get("billPayData.customerAccountNumber")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_BANK, getVal(additionalData.get("creditorBankData.bankName")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_BANK_ROUTING_CODE, getVal(additionalData.get("creditorBankData.routingCode")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.DEBIT_AMOUNT, additionalData.get("debitAccountData.ccyAmt"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.DEBIT_CURRENCY, additionalData.get("debitAccountData.accCcy"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.CREDIT_AMOUNT, additionalData.get("totalTransactionAmt"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.CREDIT_CURRENCY, additionalData.get("transactionCcy"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FX_RATE, getVal(additionalData.get("crossCurrencyPaymentData.fxRate")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.ASSOCIATED_FEE_INSTRUCTIONS, getVal(additionalData.get("charges")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.SEND_DATE, getVal(additionalData.get("paymentDate")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FREQUENCY_TYPE, getFrequencyType(additionalData.get("recurringData.recurring")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FREQUENCY, getVal(additionalData.get("recurringData.paymentFrequency")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.ENDS_ON, getVal(additionalData.get("recurringData.endDate")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.END_TO_END_REF_ID, getVal(additionalData.get("isoData.endToEndId")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.PURPOSE_OF_PAYMENT, getVal(additionalData.get("additionalInfo.purpose_of_payment")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.REASON_FOR_PAYMENT, getVal(additionalData.get("additionalInfo.reason_for_payment")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.INVOICE_NUMBER, getVal(additionalData.get("additionalInfo.invoice_number")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.MEMO, getVal(additionalData.get("additionalInfo.internal_memo")), NEW));
        //Instructions to Recipient Bank
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_EMAIL, getVal(additionalData.get("creditorData.email")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.NOTE_TO_RECIPIENT, getVal(additionalData.get("notify_message")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.BANK_INSTRUCTIONS, getVal(additionalData.get("bankInstructions")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.INTERMEDIARY_BANK_ROUTING_CODE, getVal(additionalData.get("intermediaryBankRoutingCode")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.INTERMEDIARY_BANK, getVal(additionalData.get("intermediaryBank")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.QUOTE_CONFIRMATION_ID, getVal(additionalData.get("quoteConfirmationId")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.APPROVAL_LEVEL, Optional.ofNullable(approvalData.getApprovalInfo()).map(ApprovalInfo::getApproveLvl).orElse(NA), NEW));

        String templateName = additionalData.get("templateName");
        attrList.add(new EventAttribute(PaymentAuditConstant.TEMPLATE_NAME, templateName != null
                && templateName.equalsIgnoreCase("0") ? templateName : NA, NEW));

        attrList.add(new EventAttribute(PaymentAuditConstant.RECURRING_SERIES_ID, getVal(additionalData.get("paymentId")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSACTION_ID, getVal(additionalData.get("paymentId")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.PAYMENT_STATUS, getPaymentStatus(additionalData.get("paymentStatus")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.CANCEL_TYPE, getCancelType(additionalData.get("singleInstance")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FILE_UPLOAD_OUTPUT_DETAILS, getFileDetails(additionalData.get("fileId"), additionalData.get("recordNumber")), NEW));
        setRemittanceAttrs(additionalData, attrList);
        setOBOAttrs(additionalData, attrList);
        auditEvent.getEventData().setEventAttributes(attrList);
    }

    private void setTransferApprovalAndRejectAttrs(ApprovalData approvalData, AuditEvent auditEvent) {
        List<EventAttribute> attrList = new ArrayList<>();
        HashMap<String, String> additionalData = approvalData.getAdditionalData();

        boolean isRecurringPayment = "Y".equals(additionalData.get("recurringData.recurring"));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_FROM, getVal(additionalData.get("debitAccountData.accNum")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_TO, getVal(additionalData.get("creditAccountData.accNum")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.DEBIT_AMOUNT, additionalData.get("debitAccountData.ccyAmt"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.DEBIT_CURRENCY, additionalData.get("debitAccountData.accCcy"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.CREDIT_AMOUNT, additionalData.get("totalTransactionAmt"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.CREDIT_CURRENCY, additionalData.get("transactionCcy"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FX_RATE, getVal(additionalData.get("crossCurrencyPaymentData.fxRate")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FREQUENCY_TYPE, getFrequencyType(additionalData.get("recurringData.recurring")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FREQUENCY, getVal(additionalData.get("recurringData.paymentFrequency")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.QUOTE_CONFIRMATION_ID, getVal(additionalData.get("quoteConfirmationId")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_DATE, getVal(additionalData.get("paymentDate")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.ENDS_ON, getVal(additionalData.get("recurringData.endDate")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.MEMO, getVal(additionalData.get("additionalInfo.internal_memo")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.INSUFFICIENT_FUNDS, additionalData.get(PaymentAuditConstant.INSUFFICIENT_FUNDS), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.STATUS, getPaymentStatus(additionalData.get("paymentStatus")), NEW));

        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_ADDRESS, AuditUtil.getAddress(additionalData), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.CUSTOMER_ACCOUNT_NUMBER, getVal(additionalData.get("billPayData.customerAccountNumber")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_BANK, getVal(additionalData.get("creditorBankData.bankName")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_BANK_ROUTING_CODE, getVal(additionalData.get("creditorBankData.routingCode")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECURRING_SERIES_ID, isRecurringPayment ? getVal(additionalData.get("paymentId")) : NA, NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSACTION_ID, !isRecurringPayment ? getVal(additionalData.get("paymentId")) : NA, NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_TYPE, getPaymentStatus(additionalData.get("paymentStatus")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_INITIATOR, getPaymentStatus(additionalData.get("createdBy")), NEW));

        auditEvent.getEventData().setEventAttributes(attrList);
    }

    private void setAttributesForPayment(PaymentContext context, PaymentInitiationData paymentData, AuditEvent auditEvent) {
        List<EventAttribute> attrList = new ArrayList<>();
        // implemented for non split payment
        boolean isRecurringPayment = paymentData.getRecurringData() != null && paymentData.getRecurringData().isRecurring();

        setCommonAttributes(getId(paymentData),
                Optional.ofNullable(paymentData.getPaymentType()).map(PaymentType::getDescriptionAudit).orElse(NA),
                Optional.ofNullable(paymentData.getPaymentStatus()).map(PaymentStatus::getAuditDescription).orElse(NA),
                Optional.ofNullable(paymentData.getMetaInfo()).map(MetaData::getCreatedBy).orElse(NA),
                Optional.ofNullable(paymentData.getMetaInfo()).map(MetaData::getUpdatedBy).orElse(NA),
                isRecurringPayment,
                attrList);

        attrList.add(new EventAttribute(PaymentAuditConstant.CREDIT_AMOUNT, String.format("%.2f", paymentData.getTotalTransactionAmt()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.CREDIT_CURRENCY, paymentData.getTransactionCcy().toString(), NEW));
        String productCode = paymentData.getEntries().getFirst().getDebitAccountData().getProductCode();
        if(productCode != null && PaymentConstant.EXTERNAL_ACCOUNT_TYPES.contains(productCode)) {
            attrList.add(new EventAttribute(PaymentAuditConstant.INSUFFICIENT_FUNDS, NA, NEW));
        }else {
            attrList.add(new EventAttribute(PaymentAuditConstant.INSUFFICIENT_FUNDS, getVal(paymentData.getEntries().getFirst().isInsufficientFunds()), NEW));
        }

        AccountData debitAccount = paymentData.getEntries().getFirst().getDebitAccountData();
        if(paymentData.getPaymentType() != PaymentType.FET) {
            attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_ACCOUNT,
                    Optional.ofNullable(paymentData.getEntries().getFirst().getCreditAccountData()).map(AccountData::getAccNum).orElse(NA), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_BANK,
                    Optional.ofNullable(paymentData.getEntries().getFirst().getCreditorBankData()).map(BankData::getBankName).orElse(NA), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_BANK_ROUTING_CODE,
                    Optional.ofNullable(paymentData.getEntries().getFirst().getCreditorBankData()).map(BankData::getRoutingCode).orElse(NA), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.DEBIT_AMOUNT, String.format("%.2f", debitAccount.getCcyAmt()), NEW));
        }
        attrList.add(new EventAttribute(PaymentAuditConstant.CUSTOMER_ACCOUNT_NUMBER,
                Optional.ofNullable(paymentData.getEntries().getFirst().getBillPayData()).map(BillPayData::getCustomerAccountNumber).orElse(NA), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.END_TO_END_REF_ID,
                getEndToEndRefId(paymentData.getEntries().getFirst().getIsoData()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FX_RATE,
                getFXRate(paymentData.getEntries().getFirst().getCrossCurrencyPaymentData()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.ASSOCIATED_FEE_INSTRUCTIONS,
                Optional.ofNullable(paymentData.getEntries().getFirst().getCharges()).map(obj -> obj.getValue() + " - " + obj.getDescription()).orElse(NA), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.SEND_DATE,
                getDate(paymentData.getPaymentDate(), paymentData.getEntries().getFirst().getNetworkTimeZone()), NEW));
        String templateName = templateExtService.getTemplateName(context.getClientId(), paymentData.getTemplateId());
        attrList.add(new EventAttribute(PaymentAuditConstant.TEMPLATE_NAME, getVal(templateName), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FILE_UPLOAD_OUTPUT_DETAILS,
                getFileDetails(paymentData), NEW));
        if(paymentData.getEntries().getFirst().getNotifyMessage() != null) {
            attrList.add(new EventAttribute(PaymentAuditConstant.NOTE_TO_RECIPIENT,
                    getVal(paymentData.getEntries().getFirst().getNotifyMessage()), NEW));
        }
        if(paymentData.getEntries().getFirst().getInstructions() != null) {
            attrList.add(new EventAttribute(PaymentAuditConstant.BANK_INSTRUCTIONS,
                    getInstructions(paymentData.getEntries().getFirst().getInstructions()), NEW));
        }
        if(paymentData.getEntries().getFirst().getCrossCurrencyPaymentData() != null) {
            attrList.add(new EventAttribute(PaymentAuditConstant.QUOTE_CONFIRMATION_ID,
                    Optional.ofNullable(paymentData.getEntries().getFirst().getCrossCurrencyPaymentData()).map(CrossCurrencyPaymentData::getQuoteConfirmationId).orElse(NA), NEW));
        }
        attrList.add(new EventAttribute(PaymentAuditConstant.ACCOUNT, debitAccount.getAccNum(), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.DEBIT_CURRENCY, debitAccount.getAccCcy().toString(), NEW));

        if(paymentData.getPaymentType() != PaymentType.FET) {
            setRecipientAttrs(paymentData.getEntries().getFirst().getCreditorData(), attrList);
            String remarks = getRemittanceInformation(paymentData.getEntries().getFirst().getInstructions());
            attrList.add(new EventAttribute(PaymentAuditConstant.REASON_FOR_PAYMENT, remarks, NEW));
        }

        setAdditionalInfoAttrs(paymentData.getEntries().getFirst().getAdditionalInfo(), attrList);
        setRecurringAttrs(getId(paymentData), paymentData.getRecurringData(), attrList);
        setIntermediaryBankDataAttrs(paymentData.getEntries().getFirst().getIntermediaryBankData(), attrList);
        setRemittanceAttrs(paymentData.getEntries().getFirst().getIsoData(), attrList);
        setOBOAttrs(paymentData.getEntries().getFirst().getOboData(), attrList);
        setTaxPayAttrs(paymentData.getEntries().getFirst().getTaxPayDetails(), attrList);
        auditEvent.getEventData().setEventAttributes(attrList);
    }

    private void setAttributesForCancelPayment(PaymentCancellationData paymentData, AuditEvent auditEvent, PaymentContext context) {
        List<EventAttribute> attrList = new ArrayList<>();
        HashMap<String, String> additionalData = paymentData.getAdditionalData();
        boolean isRecurringPayment = "Y".equals(additionalData.get("recurringData.recurring"));

        String debitAcctCcy = additionalData.get("debitAccountData.accCcy");
        String creditCcy = additionalData.get("transactionCcy");
        attrList.add(new EventAttribute(PaymentAuditConstant.ACCOUNT, getVal(additionalData.get("debitAccountData.accNum")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.PAYMENT_METHOD, getPaymentMethod(additionalData.get("paymentType")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.PAYMENT_INITIATOR, getName(additionalData.get("createdBy")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_NAME, getVal(additionalData.get("creditorData.name")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_ACCOUNT, getVal(additionalData.get("creditAccountData.accNum")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_ADDRESS, AuditUtil.getAddress(additionalData), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.CUSTOMER_ACCOUNT_NUMBER, getVal(additionalData.get("billPayData.customerAccountNumber")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_BANK, getVal(additionalData.get("creditorBankData.bankName")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_BANK_ROUTING_CODE, getVal(additionalData.get("creditorBankData.routingCode")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.DEBIT_AMOUNT, additionalData.get("debitAccountData.ccyAmt"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.DEBIT_CURRENCY, additionalData.get("debitAccountData.accCcy"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.CREDIT_AMOUNT, additionalData.get("totalTransactionAmt"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.CREDIT_CURRENCY, additionalData.get("transactionCcy"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FX_RATE,
                debitAcctCcy.equalsIgnoreCase(creditCcy) ? NA : getVal(additionalData.get("crossCurrencyPaymentData.fxRate")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.ASSOCIATED_FEE_INSTRUCTIONS, additionalData.get("charges"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.SEND_DATE, additionalData.get("paymentDate"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FREQUENCY_TYPE, getFrequencyType(additionalData.get("recurringData.recurring")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FREQUENCY, isRecurringPayment ? getVal(additionalData.get("recurringData.paymentFrequency")) : NA, NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.ENDS_ON, isRecurringPayment ? getVal(additionalData.get("recurringData.endDate")) : NA, NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.REASON_FOR_PAYMENT, getVal(additionalData.get("additionalInfo.reason_for_payment")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.END_TO_END_REF_ID, getVal(additionalData.get("isoData.endToEndId")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.MEMO, getVal(additionalData.get("additionalInfo.internal_memo")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.INTERMEDIARY_BANK_ROUTING_CODE, getVal(additionalData.get("intermediaryBankRoutingCode")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.INTERMEDIARY_BANK, getVal(additionalData.get("intermediaryBank")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECURRING_SERIES_ID, isRecurringPayment ? getVal(additionalData.get("paymentId")) : NA, NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSACTION_ID, !isRecurringPayment ? getVal(additionalData.get("paymentId")) : NA, NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.PAYMENT_STATUS, getPaymentStatus(additionalData.get("paymentStatus")), NEW));
        //attrList.add(new EventAttribute(PaymentAuditConstant.CANCEL_TYPE, getCancelType(additionalData.get("singleInstance")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FILE_UPLOAD_OUTPUT_DETAILS, getFileDetails(additionalData.get("fileId"), additionalData.get("recordNumber")), NEW));
        String templateId = additionalData.get("templateId");
        String templateName = "";
        if(templateId != null) {
            templateName = templateExtService.getTemplateName(context.getClientId(), Long.valueOf(templateId));
        }
        attrList.add(new EventAttribute(PaymentAuditConstant.TEMPLATE_NAME, getVal(templateName), NEW));
        setOBOAttrs(additionalData, attrList);
        auditEvent.getEventData().setEventAttributes(attrList);
    }

    private void setAttributesForCancelTransfer(PaymentCancellationData paymentData, AuditEvent auditEvent) {
        List<EventAttribute> attrList = new ArrayList<>();
        HashMap<String, String> additionalData = paymentData.getAdditionalData();
        boolean isRecurringPayment = "Y".equals(additionalData.get("recurringData.recurring"));

        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_FROM, getVal(additionalData.get("debitAccountData.accNum")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_TO, getVal(additionalData.get("creditAccountData.accNum")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_AMOUNT, additionalData.get("totalTransactionAmt"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_CURRENCY, additionalData.get("transactionCcy"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_DATE, additionalData.get("paymentDate"), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FREQUENCY_TYPE, getFrequencyType(additionalData.get("recurringData.recurring")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FREQUENCY, isRecurringPayment ?
                getVal(additionalData.get("recurringData.paymentFrequency")) : NA, NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.ENDS_ON, isRecurringPayment ?
                getClosureMessage(additionalData.get("recurringData.endDate"),
                Integer.parseInt(additionalData.get("recurringData.totalInstances") == null
                        ? "0" : additionalData.get("recurringData.totalInstances")),
                formatter,
                dateUtil.getApplicationTimeZone()) : NA, NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.MEMO, getVal(additionalData.get("additionalInfo.internal_memo")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECURRING_SERIES_ID, getVal(additionalData.get("paymentId")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSACTION_ID, getVal(additionalData.get("transactionId")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.STATUS, getPaymentStatus(additionalData.get("paymentStatus")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.CANCEL_TYPE, getCancelType(additionalData.get("singleInstance")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_TYPE, getPaymentMethod(additionalData.get("paymentType")), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_INITIATOR, getName(additionalData.get("createdBy")), NEW));

        auditEvent.getEventData().setEventAttributes(attrList);
    }

    private void setAttributesForTransfer(PaymentInitiationData paymentData, AuditEvent auditEvent) {
        List<EventAttribute> attrList = new ArrayList<>();

        boolean isRecurringPayment = paymentData.getRecurringData() != null && paymentData.getRecurringData().isRecurring();

        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSACTION_ID, isRecurringPayment ? NA: getId(paymentData), NEW));

        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_FROM, getVal(paymentData.getEntries().getFirst().getDebitAccountData().getAccNum()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_TO, getVal(paymentData.getEntries().getFirst().getCreditAccountData().getAccNum()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.DEBIT_AMOUNT, String.format("%.2f", paymentData.getEntries().getFirst().getDebitAccountData().getCcyAmt()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.DEBIT_CURRENCY, paymentData.getEntries().getFirst().getDebitAccountData().getAccCcy().toString(), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.CREDIT_AMOUNT, String.format("%.2f", paymentData.getTotalTransactionAmt()), NEW));

        attrList.add(new EventAttribute(PaymentAuditConstant.CREDIT_CURRENCY, paymentData.getTransactionCcy().toString(), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FX_RATE, getFXRate(paymentData.getEntries().getFirst().getCrossCurrencyPaymentData()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_DATE, getDate(paymentData.getPaymentDate(), paymentData.getEntries().getFirst().getNetworkTimeZone()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSFER_TYPE, Optional.ofNullable(paymentData.getPaymentType()).map(PaymentType::getDescriptionAudit).orElse(NA), NEW));

        setRecurringAttrs(getId(paymentData), paymentData.getRecurringData(), attrList);
        String memo = getAdditionalInfo(paymentData.getEntries().getFirst().getAdditionalInfo(), AdditionalInfoItem.KeyEnum.REMARKS);
        attrList.add(new EventAttribute(PaymentAuditConstant.MEMO, memo != null ? memo : NA, NEW));

        attrList.add(new EventAttribute(PaymentAuditConstant.INSUFFICIENT_FUNDS, getVal(paymentData.getEntries().getFirst().isInsufficientFunds()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.STATUS,
                Optional.ofNullable(paymentData.getPaymentStatus()).map(PaymentStatus::getAuditDescription).orElse(NA), NEW));

        auditEvent.getEventData().setEventAttributes(attrList);
    }

    private void setCommonAttributes(String transactionId, String paymentType,
                                     String paymentStatus, String createdBy,
                                     String modifiedBy, boolean isRecurringPayment, List<EventAttribute> attrList) {
        attrList.add(new EventAttribute(PaymentAuditConstant.TRANSACTION_ID, isRecurringPayment ? NA: transactionId, NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.PAYMENT_METHOD, paymentType, NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.PAYMENT_STATUS, paymentStatus, NEW));
        //attrList.add(new EventAttribute(PaymentAuditConstant.PAYMENT_INITIATOR, getName(createdBy), NEW));
        //attrList.add(new EventAttribute(PaymentAuditConstant.MODIFIED_BY, getName(modifiedBy), NEW));
    }

    private void setAttributesForTransaction(GatewayContext context, PaymentDetail paymentDetail, AuditEvent auditEvent) {
        List<EventAttribute> attrList = new ArrayList<>();
        boolean isRecurringPayment = paymentDetail.getRecurringData() != null && paymentDetail.getRecurringData().isRecurring();
        setCommonAttributes(String.valueOf(paymentDetail.getTransactionId()),
                paymentDetail.getPaymentType().getDescription(),
                getVal(paymentDetail.getPaymentStatus().getCode()),
                getVal(paymentDetail.getMeta().getCreatedBy()),
                getVal(paymentDetail.getMeta().getUpdatedBy()),
                isRecurringPayment, attrList
        );

        attrList.add(new EventAttribute(PaymentAuditConstant.CUSTOMER_ACCOUNT_NUMBER,
                Optional.ofNullable(paymentDetail.getBillPayData()).map(BillPayData::getCustomerAccountNumber).orElse(NA), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_BANK, getVal(paymentDetail.getCreditBankData().getBankName()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_BANK_ROUTING_CODE, getVal(paymentDetail.getCreditBankData().getRoutingCode()), NEW));

        attrList.add(new EventAttribute(PaymentAuditConstant.CREDIT_AMOUNT, String.format("%.2f", paymentDetail.getCreditAccountData().getCcyAmt()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.ASSOCIATED_FEE_INSTRUCTIONS, getVal(paymentDetail.getCharges().getCode()
                + " - " + paymentDetail.getCharges().getDescription()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.DEBIT_AMOUNT, String.format("%.2f", paymentDetail.getDebitAccountData().getCcyAmt()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.DEBIT_CURRENCY, paymentDetail.getDebitAccountData().getAccCcy().toString(), NEW));
        setAdditionalInfoAttrs(paymentDetail.getAdditionalInfo(), attrList);
        setRecurringAttrs(getId(paymentDetail), paymentDetail.getRecurringData(), attrList);

        attrList.add(new EventAttribute(PaymentAuditConstant.NOTE_TO_RECIPIENT, getVal(paymentDetail.getNotificationToPayee()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.BANK_INSTRUCTIONS, getInstructions(paymentDetail.getInstructions()), NEW));

        attrList.add(new EventAttribute(PaymentAuditConstant.QUOTE_CONFIRMATION_ID,
                Optional.ofNullable(paymentDetail.getCrossCurrencyPaymentData()).map(CrossCurrencyPaymentData::getQuoteConfirmationId).orElse(NA), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FX_RATE, getFXRate(paymentDetail.getCrossCurrencyPaymentData()), NEW));
        String templateName = templateExtService.getTemplateName(context.getClientId(), paymentDetail.getTemplateId());
        attrList.add(new EventAttribute(PaymentAuditConstant.TEMPLATE_NAME, getVal(templateName), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FILE_UPLOAD_OUTPUT_DETAILS, getFileDetails(paymentDetail), NEW));

        setRecipientAttrs(paymentDetail.getCreditorData(), attrList);
        setIntermediaryBankDataAttrs(paymentDetail.getIntermediaryBankData(), attrList);
        setRemittanceAttrs(paymentDetail.getIsoData(), attrList);
        setOBOAttrs(paymentDetail.getOboData(), attrList);
        setTaxPayAttrs(paymentDetail.getTaxPayDetails(), attrList);
        auditEvent.getEventData().setEventAttributes(attrList);
    }

    private void setDebitAccountAttrs(AccountData accountData, List<EventAttribute> attrList) {

    }

    private void setIntermediaryBankDataAttrs(BankData intermediaryBankData, List<EventAttribute> attrList) {
        if (intermediaryBankData != null) {
            attrList.add(new EventAttribute(PaymentAuditConstant.INTERMEDIARY_BANK_ROUTING_CODE, getVal(intermediaryBankData.getRoutingCode()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.INTERMEDIARY_BANK, getVal(intermediaryBankData.getBankName()), NEW));
        }
    }

    private void setRecipientAttrs(UserData userData, List<EventAttribute> attrList) {
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_NAME, userData.getName(), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_EMAIL, getContactEmail(userData.getContact()), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.RECIPIENT_ADDRESS, AuditUtil.getAddress(userData.getAddress()), NEW));
    }

    private void setAdditionalInfoAttrs(AdditionalInfo additionalInfo, List<EventAttribute> attrList) {
        String memo = getAdditionalInfo(additionalInfo, AdditionalInfoItem.KeyEnum.INTERNAL_MEMO);
        attrList.add(new EventAttribute(PaymentAuditConstant.MEMO, memo != null ? memo : NA, NEW));

        String purposeOfPayment = getAdditionalInfo(additionalInfo, AdditionalInfoItem.KeyEnum.PURPOSE_OF_PAYMENT_CODE);
        if(purposeOfPayment != null) {
            attrList.add(new EventAttribute(PaymentAuditConstant.PURPOSE_OF_PAYMENT, purposeOfPayment, NEW));
        }

        String invoiceNo = getAdditionalInfo(additionalInfo, AdditionalInfoItem.KeyEnum.INVOICE_NUMBER);
        if(invoiceNo != null) {
            attrList.add(new EventAttribute(PaymentAuditConstant.INVOICE_NUMBER, invoiceNo, NEW));
        }
    }

    private void setRecurringAttrs(String id, RecurringData recurringData, List<EventAttribute> attrList) {
        boolean isRecurringPayment = recurringData != null && recurringData.isRecurring();
        attrList.add(new EventAttribute(PaymentAuditConstant.RECURRING_SERIES_ID, isRecurringPayment ? id : NA , NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FREQUENCY_TYPE, getFrequencyType(recurringData), NEW));
        attrList.add(new EventAttribute(PaymentAuditConstant.FREQUENCY, isRecurringPayment ? getFrequency(recurringData) : NA, NEW));
        if(isRecurringPayment) {
            attrList.add(new EventAttribute(PaymentAuditConstant.ENDS_ON,
                    getClosureMessage(recurringData.getEndDate(), recurringData.getTotalInstances(), formatter, dateUtil.getApplicationTimeZone()), NEW));
        }else {
            attrList.add(new EventAttribute(PaymentAuditConstant.ENDS_ON, NA, NEW));
        }
    }

    private void setRemittanceAttrs(IsoData isoData, List<EventAttribute> attrList) {
        if (isoData != null && isoData.getRelatedRemittanceInfo() != null) {
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_ID, getVal(isoData.getRelatedRemittanceInfo().getRemittanceId()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_SEND_METHOD, getVal(isoData.getRelatedRemittanceInfo().getMethod().name()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_ELECTRONIC_ID, String.valueOf(isoData.getRelatedRemittanceInfo().getElectronicId()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_COUNTRY, getVal(isoData.getRelatedRemittanceInfo().getPostalAddress().getCountryCode()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_BUILDING_NUMBER, getVal(isoData.getRelatedRemittanceInfo().getPostalAddress().getBuildingNumber()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_STREET_NAME, getVal(isoData.getRelatedRemittanceInfo().getPostalAddress().getStreetName()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_CITY, getVal(isoData.getRelatedRemittanceInfo().getPostalAddress().getCity()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_STATE, getVal(isoData.getRelatedRemittanceInfo().getPostalAddress().getState()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_POSTAL_CODE, getVal(isoData.getRelatedRemittanceInfo().getPostalAddress().getPostalCode()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.END_TO_END_ID, getVal(isoData.getEndToEndId()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REASON_FOR_PAYMENT_CODE, String.valueOf(isoData.getPurposeCodeInfo().getPurposeCode()), NEW));
        }
    }

    private void setRemittanceAttrs(HashMap<String, String> additionalData, List<EventAttribute> attrList) {
        if (additionalData != null ) {
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_ID, getVal(additionalData.get(PaymentAuditConstant.REMITTANCE_DETAILS_ID)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_SEND_METHOD, getVal(additionalData.get(PaymentAuditConstant.REMITTANCE_DETAILS_SEND_METHOD)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_ELECTRONIC_ID, getVal(additionalData.get(PaymentAuditConstant.REMITTANCE_DETAILS_ELECTRONIC_ID)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_COUNTRY, getVal(additionalData.get(PaymentAuditConstant.REMITTANCE_DETAILS_COUNTRY)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_BUILDING_NUMBER, getVal(additionalData.get(PaymentAuditConstant.REMITTANCE_DETAILS_BUILDING_NUMBER)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_STREET_NAME, getVal(additionalData.get(PaymentAuditConstant.REMITTANCE_DETAILS_STREET_NAME)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_CITY, getVal(additionalData.get(PaymentAuditConstant.REMITTANCE_DETAILS_CITY)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_STATE, getVal(additionalData.get(PaymentAuditConstant.REMITTANCE_DETAILS_STATE)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REMITTANCE_DETAILS_POSTAL_CODE, getVal(additionalData.get(PaymentAuditConstant.REMITTANCE_DETAILS_POSTAL_CODE)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.END_TO_END_ID, getVal(additionalData.get(PaymentAuditConstant.END_TO_END_ID)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.REASON_FOR_PAYMENT_CODE, getVal(additionalData.get(PaymentAuditConstant.REASON_FOR_PAYMENT_CODE)), NEW));
        }
    }

    private void setOBOAttrs(OBOData oboData, List<EventAttribute> attrList) {
        if (oboData != null) {
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_TYPE_IDENTIFIER, getVal(oboData.getOriginatorType().getDescription()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_NAME, getVal(oboData.getOriginatorName()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_IDENTIFIER, getVal(oboData.getOriginatorIdentifier()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_STREET_ADDRESS, getVal(oboData.getOriginatorStreetAddr()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_CITY, getVal(oboData.getOriginatorCity()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_STATE, getVal(oboData.getOriginatorState()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_ZIP_CODE, getVal(oboData.getOriginatorZip()), NEW));
            if(StringUtils.hasLength(oboData.getOriginatorCountry())) {
                Map<String, String> countryDescMap = staticDataService.retrieveCountries()
                        .stream()
                        .collect(Collectors.toMap(
                                CountryDetail::getCountryCode,
                                CountryDetail::getCountryDescription
                        ));
                String countryDesc = countryDescMap.get(oboData.getOriginatorCountry());
                attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_COUNTRY, getVal(StringUtils.hasLength(countryDesc) ? countryDesc : oboData.getOriginatorCountry()), NEW));
            }
        }
    }

    private void setOBOAttrs(HashMap<String, String> additionalData, List<EventAttribute> attrList) {
        if (additionalData != null &&
                additionalData.get(PaymentAuditConstant.OBO_ORIGINATOR_TYPE_IDENTIFIER) != null &&
                !additionalData.get(PaymentAuditConstant.OBO_ORIGINATOR_TYPE_IDENTIFIER).isEmpty()) {
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_TYPE_IDENTIFIER, getVal(additionalData.get(PaymentAuditConstant.OBO_ORIGINATOR_TYPE_IDENTIFIER)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_NAME, getVal(additionalData.get(PaymentAuditConstant.OBO_ORIGINATOR_NAME)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_IDENTIFIER, getVal(additionalData.get(PaymentAuditConstant.OBO_ORIGINATOR_IDENTIFIER)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_STREET_ADDRESS, getVal(additionalData.get(PaymentAuditConstant.OBO_ORIGINATOR_STREET_ADDRESS)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_CITY, getVal(additionalData.get(PaymentAuditConstant.OBO_ORIGINATOR_CITY)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_STATE, getVal(additionalData.get(PaymentAuditConstant.OBO_ORIGINATOR_STATE)), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_ZIP_CODE, getVal(additionalData.get(PaymentAuditConstant.OBO_ORIGINATOR_ZIP_CODE)), NEW));
            if(StringUtils.hasLength(additionalData.get(PaymentAuditConstant.OBO_ORIGINATOR_COUNTRY))) {
                Map<String, String> countryDescMap = staticDataService.retrieveCountries()
                        .stream()
                        .collect(Collectors.toMap(
                                CountryDetail::getCountryCode,
                                CountryDetail::getCountryDescription
                        ));
                String countryDesc = countryDescMap.get(additionalData.get(PaymentAuditConstant.OBO_ORIGINATOR_COUNTRY));
                attrList.add(new EventAttribute(PaymentAuditConstant.OBO_ORIGINATOR_COUNTRY, getVal(StringUtils.hasLength(countryDesc) ? countryDesc
                        : additionalData.get(PaymentAuditConstant.OBO_ORIGINATOR_COUNTRY)), NEW));
            }
        }
    }

    private void setTaxPayAttrs(TaxPayDetails taxPayDetails, List<EventAttribute> attrList) {
        if(taxPayDetails != null) {
            attrList.add(new EventAttribute(PaymentAuditConstant.TAX_PAYER_NAME, getVal(taxPayDetails.getTaxPayerName()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.TAX_PAYER_ID_NUMBER, getVal(taxPayDetails.getTaxPayerIdNumber()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.TAX_TYPE_CODE, getVal(taxPayDetails.getTaxTypeCode()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.TAX_YEAR, getVal(taxPayDetails.getTaxYear()), NEW));
            attrList.add(new EventAttribute(PaymentAuditConstant.TAX_MONTH, getVal(Optional.ofNullable(taxPayDetails.getTaxMonth()).map(Month::toString).orElse(NA)), NEW));
        }
    }

    private String getFileDetails(PaymentDetail paymentDetail) {
        if (paymentDetail.getFileId() > 0) {
            return String.format("%s | %s", paymentDetail.getFileId(), paymentDetail.getRecordNumber());
        }
        return NA;
    }

    private String getFileDetails(PaymentInitiationData paymentData) {
        return this.getFileDetails(String.valueOf(paymentData.getFileId()), String.valueOf(paymentData.getRecordNumber()));
    }

    private String getFileDetails(String fileId, String recordNumber) {
        StringJoiner fileDetails = new StringJoiner(" / ");
        fileDetails.add(fileId != null ? fileId : "");
        fileDetails.add(recordNumber != null ? recordNumber : "");
        return !fileDetails.toString().trim().equals("0 / 0")? fileDetails.toString() : NA;
    }

    private String getContactEmail(ContactData contactData) {
        return Optional.ofNullable(contactData)
                .map(ContactData::getEmail)
                .orElse(NA);
    }

    private String getVal(boolean insufficientFunds) {
        return insufficientFunds ? "Y" : "N";
    }

    private String getStatus(PaymentInitiationData paymentData) {
        String status = NA;
        if (paymentData.getTransactionId() > 0) {
            status = Optional.ofNullable(paymentData.getTransactionStatus()).map(TransactionStatus::getDescription).orElse(NA);
        } else if (paymentData.getPaymentId() > 0) {
            status = Optional.ofNullable(paymentData.getPaymentStatus()).map(PaymentStatus::getAuditDescription).orElse(NA);
        }
        return status;
    }

    private String getId(PaymentInitiationData paymentData) {
        if (paymentData.getTransactionId() > 0) {
            return String.valueOf(paymentData.getTransactionId());
        } else if (paymentData.getPaymentId() > 0) {
            return String.valueOf(paymentData.getPaymentId());
        }
        return NA;
    }

    private String getId(PaymentDetail paymentData) {
        if (paymentData.getTransactionId() > 0) {
            return String.valueOf(paymentData.getTransactionId());
        } else if (paymentData.getPaymentId() > 0) {
            return String.valueOf(paymentData.getPaymentId());
        }
        return NA;
    }


    private String getAdditionalInfo(AdditionalInfo additionalInfo, AdditionalInfoItem.KeyEnum key) {
        String val = null;
        if (additionalInfo != null) {
            Optional<AdditionalInfoItem> memo = additionalInfo.getItems().stream()
                    .filter(item -> item.getKey().equals(key))
                    .findFirst();
            if (memo.isPresent()) {
                val = memo.get().getValue();
            }
        }
        return val;
    }

    private String getEndToEndRefId(IsoData isoData) {
        return Optional.ofNullable(isoData)
                .map(IsoData::getEndToEndId)
                .map(String::toString)
                .orElse(NA);
    }

    private String getFrequency(RecurringData recurringData) {
        return Optional.ofNullable(recurringData)
                .map(RecurringData::getPaymentFrequency)
                .map(Frequency::getDescription)
                .orElse(NA);
    }

    private String getInstructions(Instructions instructions) {
        return Optional.ofNullable(instructions)
                .map(Instructions::getBankToBankInstructions)
                .map(String::toString)
                .orElse(NA);
    }

    private String getDate(Timestamp paymentDate, String networkTimeZone) {
        networkTimeZone = networkTimeZone == null || networkTimeZone.isEmpty() ? PaymentConstant.US_TIME_ZONE : networkTimeZone;
        return dateUtil.getTimestamp(paymentDate, networkTimeZone, DateTimeFormatter.ISO_LOCAL_DATE);
    }

    private String getFXRate(CrossCurrencyPaymentData crossCurrencyPaymentData) {
        Double fxRate = Optional.ofNullable(crossCurrencyPaymentData).map(CrossCurrencyPaymentData::getFxRate).orElse((double) 0);
        return fxRate > 0 ? fxRate.toString() : NA;
    }

    private String getVal(String val) {
        return val == null || val.isEmpty() || val.equalsIgnoreCase("null") ? NA : val;
    }

    private String getFrequencyType(RecurringData recurringData) {
        return Optional.ofNullable(recurringData)
                .map(RecurringData::getPaymentFrequency)
                .map(s -> "recurring")
                .orElse("one-time");
    }

    private String getFrequencyType(String recurring) {
        return Optional.ofNullable(recurring)
                .filter("Y"::equals)
                .map(s -> "recurring")
                .orElse("one-time");
    }

    private String getPaymentMethod(String paymentType) {
        if (paymentType == null) {
            return NA;
        }
        return Optional.ofNullable(PaymentType.fromValue(paymentType)).map(PaymentType::getDescriptionAudit).orElse(NA);
    }

    private String getPaymentStatus(String paymentStatus) {
        if (paymentStatus == null) {
            return NA;
        }
        return Optional.ofNullable(PaymentStatus.fromValue(paymentStatus)).map(PaymentStatus::getAuditDescription).orElse(NA);
    }

    private String getName(String userId) {
        if (userId == null) {
            return NA;
        }
        IdentityResponseIdentityData userData = identityService.getIdentity(userId);
        return Optional.ofNullable(userData)
                .map(IdentityResponseIdentityData::getData)
                .map(data -> String.format("%s %s",
                        Optional.ofNullable(data.getFirstName()).map(String::toString).orElse(NA),
                        Optional.ofNullable(data.getLastName()).map(String::toString).orElse(NA)))
                .orElse(NA);
    }

    private String getCancelType(String singleInstance) {
        return Optional.ofNullable(singleInstance)
                .map(s -> "true".equals(s) ? "Next Instance" : "Complete Series")
                .orElse(NA);
    }

    private String getClosureMessage(String endDate, Integer instances,
                                     DateTimeFormatter formatter, String networkTimeZone) {
        if (endDate != null && !endDate.isEmpty()) {
            return  dateUtil.getTimestamp(dateUtil.getTimestamp(endDate), networkTimeZone, formatter);
        } else if (instances > 0) {
            return "After " + instances + " occurrences";
        } else {
            return "Upon Cancellation";
        }
    }

    private String getRemittanceInformation(Instructions instructions) {
        return Optional.ofNullable(instructions).map(Instructions::getRemittanceInformation).orElse(NA);
    }

}