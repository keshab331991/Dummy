package com.svb.gateway.payments.payment.batch.job;

import com.svb.gateway.payments.common.enums.DownstreamStatusEnum;
import com.svb.gateway.payments.common.model.payment.WirePaymentProcessingData;
import com.svb.gateway.payments.common.service.mail.EmailService;
import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.mapper.PaymentMapperUtil;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.service.PaymentProcessingService;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.svb.gateway.payments.common.util.PaymentConstant.*;


@Component
@Slf4j
public class SPMPaymentRetryJob {

    private final TransactionDBMapper transactionDBMapper;
    private final TransactionEntryDBMapper transactionEntryDBMapper;
    private final PaymentProcessingService paymentProcessingService;
    private final EmailService emailService;
    private final PaymentStatusUtil paymentStatusUtil;


    public SPMPaymentRetryJob(TransactionDBMapper transactionDBMapper,
                              TransactionEntryDBMapper transactionEntryDBMapper,
                              PaymentProcessingService paymentProcessingService,
                              EmailService emailService,
                              PaymentStatusUtil paymentStatusUtil) {
        this.transactionDBMapper = transactionDBMapper;
        this.transactionEntryDBMapper = transactionEntryDBMapper;
        this.paymentProcessingService = paymentProcessingService;
        this.emailService = emailService;
        this.paymentStatusUtil = paymentStatusUtil;
    }

    @Scheduled(cron = "${spm.payment.retry.cron.expression:-}", zone = "America/Los_Angeles")
    @SchedulerLock(name = "${spm.payment.retry.scheduler.name}")
    public void execute() {
        log.info("Start : SPMPaymentRetryJob : Time :{}", System.currentTimeMillis());
        List<PaymentTransactionStatusEntity> spmPaymentsList = transactionDBMapper.getTxnByDownStreamStatusAndRetryLimit(
                List.of(DownstreamStatusEnum.INITIATED.toString(), DownstreamStatusEnum.POSTING_RETRY.toString()),
                null,
                maxRetryLimit,
                List.of("XST", "SAM", "XSD", "WIRE", "MSI", "MSG", "XMR", "ICA", "ICT"));
            log.info("List of SPM Payment records to be retried : {}", spmPaymentsList.size());
            for (PaymentTransactionStatusEntity spmPayment : spmPaymentsList) {
                try {
                    log.info("SPMPaymentRetryJob: fetch transaction for transaction Id :{}" +
                            " and prepare the Payment message.", spmPayment.getTransactionId());

                    List<ProcessingMessage> processingMessages = transactionDBMapper.fetchTransaction(spmPayment.getTransactionId(), spmPayment.getSequenceNo());
                    if (!processingMessages.isEmpty()) {
                        if (spmPayment.getNoOfRetries() == paymentRetryLimit) {
                            log.info("Posting Retry has reached maximum no of limit {} for transaction Id {} and paymentType {} ", spmPayment.getNoOfRetries(), spmPayment.getTransactionId(), spmPayment.getPaymentType());
                            spmPayment.setDownstreamStatus(DownstreamStatusEnum.OFFLINE_RETRY.name());
                            paymentStatusUtil.updateTransactionEntryStatus(spmPayment, false);
                            log.info("DB Status updated to Offline Retry {}", spmPayment.getTransactionId());
                            String offlineRetrySubject = "XSD".equalsIgnoreCase(spmPayment.getPaymentType()) ? "SPM Payment Posting Retry Failed: " : "USD Payment Posting Retry Failed: ";
                            String offlineRetryBody = "Gateway payment Id : " + spmPayment.getPaymentId() + " failed to post it to SOA and has exceeded max no of retries : " ;
                            emailService.sendEmail(offlineRetrySubject,offlineRetryBody);
                            log.info("Email alert sent to App Support team {}", spmPayment.getPaymentId());
                        } else {
                            int retryCount = spmPayment.getNoOfRetries() + 1;
                            spmPayment.setNoOfRetries(retryCount);
                            ProcessingMessage processingMessage = processingMessages.getFirst();
                            PaymentMapperUtil.customizePaymentMsg(processingMessage.getPaymentData());
                            // Convert the processing message to wire payment message
                            WirePaymentProcessingData wirePaymentProcessingData = new WirePaymentProcessingData();
                            wirePaymentProcessingData.setPaymentHeader(processingMessage.getPaymentHeader());
                            wirePaymentProcessingData.setPaymentData(processingMessage.getPaymentData());
                            transactionEntryDBMapper.updateTransactionEntryStatus(spmPayment);
                            paymentProcessingService.processWirePayment(wirePaymentProcessingData);
                        }
                    }
                } catch (Exception e) {
                    log.error("Error occurred when executing SPMPaymentRetryJob.", e);
                    emailService.sendEmail("SPMPaymentRetryJob Has Failed for transfer id : " + spmPayment.getTransactionId(),
                            "Caught Unexpected Exception in Retry Job " + e.getMessage());
                }
            }
    }

}

