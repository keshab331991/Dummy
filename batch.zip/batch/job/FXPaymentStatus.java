package com.svb.gateway.payments.payment.batch.job;

import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.service.PaymentProcessingService;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class FXPaymentStatus {
    private final TransactionDBMapper transactionDBMapper;
    private final PaymentProcessingService paymentProcessingService;

    public FXPaymentStatus(TransactionDBMapper transactionDBMapper,
                           PaymentProcessingService paymentProcessingService) {
        this.transactionDBMapper = transactionDBMapper;
        this.paymentProcessingService = paymentProcessingService;
    }

    @Scheduled(cron = "${fxpayment.status.sync.cron.exp:-}", zone = "America/Los_Angeles")
    @SchedulerLock(name = "${fxpayment.status.sync.scheduler.name}")
    public void execute() {
        log.info(" Start : FXPaymentStatusJob : Time :{}", System.currentTimeMillis());
        List<PaymentTransactionStatusEntity> transactions = transactionDBMapper.getPendingFXTransactions();
        if (transactions != null && !transactions.isEmpty()) {
            log.info("  FXPaymentStatusJob : Processing no of records :{} ", transactions.size());
            for (PaymentTransactionStatusEntity transaction : transactions) {
                paymentProcessingService.retrieveFXPaymentStatus(transaction);
            }
        } else {
            log.info("  FXPaymentStatusJob : No transactions record found to process.");
        }
        log.info(" End : FXPaymentStatusJob : Time :{}", System.currentTimeMillis());
    }
}
