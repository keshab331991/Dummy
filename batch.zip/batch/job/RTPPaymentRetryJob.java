package com.svb.gateway.payments.payment.batch.job;

import com.svb.gateway.payments.common.enums.DownstreamStatusEnum;
import com.svb.gateway.payments.common.model.payment.WirePaymentProcessingData;
import com.svb.gateway.payments.common.service.mail.EmailService;
import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.mapper.PaymentMapperUtil;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.service.PaymentProcessingService;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.svb.gateway.payments.common.util.PaymentConstant.*;


@Component
@Slf4j
public class RTPPaymentRetryJob {

    private final TransactionDBMapper transactionDBMapper;
    private final TransactionEntryDBMapper transactionEntryDBMapper;
    private final PaymentProcessingService paymentProcessingService;
    private final EmailService emailService;
    private final PaymentStatusUtil paymentStatusUtil;


    public RTPPaymentRetryJob(TransactionDBMapper transactionDBMapper,
                              TransactionEntryDBMapper transactionEntryDBMapper,
                              PaymentProcessingService paymentProcessingService,
                              EmailService emailService,
                              PaymentStatusUtil paymentStatusUtil) {
        this.transactionDBMapper = transactionDBMapper;
        this.transactionEntryDBMapper = transactionEntryDBMapper;
        this.paymentProcessingService = paymentProcessingService;
        this.emailService = emailService;
        this.paymentStatusUtil = paymentStatusUtil;
    }

    @Scheduled(cron = "${rtp.payment.retry.cron.expression:-}", zone = "America/Los_Angeles")
    @SchedulerLock(name = "${rtp.payment.retry.scheduler.name}")
    public void execute() {
        log.info("Start : RTPPaymentRetryJob : Time :{}", System.currentTimeMillis());
        List<PaymentTransactionStatusEntity> rtpPaymentsList = transactionDBMapper.getTxnByDownStreamStatusAndRetryLimit(
                List.of(DownstreamStatusEnum.INITIATED.toString(), DownstreamStatusEnum.POSTING_RETRY.toString()),
                null,
                maxRetryLimit,
                List.of("RTP"));
            log.info("List of RTP Payment records to be retried : {}", rtpPaymentsList.size());
            for (PaymentTransactionStatusEntity rtpPayment : rtpPaymentsList) {
                try {
                    log.info("RTPPaymentRetryJob: fetch transaction for transaction Id :{}" +
                            " and prepare the Payment message.", rtpPayment.getTransactionId());

                    List<ProcessingMessage> processingMessages = transactionDBMapper.fetchTransaction(rtpPayment.getTransactionId(),  rtpPayment.getSequenceNo());
                    if (!processingMessages.isEmpty()) {
                        if (rtpPayment.getNoOfRetries() == paymentRetryLimit) {
                            log.info("Posting Retry has reached maximum no of limit {} for transaction Id {} and paymentType {} ", rtpPayment.getNoOfRetries(), rtpPayment.getTransactionId(), rtpPayment.getPaymentType());
                            rtpPayment.setDownstreamStatus(DownstreamStatusEnum.OFFLINE_RETRY.name());
                            paymentStatusUtil.updateTransactionEntryStatus(rtpPayment, false);
                            log.info("DB Status updated to Offline Retry {}", rtpPayment.getTransactionId());
                            String offlineRetrySubject = "XSD".equalsIgnoreCase(rtpPayment.getPaymentType()) ? "RTP Payment Posting Retry Failed: " : "USD Payment Posting Retry Failed: ";
                            String offlineRetryBody = "Gateway payment Id : " + rtpPayment.getPaymentId() + " failed to post it to SOA and has exceeded max no of retries : " ;
                            emailService.sendEmail(offlineRetrySubject,offlineRetryBody);
                            log.info("Email alert sent to App Support team {}", rtpPayment.getPaymentId());
                        } else {
                            int retryCount = rtpPayment.getNoOfRetries() + 1;
                            rtpPayment.setNoOfRetries(retryCount);
                            ProcessingMessage processingMessage = processingMessages.get(0);
                            PaymentMapperUtil.customizePaymentMsg(processingMessage.getPaymentData());
                            // Convert the processing message to wire payment message
                            WirePaymentProcessingData wirePaymentProcessingData = new WirePaymentProcessingData();
                            wirePaymentProcessingData.setPaymentHeader(processingMessage.getPaymentHeader());
                            wirePaymentProcessingData.setPaymentData(processingMessage.getPaymentData());
                            transactionEntryDBMapper.updateTransactionEntryStatus(rtpPayment);
                            paymentProcessingService.processWirePayment(wirePaymentProcessingData);
                        }
                    }
                } catch (Exception e) {
                    log.error("Error occurred when executing RTPPaymentRetryJob.", e);
                    emailService.sendEmail("RTPPaymentRetryJob Has Failed for transfer id : " + rtpPayment.getTransactionId(),
                            "Caught Unexpected Exception in Retry Job " + e.getMessage());
                }
            }
    }

}

