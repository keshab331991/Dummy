package com.svb.gateway.payments.payment.batch.job;

import com.svb.gateway.payments.common.enums.DownstreamStatusEnum;
import com.svb.gateway.payments.common.enums.PaymentTypeEnum;
import com.svb.gateway.payments.common.enums.TransactionStatusEnum;
import com.svb.gateway.payments.common.model.payment.TransferPaymentProcessingData;
import com.svb.gateway.payments.common.service.mail.EmailService;
import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.mapper.PaymentMapperUtil;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.service.PaymentProcessingService;
import com.svb.gateway.payments.payment.util.PaymentStatusUtil;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class TransferPostingNSFRetryJob {
    @Value("${nsf.payment.retry.cutofftime}")
    private String cutOffForNsfRetry;

    private final TransactionDBMapper transactionDBMapper;
    private final PaymentProcessingService paymentProcessingService;
    private final PaymentStatusUtil paymentStatusUtil;
    private final EmailService emailService;

    public TransferPostingNSFRetryJob(TransactionDBMapper transactionDBMapper,
                                      PaymentProcessingService paymentProcessingService,
                                      PaymentStatusUtil paymentStatusUtil,
                                      EmailService emailService) {
        this.transactionDBMapper = transactionDBMapper;
        this.paymentProcessingService = paymentProcessingService;
        this.paymentStatusUtil = paymentStatusUtil;
        this.emailService = emailService;
    }

    @Scheduled( cron = "${transfer.posting.nsf.retry.cron.expression}", zone = "${transfer.posting.nsf.retry.cron.timezone}" )
    @SchedulerLock(name = "${transfer.posting.nsf.retry.scheduler.name}")
    public void execute() {
        log.info("TransferPostingNSFRetryJob - NSF TransferPostingRetryJob has Started !!!");

        // here fetch the pending NSF_RETRY transactions
        List<PaymentTransactionStatusEntity> transferList = transactionDBMapper.getTransactionsByStatusAndType(
                DownstreamStatusEnum.NSF_RETRY.toString(),
                PaymentTypeEnum.XFR.name());
        log.info("TransferPostingNSFRetryJob: List of NSF Transfers records to be retried :{}", transferList.size());
        for (PaymentTransactionStatusEntity transferEntity : transferList) {
            try{
                log.info("TransferPostingNSFRetryJob: fetch transaction for transaction Id :{}" +
                        " and prepare the Payment message.", transferEntity.getTransactionId());

                List<ProcessingMessage> processingMessages = transactionDBMapper.fetchTransaction(transferEntity.getTransactionId(),  transferEntity.getSequenceNo());
                if(!processingMessages.isEmpty()) {
                    ProcessingMessage processingMessage = processingMessages.getFirst();
                    PaymentMapperUtil.customizePaymentMsg(processingMessage.getPaymentData());
                    // Convert the processing message to transfer message
                    TransferPaymentProcessingData transferPaymentProcessingData = new TransferPaymentProcessingData();
                    transferPaymentProcessingData.setPaymentHeader(processingMessage.getPaymentHeader());
                    transferPaymentProcessingData.setPaymentData(processingMessage.getPaymentData());

                    // update the transaction status to IN-PROCESS
                    transferEntity.setTransactionId(transferEntity.getTransactionId());
                    transferEntity.setStatus(TransactionStatusEnum.INPR.name());
                    transferEntity.setPaymentId(transferEntity.getPaymentId());
                    paymentStatusUtil.updateEntireStatus(transferEntity, true);
                    // Process the & POST the transfer message
                    paymentProcessingService.processTransfer(transferPaymentProcessingData);
                }
            } catch (Exception e) {
                log.error("Error occurred when executing NSF TransferPostingRetryJob.", e);
                emailService.sendEmail("NSF TransferPostingRetryJob Has Failed for transfer id : " + transferEntity.getTransactionId(),
                        "Caught Unexpected Exception in Retry Job " + e.getMessage());
            }
        }
        log.info("TransferPostingNSFRetryJob - NSF TransferPostingRetryJob has done !!!");
     }
    }
