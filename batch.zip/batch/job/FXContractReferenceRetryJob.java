package com.svb.gateway.payments.payment.batch.job;

import com.svb.gateway.payments.common.enums.DownstreamStatusEnum;
import com.svb.gateway.payments.common.enums.TransactionStatusEnum;
import com.svb.gateway.payments.common.model.payment.FXWPaymentProcessingData;
import com.svb.gateway.payments.common.model.payment.fxw.FXWPayments;
import com.svb.gateway.payments.common.model.payment.processing.PaymentProcessingData;
import com.svb.gateway.payments.common.service.mail.EmailService;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.mapper.PaymentMapperUtil;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.service.FXService;
import com.svb.gateway.payments.payment.service.PaymentProcessingService;
import com.svb.gateway.payments.payment.util.PaymentProcessingErrorUtil;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


@Component
@Slf4j
public class FXContractReferenceRetryJob {
    private static final String EMAIL_SUBJECT = "SVB Go - FX / GACH Contract Retry Failure Notification - PaymentID: ";
    private static final String FX_CONTRACT_REFERENCE_RETRY_ERROR_MESSAGE = "Unhandled Exception while updating contract reference ";
    private static final String FX_INITIATED_RETRY_ERROR_MESSAGE = "Unhandled Exception while updating status of payment to initiated ";
    private static final String MESSAGE_FOR_RETRY_COUNT = "Once updated the next SVB GO auto-retry should automatically process this transaction";
    private static final String MESSAGE_FOR_RETRY_COUNT_240 = "Once updated, \"FX_RETRY\" count must be manually updated to '0' for the SVB GO payment batch to process this transaction.";

    private final TransactionDBMapper transactionDBMapper;
    private final PaymentProcessingService paymentProcessingService;
    private final EmailService emailService;
    private final PaymentProcessingErrorUtil paymentProcessingErrorUtil;
    private final FXService fxService;

    public FXContractReferenceRetryJob(TransactionDBMapper transactionDBMapper,
                                       PaymentProcessingService paymentProcessingService,
                                       EmailService emailService,
                                       PaymentProcessingErrorUtil paymentProcessingErrorUtil,
                                       FXService fxService) {
        this.transactionDBMapper = transactionDBMapper;
        this.paymentProcessingService = paymentProcessingService;
        this.emailService = emailService;
        this.paymentProcessingErrorUtil = paymentProcessingErrorUtil;
        this.fxService = fxService;
    }

    @Scheduled(cron = "${fx.contract.reference.retry.cron.expression:-}", zone = "America/Los_Angeles")
    @SchedulerLock(name = "${fx.contract.reference.retry.scheduler.name}")
    public void execute() {
        log.info("Start : FXContractReferenceRetryJob : Time :{}", System.currentTimeMillis());
        try {
            // Get FX transactions with FX_CONTRACT_RETRY downstream status and retry limit
            List<PaymentTransactionStatusEntity> contractReferenceList = transactionDBMapper.getTxnByDownStreamStatusAndRetryLimit(
                    List.of(DownstreamStatusEnum.FX_CONTRACT_RETRY.toString()),
                    null,
                    PaymentConstant.FXW_CONTRACT_REF_RETRY_LIMIT,
                    List.of("FXW", "FXG", "MXW", "XMM", "XMC", "MXG"));
            log.info("FXContractReferenceRetryJob: List of FX_CONTRACT_RETRY records to be retried :{} ", contractReferenceList.size());

            // Get FX transactions with INITIATED OR  downstream status
            List<PaymentTransactionStatusEntity> fxPaymentsWithInitiatedStatus = transactionDBMapper.getTxnByDownStreamStatusAndRetryLimit(
                    List.of(DownstreamStatusEnum.INITIATED.toString()),
                    null,
                    0,
                    List.of("FXW", "FXG", "MXW", "XMM", "XMC", "MXG"));

            // Get FX transactions with FX_EXECUTE_RETRY downstream status
            List<PaymentTransactionStatusEntity> fxExecuteRetryList = transactionDBMapper.getTxnByDownStreamStatusAndRetryLimit(
                    List.of(DownstreamStatusEnum.FX_EXECUTE_RETRY.toString()),
                    null,
                    PaymentConstant.FX_EXECUTE_RETRY_LIMIT,
                    List.of("FXW", "FXG", "MXW", "MXG"));

            log.info("FXContractReferenceRetryJob: List of FX_EXECUTE_RETRY records to be retried :{} ", contractReferenceList.size());
            contractReferenceList.addAll(fxPaymentsWithInitiatedStatus);
            contractReferenceList.addAll(fxExecuteRetryList);

            if (!contractReferenceList.isEmpty()) {
                for (PaymentTransactionStatusEntity fxPaymentEntity : contractReferenceList) {
                    if (fxPaymentEntity != null) {
                        processFXContractReference(fxPaymentEntity);
                    }
                }
            }
            log.info("JOB_ID: 5 - FXWContractReferenceRetryJob successfully completed :{}", new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss").format(new Date()));
        } catch (Exception e) {
            log.error("Error occurred when executing FXWContractReferenceRetryJob", e);
            emailService.sendEmail("JOB_ID: 5 - FXWContractReferenceRetryJob Has Failed", "Caught Unexpected Exception in Retry Job " + e.getMessage());
        }
    }

    private void processFXContractReference(PaymentTransactionStatusEntity fxwEntity) {
        try {
            int retryCount = (fxwEntity.getNoOfRetries() != null ? fxwEntity.getNoOfRetries() : 0) + 1;
            log.info("Message to retry olb_payment_id:{} , No of Retries:{} ", fxwEntity.getTransactionId(), retryCount);
            if (DownstreamStatusEnum.FX_CONTRACT_RETRY.toString().equals(fxwEntity.getDownstreamStatus()) && retryCount == PaymentConstant.FXW_CONTRACT_REF_RETRY_LIMIT) {
                log.info("FXWContractReferenceRetryJob - Sending final email alert to App support team for retryCount:{} and for the paymentId:{}", retryCount, fxwEntity.getTransactionId());
                emailService.sendEmail(EMAIL_SUBJECT + fxwEntity.getTransactionId(),
                        createContractReferenceErrorMessage(fxwEntity.getTransactionId(),
                                "FX Contract " + fxwEntity.getContractId() + " created does not have a WSS reference in TTS system. SVB Go auto-retry has been exhausted. ",
                                fxwEntity.getContractId(), MESSAGE_FOR_RETRY_COUNT_240));
            } else if (DownstreamStatusEnum.FX_CONTRACT_RETRY.toString().equals(fxwEntity.getDownstreamStatus()) && retryCount % 12 == 0) {
                log.info("FXWContractReferenceRetryJob - Sending alert to App support team for retryCount:{} and for the payment_id:{}", retryCount, fxwEntity.getTransactionId());
                emailService.sendEmail(EMAIL_SUBJECT + fxwEntity.getTransactionId(),
                        createContractReferenceErrorMessage(fxwEntity.getTransactionId(),
                                "FX Contract " + fxwEntity.getContractId() + " created does not have a WSS reference in TTS system. ",
                                fxwEntity.getContractId(), MESSAGE_FOR_RETRY_COUNT));
            } else if (DownstreamStatusEnum.INITIATED.toString().equals(fxwEntity.getDownstreamStatus()) && retryCount == PaymentConstant.fxPaymentRetryLimit) {
                log.info("FXWContractReferenceRetryJob - Sending final alert to App support team for payments stuck in initiated state for retryCount:{} and for the paymentId:{}", retryCount, fxwEntity.getTransactionId());
                emailService.sendEmail("JOB_ID: 5 - FXWContractReferenceRetryJob Failed for " + fxwEntity.getTransactionId(), "Caught Unexpected Exception in Retry Job ");
            }
            fxwEntity.setNoOfRetries(retryCount);
            List<ProcessingMessage> processingMessages = transactionDBMapper.fetchTransaction(fxwEntity.getTransactionId(), fxwEntity.getSequenceNo());
            if (!processingMessages.isEmpty()) {
                if ("SDMC".equalsIgnoreCase(fxwEntity.getPaymentCategory())) {
                    List<PaymentProcessingData> paymentsData = processingMessages.stream().map(ProcessingMessage::getPaymentData).toList();
                    paymentProcessingService.processSplitFXWPayment(new FXWPayments(processingMessages.getFirst().getPaymentHeader(),
                            paymentsData));
                } else {
                    ProcessingMessage processingMessage = processingMessages.getFirst();
                    PaymentMapperUtil.customizePaymentMsg(processingMessage.getPaymentData());
                    fxService.processFXWPayment(new FXWPaymentProcessingData(processingMessage.getPaymentHeader(), processingMessage.getPaymentData()), fxwEntity);
                }
            }
        } catch (Exception ex) {
            log.error("Caught a exception while updating the FXContract Reference :{}", ex.getMessage());
            if (DownstreamStatusEnum.FX_CONTRACT_RETRY.toString().equals(fxwEntity.getStatus())) {
                handleException(fxwEntity, ex, FX_CONTRACT_REFERENCE_RETRY_ERROR_MESSAGE);
            } else if (TransactionStatusEnum.FAIL.name().equals(fxwEntity.getStatus())) {
                handleException(fxwEntity, ex, FX_INITIATED_RETRY_ERROR_MESSAGE);
            }
        }
    }

    String createContractReferenceErrorMessage(Long paymentId, String errorMsg, String contractId, String retryCountMessage) {
        return "Hi Team - " + System.lineSeparator() + "Error while trying to retrieve FX contract details for the following FX payment record:" +
                System.lineSeparator() + "PaymentID: " + paymentId + System.lineSeparator() + "Error Reason:  " + errorMsg +
                System.lineSeparator() + "Next Step(s):  " + "Please check with \"WSS AppSupport\" to update the WSS TID and Deal number of the FX Contract " + contractId + " in TTS GUI. " +
                retryCountMessage;
    }

    public void handleException(PaymentTransactionStatusEntity paymentEntity, Exception ex, String errorMessage) {
        try {
            paymentProcessingErrorUtil.handlerProcessingError(paymentEntity.getTransactionId(),
                    paymentEntity.getPaymentType(),
                    errorMessage,
                    "Error: " + ex.getMessage(),
                    "",
                    paymentEntity.getNoOfRetries(),
                    "Y".equals(paymentEntity.getRecurring()));
        } catch (Exception e) {
            log.error("Exception while calling handlePostingError()");
        }
    }
}

