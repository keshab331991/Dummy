package com.svb.gateway.payments.payment.batch.job;

import com.svb.gateway.payments.common.constants.CommonConstant;
import com.svb.gateway.payments.common.enums.DownstreamStatusEnum;
import com.svb.gateway.payments.common.model.payment.FXWPaymentProcessingData;
import com.svb.gateway.payments.common.model.payment.fxw.FXWPayments;
import com.svb.gateway.payments.common.model.payment.processing.PaymentProcessingData;
import com.svb.gateway.payments.common.service.mail.EmailService;
import com.svb.gateway.payments.common.util.PaymentConstant;
import com.svb.gateway.payments.payment.entity.PaymentTransactionStatusEntity;
import com.svb.gateway.payments.payment.mapper.PaymentMapperUtil;
import com.svb.gateway.payments.payment.mapper.db.TransactionDBMapper;
import com.svb.gateway.payments.payment.mapper.db.TransactionEntryDBMapper;
import com.svb.gateway.payments.payment.model.ProcessingMessage;
import com.svb.gateway.payments.payment.service.PaymentProcessingService;
import com.svb.gateway.payments.payment.util.PaymentProcessingErrorUtil;
import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;


@Component
@Slf4j
public class FXPaymentRetryJob {
    private static final String EMAIL_SUBJECT = "SVB Go - FX Payment Retry Failure Notification - PaymentID: ";
    private static final String FX_PAYMENT_RETRY_ERROR_MESSAGE = "Unhandled Exception while retrying FX Payment.";

    private final TransactionDBMapper transactionDBMapper;
    private final PaymentProcessingService paymentProcessingService;
    private final EmailService emailService;
    private final PaymentProcessingErrorUtil paymentProcessingErrorUtil;
    private final TransactionEntryDBMapper transactionEntryDBMapper;

    public FXPaymentRetryJob(TransactionDBMapper transactionDBMapper, PaymentProcessingService paymentProcessingService,
                             EmailService emailService,
                             PaymentProcessingErrorUtil paymentProcessingErrorUtil,
                             TransactionEntryDBMapper transactionEntryDBMapper) {
        this.transactionDBMapper = transactionDBMapper;
        this.paymentProcessingService = paymentProcessingService;
        this.emailService = emailService;
        this.paymentProcessingErrorUtil = paymentProcessingErrorUtil;
        this.transactionEntryDBMapper = transactionEntryDBMapper;
    }

    @Scheduled(cron = "${fx.payment.retry.cron.expression:-}", zone = "America/Los_Angeles")
    @SchedulerLock(name = "${fx.payment.retry.scheduler.name}")
    public void execute() {
        log.info("Start : FXPaymentRetryJob : Time :{}", System.currentTimeMillis());
        try {
            // Get FX transactions with FX_PAYMENT_RETRY downstream status and retry limit
            List<PaymentTransactionStatusEntity> paymentList = transactionDBMapper.getTxnByDownStreamStatusAndRetryLimit(
                    List.of(DownstreamStatusEnum.POSTING_RETRY.toString()),
                    null,
                    PaymentConstant.FXW_PAYMENT_RETRY_LIMIT,
                    List.of("FXW","FXG","MXW","XMM","XMC","MXG"));
            log.info("FXPaymentRetryJob: List of FX_PAYMENT_RETRY records to be retried :{} ", paymentList.size());
            for (PaymentTransactionStatusEntity fxPaymentEntity : paymentList) {
                processFXPayment(fxPaymentEntity);
            }
            log.info("JOB_ID: 4 - FXPaymentRetryJob successfully completed :{}", DateTimeFormatter.ofPattern("dd-MMM-yyyy HH:mm:ss", Locale.ENGLISH).format(LocalDateTime.now()));
        } catch (Exception e) {
            log.error("Error occurred when executing FXPaymentRetryJob", e);
            emailService.sendEmail("JOB_ID: 4 - FXPaymentRetryJob Has Failed", "Caught Unexpected Exception in Retry Job " + e.getMessage());
        }
    }

    private void processFXPayment(PaymentTransactionStatusEntity fxwEntity) {
        try {
            log.info("Message to retry TransactionId:{}", fxwEntity.getTransactionId());
            // updating the retry count in DB
            fxwEntity.setNoOfRetries((fxwEntity.getNoOfRetries() != null ? fxwEntity.getNoOfRetries() : 0) + 1);
            transactionEntryDBMapper.updateTransactionEntryStatus(fxwEntity);
            List<ProcessingMessage> processingMessages = transactionDBMapper.fetchTransaction(fxwEntity.getTransactionId(), fxwEntity.getSequenceNo());
            if(!processingMessages.isEmpty()) {
                ProcessingMessage processingMessage = processingMessages.getFirst();
                PaymentMapperUtil.customizePaymentMsg(processingMessage.getPaymentData());
                paymentProcessingService.processFXWPaymentForPostingRetry(new FXWPaymentProcessingData(processingMessage.getPaymentHeader(), processingMessage.getPaymentData()), fxwEntity);
            }
        } catch (Exception ex) {
            log.error("Caught a exception while updating the FXPayment :{}", ex.getMessage());
            if (DownstreamStatusEnum.POSTING_RETRY.toString().equals(fxwEntity.getStatus())) {
                handleException(fxwEntity, ex,  FX_PAYMENT_RETRY_ERROR_MESSAGE);
            }
        }
    }

    private String createFXPaymentErrorMessage(Long paymentId) {
        return """
           Hi Team,
           Error while Re-trying FX payment:
           PaymentID: %s
           Error Reason: SVB Go auto-retry has been exhausted FX Payment.
           """.formatted(paymentId);
    }

    public void handleException(PaymentTransactionStatusEntity paymentEntity, Exception ex, String errorMessage) {
        try {
            paymentProcessingErrorUtil.handlerProcessingError(paymentEntity.getTransactionId(),
                    paymentEntity.getPaymentType(),
                    errorMessage,
                    "Error: %s".formatted(ex.getMessage()),
                    "",
                    paymentEntity.getNoOfRetries(),
                    "Y".equals(paymentEntity.getRecurring()));
        } catch (Exception e) {
            log.error("Exception while calling handlePostingError()");
        }
    }
}

