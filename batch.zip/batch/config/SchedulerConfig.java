package com.svb.gateway.payments.payment.batch.config;

import lombok.extern.slf4j.Slf4j;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.EnableScheduling;

import javax.sql.DataSource;

@Configuration
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor="${shedlock.default-lock-at-most-for}", defaultLockAtLeastFor="${shedlock.default-lock-at-least-for}")
@Slf4j
public class SchedulerConfig {
    private static final String SHEDLOCK_SCHEDULER_TABLE_NAME = "SHEDLOCK";

    @Bean
    public LockProvider lockProvider(DataSource dataSource) {
        log.info("LockProvider - Initializing Lock Provider Bean");
        var configuration = JdbcTemplateLockProvider.Configuration
                .builder().withTableName(SHEDLOCK_SCHEDULER_TABLE_NAME).
                withJdbcTemplate(new JdbcTemplate(dataSource)).
                usingDbTime().
                build();
        var jdbcTemplateLockProvider = new JdbcTemplateLockProvider(configuration);
        log.info("LockProvider - Initializing Lock Provider Bean Successful");
        return jdbcTemplateLockProvider;
    }
}
